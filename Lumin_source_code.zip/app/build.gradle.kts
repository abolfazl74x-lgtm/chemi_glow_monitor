import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.roborazzi)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.aistudio.nightlapse.camzbx"
    minSdk = 24
    targetSdk = 36
    versionCode = 1
    versionName = "1.0"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    debug { signingConfig = signingConfigs.getByName("debugConfig") }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

// Suppress benign KSP IntelliJ Core AWT-EventQueue-0 disposal race NPE on ApplicationManager.getApplication()
run {
  val kspAwtHandler = Thread.UncaughtExceptionHandler { thread, throwable ->
    val msg = throwable.message ?: ""
    val isKspAwtNpe =
      thread.name.startsWith("AWT-EventQueue") &&
        (msg.contains("ksp.com.intellij.openapi.application.Application") ||
          throwable.stackTrace.any { it.className.startsWith("ksp.com.intellij") })
    if (!isKspAwtNpe) {
      System.err.print("Exception in thread \"${thread.name}\" ")
      throwable.printStackTrace(System.err)
    }
  }
  Thread.setDefaultUncaughtExceptionHandler(kspAwtHandler)
  Thread.getAllStackTraces().keys
    .filter { it.name.startsWith("AWT-EventQueue") }
    .forEach { it.uncaughtExceptionHandler = kspAwtHandler }
}

tasks.configureEach {
  if (name == "preBuild" || name.startsWith("ksp")) {
    doFirst {
      val handler = Thread.UncaughtExceptionHandler { thread, throwable ->
        val msg = throwable.message ?: ""
        val isKspAwtNpe =
          thread.name.startsWith("AWT-EventQueue") &&
            (msg.contains("ksp.com.intellij.openapi.application.Application") ||
              throwable.stackTrace.any { it.className.startsWith("ksp.com.intellij") })
        if (!isKspAwtNpe) {
          System.err.print("Exception in thread \"${thread.name}\" ")
          throwable.printStackTrace(System.err)
        }
      }
      Thread.setDefaultUncaughtExceptionHandler(handler)
      Thread.getAllStackTraces().keys
        .filter { it.name.startsWith("AWT-EventQueue") }
        .forEach { it.uncaughtExceptionHandler = handler }
    }
    doLast {
      val handler = Thread.UncaughtExceptionHandler { thread, throwable ->
        val msg = throwable.message ?: ""
        val isKspAwtNpe =
          thread.name.startsWith("AWT-EventQueue") &&
            (msg.contains("ksp.com.intellij.openapi.application.Application") ||
              throwable.stackTrace.any { it.className.startsWith("ksp.com.intellij") })
        if (!isKspAwtNpe) {
          System.err.print("Exception in thread \"${thread.name}\" ")
          throwable.printStackTrace(System.err)
        }
      }
      Thread.setDefaultUncaughtExceptionHandler(handler)
      Thread.getAllStackTraces().keys
        .filter { it.name.startsWith("AWT-EventQueue") }
        .forEach { it.uncaughtExceptionHandler = handler }
    }
  }
}

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation("androidx.documentfile:documentfile:1.0.1")
  implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:7.1.6")
  implementation("com.arthenica:smart-exception-java:0.2.1")
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))
  implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.vico.compose)
  implementation(libs.vico.compose.m3)
  implementation(libs.vico.core)
  // implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  // implementation(libs.coil.compose)
  // implementation(libs.converter.moshi)
  // implementation(libs.firebase.ai)
  // Uncomment to use Firestore:
  // implementation(libs.firebase.firestore)

  // Uncomment ALL FOUR of the following dependencies together to use Firebase Auth and Google
  // Sign-In via Credential Manager:
  // implementation(libs.firebase.auth)
  // implementation(libs.androidx.credentials)
  // implementation(libs.androidx.credentials.play.services)
  // implementation(libs.googleid)
  // implementation(libs.firebase.appcheck.recaptcha)
  // implementation(libs.firebase.appcheck.debug)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  // implementation(libs.logging.interceptor)
  // implementation(libs.moshi.kotlin)
  // implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  // implementation(libs.retrofit)
  implementation(libs.androidx.media3.exoplayer)
  implementation(libs.androidx.media3.ui)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  testImplementation(libs.roborazzi)
  testImplementation(libs.roborazzi.compose)
  testImplementation(libs.roborazzi.junit.rule)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  // "ksp"(libs.moshi.kotlin.codegen)
}
