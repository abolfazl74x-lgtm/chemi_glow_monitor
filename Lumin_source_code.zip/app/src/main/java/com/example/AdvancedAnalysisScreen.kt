package com.example

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.ExperimentEntity
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.compose.chart.line.lineSpec
import com.patrykandpatrick.vico.compose.chart.scroll.rememberChartScrollSpec
import com.patrykandpatrick.vico.core.axis.AxisItemPlacer
import com.patrykandpatrick.vico.core.chart.decoration.ThresholdLine
import com.patrykandpatrick.vico.core.component.shape.Shapes
import com.patrykandpatrick.vico.core.entry.FloatEntry
import com.patrykandpatrick.vico.core.entry.entryModelOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AdvancedAnalysisParams(
    val smoothingWindowSize: Int,
    val totalIntegralCutoff: Float,
    val highIntegralThreshold: Float,
    val emissionTimeCutoff: Float,
    val highDurationThreshold: Float,
    val maxEmissionWindowDuration: Float
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedAnalysisScreen(
    rawResults: List<IntensityResult>?,
    exposureTime: Float,
    testTitle: String,
    sessionFolderPath: String,
    originalExposure: Float? = null,
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit
) {
    var smoothingWindowSize by remember { mutableStateOf(if (rawResults != null && rawResults.size < 21) kotlin.math.max(3, ((rawResults.size - 1) / 2) * 2 + 1).toString() else "21") }
    var totalIntegralCutoff by remember { mutableStateOf("10.0") }
    var highIntegralThreshold by remember { mutableStateOf("85.0") }
    var emissionTimeCutoff by remember { mutableStateOf("50.0") }
    var highDurationThreshold by remember { mutableStateOf("75.0") }
    var maxEmissionWindowDuration by remember { mutableStateOf("20.0") }
    var smoothingError by remember { mutableStateOf(false) }

    var analysisParams by remember { mutableStateOf<AdvancedAnalysisParams?>(null) }
    var analysisResults by remember { mutableStateOf<AnalysisResults?>(null) }
    
    var experimentName by remember { 
        mutableStateOf(testTitle.takeIf { it.isNotBlank() } ?: "Exp_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}") 
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text("Advanced Analysis") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { padding ->
            if (rawResults.isNullOrEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Text(
                        text = "No data available",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(padding)
                        .padding(16.dp)
                ) {
            // Parameters Section
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Configuration",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    val parsedSmoothing = smoothingWindowSize.toIntOrNull()
                    val isSmoothingPositive = parsedSmoothing != null && parsedSmoothing > 0
                    val isEvenSmoothing = parsedSmoothing != null && parsedSmoothing > 0 && parsedSmoothing % 2 == 0
                    val isSmoothingInvalid = smoothingWindowSize.isNotEmpty() && !isSmoothingPositive

                    SettingsNumberField(
                        value = smoothingWindowSize,
                        onValueChange = { 
                            smoothingWindowSize = it.filter { char -> char.isDigit() }
                            val num = smoothingWindowSize.toIntOrNull()
                            smoothingError = num == null || num <= 0
                        },
                        label = "Smoothing Window Size (Odd)",
                        isError = isSmoothingInvalid
                    )
                    if (isSmoothingInvalid) {
                        Text(
                            text = "Must be a positive integer (> 0).", 
                            color = MaterialTheme.colorScheme.error, 
                            style = MaterialTheme.typography.bodySmall, 
                            modifier = Modifier.padding(start = 16.dp, bottom = 12.dp)
                        )
                    } else if (isEvenSmoothing) {
                        Text(
                            text = "Even numbers will be rounded up to the next odd integer (${parsedSmoothing!! + 1}).", 
                            color = MaterialTheme.colorScheme.primary, 
                            style = MaterialTheme.typography.bodySmall, 
                            modifier = Modifier.padding(start = 16.dp, bottom = 12.dp)
                        )
                    }
                    SettingsNumberField(
                        value = totalIntegralCutoff,
                        onValueChange = { totalIntegralCutoff = it },
                        label = "Total Integral Cutoff (%)"
                    )
                    SettingsNumberField(
                        value = highIntegralThreshold,
                        onValueChange = { highIntegralThreshold = it },
                        label = "High Integral Threshold (%)"
                    )
                    SettingsNumberField(
                        value = emissionTimeCutoff,
                        onValueChange = { emissionTimeCutoff = it },
                        label = "Emission Time Cutoff (%)"
                    )
                    SettingsNumberField(
                        value = highDurationThreshold,
                        onValueChange = { highDurationThreshold = it },
                        label = "High Duration Threshold (%)"
                    )
                    SettingsNumberField(
                        value = maxEmissionWindowDuration,
                        onValueChange = { maxEmissionWindowDuration = it },
                        label = "Max Emission Window Duration (s)"
                    )
                    
                    Button(
                        onClick = {
                            val rawSmoothing = (smoothingWindowSize.toIntOrNull() ?: 3).coerceAtLeast(1)
                            val finalSmoothing = if (rawSmoothing % 2 == 0) rawSmoothing + 1 else rawSmoothing
                            
                            val params = AdvancedAnalysisParams(
                                smoothingWindowSize = finalSmoothing,
                                totalIntegralCutoff = totalIntegralCutoff.toFloatOrNull() ?: 10.0f,
                                highIntegralThreshold = highIntegralThreshold.toFloatOrNull() ?: 85.0f,
                                emissionTimeCutoff = emissionTimeCutoff.toFloatOrNull() ?: 50.0f,
                                highDurationThreshold = highDurationThreshold.toFloatOrNull() ?: 75.0f,
                                maxEmissionWindowDuration = maxEmissionWindowDuration.toFloatOrNull() ?: 20.0f
                            )
                            
                            val rawData = rawResults.map { 
                                Pair(((it.frameIndex + 1) * exposureTime).toDouble(), it.averageIntensity) 
                            }
                            val results = SignalProcessor.analyze(rawData, params)
                            
                            analysisParams = params
                            analysisResults = results
                        },
                        enabled = isSmoothingPositive,
                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
                    ) {
                        Text("Run Analysis")
                    }
                }
            }

            // Results Section
            if (analysisResults != null && analysisParams != null) {
                val results = analysisResults!!
                val params = analysisParams!!
                
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                            .padding(16.dp)
                    ) {
                        val chartEntryModel = remember(results) {
                            val entries = results.smoothedData.map { 
                                FloatEntry(x = it.first.toFloat(), y = it.second.toFloat()) 
                            }
                            entryModelOf(entries)
                        }
                        
                        val highThresholdValue = (results.peakIntensity * (params.highDurationThreshold / 100.0)).toFloat()
                        
                        val thresholdLine = remember(highThresholdValue) {
                            ThresholdLine(
                                thresholdValue = highThresholdValue,
                                thresholdLabel = "High Threshold",
                                lineComponent = com.patrykandpatrick.vico.core.component.shape.ShapeComponent(
                                    color = android.graphics.Color.RED,
                                    strokeWidthDp = 2f
                                ),
                                labelComponent = com.patrykandpatrick.vico.core.component.text.TextComponent.Builder().apply {
                                    color = android.graphics.Color.WHITE
                                    background = com.patrykandpatrick.vico.core.component.shape.ShapeComponent(
                                        color = android.graphics.Color.RED,
                                        shape = Shapes.pillShape
                                    )
                                }.build()
                            )
                        }

                        val dataSize = results.smoothedData.size
                        val dynamicSpacing = kotlin.math.max(1, dataSize / 6)

                        Chart(
                            chart = lineChart(
                                lines = listOf(lineSpec(
                                    lineColor = MaterialTheme.colorScheme.primary,
                                    point = null,
                                    pointConnector = com.patrykandpatrick.vico.core.chart.DefaultPointConnector(cubicStrength = 0f)
                                )),
                                decorations = listOf(thresholdLine)
                            ),
                            model = chartEntryModel,
                            startAxis = rememberStartAxis(
                                title = "Intensity",
                                titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(end = 4.dp)
                                )
                            ),
                            bottomAxis = rememberBottomAxis(
                                title = "Time (s)",
                                titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(top = 4.dp)
                                ),
                                itemPlacer = AxisItemPlacer.Horizontal.default(
                                    spacing = dynamicSpacing,
                                    addExtremeLabelPadding = true
                                )
                            ),
                            chartScrollSpec = rememberChartScrollSpec(isScrollEnabled = false)
                        )
                    }
                }
                
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Summary Metrics",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.padding(bottom = 8.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        
                        MetricRow("Total AUC:", String.format(Locale.US, "%.2f", results.totalAuc))
                        MetricRow("Peak Time:", String.format(Locale.US, "%.2f s", results.peakTime))
                        MetricRow("Peak Intensity:", String.format(Locale.US, "%.2f", results.peakIntensity))
                        MetricRow("High Duration:", String.format(Locale.US, "%.2f s", results.highDuration))
                        if (originalExposure != null) {
                            MetricRow("Original Exposure Time:", "${originalExposure}s")
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Max Emission Window",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 4.dp)
                        )
                        MetricRow("Start Time:", String.format(Locale.US, "%.2f s", results.maxWindowStartTime))
                        MetricRow("End Time:", String.format(Locale.US, "%.2f s", results.maxWindowEndTime))
                        MetricRow("Window AUC:", String.format(Locale.US, "%.2f", results.maxWindowAuc))
                    }
                }

                OutlinedTextField(
                    value = experimentName,
                    onValueChange = { experimentName = it },
                    label = { Text("Experiment Name") },
                    readOnly = testTitle.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val entity = ExperimentEntity(
                            experimentName = experimentName,
                            timestamp = System.currentTimeMillis(),
                            exposureTime = exposureTime.toInt(),
                            originalExposure = originalExposure,
                            sessionFolderPath = sessionFolderPath,
                            peakTime = results.peakTime,
                            peakIntensity = results.peakIntensity,
                            totalAuc = results.totalAuc,
                            highDuration = results.highDuration,
                            maxWindowAuc = results.maxWindowAuc,
                            maxWindowStartTime = results.maxWindowStartTime,
                            maxWindowEndTime = results.maxWindowEndTime
                        )
                        if (sessionFolderPath.isNotBlank()) {
                            try {
                                val sFolder = java.io.File(sessionFolderPath)
                                if (sFolder.exists() || sFolder.mkdirs()) {
                                    val csvOut = java.io.File(sFolder, "kinetics.csv")
                                    csvOut.bufferedWriter().use { w ->
                                        w.write("Time(s),Intensity\n")
                                        rawResults.forEach { r ->
                                            w.write("${(r.frameIndex + 1) * exposureTime},${r.averageIntensity}\n")
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        onSaveExperiment(entity)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Save Experiment")
                }
            }
        }
    }
    }
}
}

@Composable
fun SettingsNumberField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    isError: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = { input ->
            if (input.isEmpty() || (input.count { char -> char == '.' } <= 1 && input.replace(".", "").all { char -> char.isDigit() })) {
                onValueChange(input)
            }
        },
        label = { Text(label) },
        isError = isError,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = Color.LightGray,
            focusedLabelColor = MaterialTheme.colorScheme.primary,
            unfocusedLabelColor = Color.LightGray,
            cursorColor = MaterialTheme.colorScheme.primary,
            errorTextColor = MaterialTheme.colorScheme.error,
            errorBorderColor = MaterialTheme.colorScheme.error,
            errorLabelColor = MaterialTheme.colorScheme.error,
            errorCursorColor = MaterialTheme.colorScheme.error
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
    )
}

@Composable
fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
