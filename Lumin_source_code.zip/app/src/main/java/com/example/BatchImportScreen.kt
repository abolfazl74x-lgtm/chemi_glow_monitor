package com.example

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatchImportScreen(
    onBack: () -> Unit,
    onImportComplete: (List<File>, String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var isImporting by remember { mutableStateOf(false) }
    var importProgress by remember { mutableFloatStateOf(0f) }
    var importStatus by remember { mutableStateOf("Ready to import...") }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            isImporting = true
            scope.launch {
                withContext(Dispatchers.IO) {
                    try {
                        importStatus = "Sorting files..."
                        
                        // Sort URIs based on Display Name (chronological for scientific frames)
                        val sortedUris = uris.sortedBy { uri ->
                            getFileName(context, uri)
                        }

                        // Create session folder
                        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        val sessionDir = File(context.cacheDir, "imported_session_$timestamp")
                        if (!sessionDir.exists()) sessionDir.mkdirs()
                        
                        val framesDir = File(sessionDir, "frames")
                        if (!framesDir.exists()) framesDir.mkdirs()
                        
                        val copiedFiles = mutableListOf<File>()
                        val total = sortedUris.size
                        
                        sortedUris.forEachIndexed { index, uri ->
                            val destFile = File(framesDir, String.format("frame_%03d.jpg", index + 1))
                            context.contentResolver.openInputStream(uri)?.use { input ->
                                FileOutputStream(destFile).use { output ->
                                    input.copyTo(output)
                                }
                            }
                            if (destFile.exists()) {
                                copiedFiles.add(destFile)
                            }
                            
                            val progress = (index + 1).toFloat() / total.toFloat()
                            withContext(Dispatchers.Main) {
                                importProgress = progress
                                importStatus = "Copying... ${index + 1}/$total"
                            }
                        }
                        
                        val title = if (sortedUris.isNotEmpty()) {
                            FileUtil.extractOriginalFilename(context, sortedUris.first())
                        } else {
                            "imported_batch"
                        }
                        withContext(Dispatchers.Main) {
                            importStatus = "Import Complete!"
                            onImportComplete(copiedFiles, title)
                        }
                        
                    } catch (e: Exception) {
                        e.printStackTrace()
                        withContext(Dispatchers.Main) {
                            importStatus = "Error: ${e.localizedMessage}"
                            isImporting = false
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Batch Import Images") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (!isImporting) {
                Text(
                    text = "Select a sequence of JPEG frames from your device to import them for analysis.",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
                Button(
                    onClick = { launcher.launch("image/jpeg") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Select JPEG Sequence")
                }
            } else {
                CircularProgressIndicator(
                    progress = { importProgress },
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                LinearProgressIndicator(
                    progress = { importProgress },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(importStatus, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

private fun getFileName(context: Context, uri: Uri): String {
    var result: String? = null
    if (uri.scheme == "content") {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    result = cursor.getString(index)
                }
            }
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/') ?: -1
        if (cut != -1) {
            result = result?.substring(cut + 1)
        }
    }
    return result ?: ""
}
