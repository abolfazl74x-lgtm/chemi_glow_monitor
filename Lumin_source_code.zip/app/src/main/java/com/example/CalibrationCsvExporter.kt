package com.example

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class UnknownSampleResult(
    val name: String,
    val yValue: Double,
    val calculatedX: Double
)

object CalibrationCsvExporter {

    /**
     * Exports a structured Calibration Report (CSV format, readable directly by Excel)
     * containing:
     * 1. Calibration Summary (Equation, Slope, Intercept, R², Feature Name, Concentration Unit)
     * 2. Standard Calibration Points Table (Concentration vs Measured Value vs Predicted Value)
     * 3. Unknown Samples Analysis (Sample Name, Input Y, Calculated Concentration)
     *
     * Files are saved to the public Downloads folder via MediaStore.
     */
    suspend fun exportCalibrationReport(
        context: Context,
        result: CalibrationResult,
        featureName: String,
        unit: String,
        unknownSamples: List<UnknownSampleResult> = emptyList(),
        unknownY: Double? = null,
        calculatedX: Double? = null,
        unknownSampleLabel: String? = null
    ): Uri? = withContext(Dispatchers.IO) {
        try {
            val timestamp = System.currentTimeMillis()
            val cleanFeature = featureName.replace("\\s+".toRegex(), "_")
            val fileName = "Calibration_${cleanFeature}_$timestamp.csv"
            val resolver = context.contentResolver
            var resultUri: Uri? = null

            val allUnknowns = if (unknownSamples.isNotEmpty()) {
                unknownSamples
            } else if (unknownY != null && calculatedX != null) {
                listOf(
                    UnknownSampleResult(
                        name = unknownSampleLabel?.takeIf { it.isNotBlank() } ?: "Manual Input",
                        yValue = unknownY,
                        calculatedX = calculatedX
                    )
                )
            } else {
                emptyList()
            }

            val csvContent = buildCsvContent(
                result = result,
                featureName = featureName,
                unit = unit,
                unknownSamples = allUnknowns
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                resultUri = resolver.insert(collection, contentValues)
                resultUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(csvContent.toByteArray(Charsets.UTF_8))
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) {
                    downloadsDir.mkdirs()
                }
                val file = File(downloadsDir, fileName)
                file.outputStream().use { outputStream ->
                    outputStream.write(csvContent.toByteArray(Charsets.UTF_8))
                }
                resultUri = Uri.fromFile(file)
            }
            resultUri
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun buildCsvContent(
        result: CalibrationResult,
        featureName: String,
        unit: String,
        unknownSamples: List<UnknownSampleResult>
    ): String {
        val sb = StringBuilder()

        // Section 1: Calibration Summary
        sb.append("=== CALIBRATION CURVE REPORT ===\n")
        sb.append("Report Type,Linear Regression Calibration\n")
        sb.append("Analytical Feature (Y),\"$featureName\"\n")
        sb.append("Concentration Unit (X),\"$unit\"\n")
        sb.append(
            "Equation,\"y = ${String.format(Locale.US, "%.6f", result.slope)}x ${if (result.intercept >= 0) "+ " else "- "}${String.format(Locale.US, "%.6f", kotlin.math.abs(result.intercept))}\"\n"
        )
        sb.append("Slope (m),${String.format(Locale.US, "%.6f", result.slope)}\n")
        sb.append("Y-Intercept (b),${String.format(Locale.US, "%.6f", result.intercept)}\n")
        sb.append("R-Squared (R²),${String.format(Locale.US, "%.6f", result.rSquared)}\n")
        sb.append("Number of Standards,${result.points.size}\n")
        sb.append("\n")

        // Section 2: Standard Points
        sb.append("=== STANDARD CALIBRATION POINTS ===\n")
        val unitLabel = if (unit.isNotBlank()) " ($unit)" else ""
        sb.append("Standard #,Standard Concentration [X]$unitLabel,Measured $featureName [Y],Predicted $featureName [Y_pred],Residual (Y - Y_pred)\n")

        val sortedPoints = result.points.sortedBy { it.first }
        sortedPoints.forEachIndexed { index, (x, y) ->
            val yPred = result.slope * x + result.intercept
            val residual = y - yPred
            sb.append(
                "${index + 1},${String.format(Locale.US, "%.4f", x)},${String.format(Locale.US, "%.4f", y)},${String.format(Locale.US, "%.4f", yPred)},${String.format(Locale.US, "%.4f", residual)}\n"
            )
        }
        sb.append("\n")

        // Section 3: Unknown Samples Analysis
        sb.append("=== Unknown Samples Analysis ===\n")
        sb.append("Sample Name,Input Y ($featureName),Calculated Concentration ($unit)\n")
        if (unknownSamples.isNotEmpty()) {
            unknownSamples.forEach { sample ->
                val escapedName = sample.name.replace("\"", "\"\"")
                sb.append(
                    "\"$escapedName\",${String.format(Locale.US, "%.4f", sample.yValue)},${String.format(Locale.US, "%.4f", sample.calculatedX)}\n"
                )
            }
        }

        return sb.toString()
    }
}
