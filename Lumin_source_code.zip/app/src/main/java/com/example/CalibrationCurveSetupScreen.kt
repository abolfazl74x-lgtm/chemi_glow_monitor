package com.example

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalibrationCurveSetupScreen(
    viewModel: ExperimentViewModel,
    onBack: () -> Unit,
    onGenerate: (List<CalibrationStandard>, String, String) -> Unit
) {
    val context = LocalContext.current
    val experiments by viewModel.allExperiments.collectAsState()

    val features = listOf("Peak Value", "Total AUC", "Max Emission AUC")
    var featureExpanded by remember { mutableStateOf(false) }
    var selectedFeature by remember { mutableStateOf(features[1]) }

    val commonUnits = listOf("mg/L", "µg/mL", "ppm", "ppb", "mM", "µM", "nM", "%")
    var selectedUnit by remember { mutableStateOf("mg/L") }
    var unitDropdownExpanded by remember { mutableStateOf(false) }

    // Map of Experiment ID to Concentration Input String
    var selectedExperiments by remember { mutableStateOf(mapOf<Int, String>()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Calibration Setup") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            ExposedDropdownMenuBox(
                expanded = featureExpanded,
                onExpandedChange = { featureExpanded = it }
            ) {
                OutlinedTextField(
                    value = selectedFeature,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Initial Y-Axis Feature (Switchable in Results)") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = featureExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = featureExpanded,
                    onDismissRequest = { featureExpanded = false }
                ) {
                    features.forEach { feature ->
                        DropdownMenuItem(
                            text = { Text(feature) },
                            onClick = {
                                selectedFeature = feature
                                featureExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            ExposedDropdownMenuBox(
                expanded = unitDropdownExpanded,
                onExpandedChange = { unitDropdownExpanded = it }
            ) {
                OutlinedTextField(
                    value = selectedUnit,
                    onValueChange = { selectedUnit = it },
                    label = { Text("Concentration Unit") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitDropdownExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = unitDropdownExpanded,
                    onDismissRequest = { unitDropdownExpanded = false }
                ) {
                    commonUnits.forEach { unit ->
                        DropdownMenuItem(
                            text = { Text(unit) },
                            onClick = {
                                selectedUnit = unit
                                unitDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("Select Standard Samples:", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(experiments) { exp ->
                    val isSelected = selectedExperiments.containsKey(exp.id)
                    val yVal = when (selectedFeature) {
                        "Peak Value" -> exp.peakIntensity
                        "Total AUC" -> exp.totalAuc
                        "Max Emission AUC" -> exp.maxWindowAuc
                        else -> exp.totalAuc
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                        onClick = {
                            selectedExperiments = if (isSelected) {
                                selectedExperiments - exp.id
                            } else {
                                selectedExperiments + (exp.id to "")
                            }
                        }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { checked ->
                                        selectedExperiments = if (checked) {
                                            selectedExperiments + (exp.id to "")
                                        } else {
                                            selectedExperiments - exp.id
                                        }
                                    }
                                )
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(start = 4.dp)
                                ) {
                                    Text(
                                        text = exp.experimentName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "$selectedFeature: ${String.format(Locale.US, "%.2f", yVal)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "Peak: ${String.format(Locale.US, "%.1f", exp.peakIntensity)} • Total AUC: ${String.format(Locale.US, "%.1f", exp.totalAuc)} • Max AUC: ${String.format(Locale.US, "%.1f", exp.maxWindowAuc)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (isSelected) {
                                OutlinedTextField(
                                    value = selectedExperiments[exp.id] ?: "",
                                    onValueChange = { newValue ->
                                        selectedExperiments = selectedExperiments + (exp.id to newValue)
                                    },
                                    label = { Text("Standard Concentration ($selectedUnit)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                                        unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(start = 48.dp, top = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val standards = selectedExperiments.mapNotNull { (id, concStr) ->
                        val conc = concStr.toDoubleOrNull()
                        val exp = experiments.find { it.id == id }
                        if (conc != null && exp != null) {
                            CalibrationStandard(
                                name = exp.experimentName,
                                concentration = conc,
                                peakValue = exp.peakIntensity,
                                totalAuc = exp.totalAuc,
                                maxEmissionAuc = exp.maxWindowAuc
                            )
                        } else null
                    }
                    if (standards.size < 2) {
                        Toast.makeText(
                            context,
                            "Please select at least 2 standards with valid concentrations",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else if (standards.map { it.concentration }.distinct().size < 2) {
                        Toast.makeText(
                            context,
                            "Standards must have at least 2 distinct concentrations",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        onGenerate(standards, selectedFeature, selectedUnit)
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = selectedExperiments.isNotEmpty()
            ) {
                Text("Generate Calibration Curve")
            }
        }
    }
}
