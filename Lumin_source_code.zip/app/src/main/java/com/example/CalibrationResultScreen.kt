package com.example

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CalibrationEntity
import com.example.data.ExperimentEntity
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.compose.chart.line.lineSpec
import com.patrykandpatrick.vico.compose.chart.scroll.rememberChartScrollSpec
import com.patrykandpatrick.vico.core.axis.AxisItemPlacer
import com.patrykandpatrick.vico.core.chart.DefaultPointConnector
import com.patrykandpatrick.vico.core.component.shape.Shapes
import com.patrykandpatrick.vico.core.entry.ChartEntryModel
import com.patrykandpatrick.vico.core.entry.FloatEntry
import com.patrykandpatrick.vico.core.entry.entryModelOf
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val LabBackground = Color(0xFFF6F7FB)
private val LabSurface = Color(0xFFFFFFFF)
private val LabSoftPurple = Color(0xFFF3F0FF)
private val LabPrimaryPurple = Color(0xFF4F46E5)
private val LabBorderColor = Color(0xFFE5E7EB)
private val LabTextPrimary = Color(0xFF111827)
private val LabTextSecondary = Color(0xFF6B7280)
private val LabStandardPointColor = Color(0xFF2563EB)
private val LabUnknownOrange = Color(0xFFF97316)

private val CalibrationFeatures = listOf("Peak Value", "Total AUC", "Max Emission AUC")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalibrationResultScreen(
    standards: List<CalibrationStandard>,
    initialFeature: String,
    concentrationUnit: String = "",
    experiments: List<ExperimentEntity> = emptyList(),
    fallbackResult: CalibrationResult? = null,
    onSaveCalibration: (CalibrationEntity) -> Unit = {},
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var activeFeature by remember(initialFeature) {
        mutableStateOf(if (initialFeature in CalibrationFeatures) initialFeature else "Total AUC")
    }

    val result = remember(standards, activeFeature, fallbackResult) {
        LinearRegressionHelper.calculateForStandards(standards, activeFeature)
            ?: fallbackResult
            ?: CalibrationResult(slope = 1.0, intercept = 0.0, rSquared = 0.0, points = emptyList())
    }

    var isExporting by remember { mutableStateOf(false) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var saveCalibrationName by remember { mutableStateOf("") }

    var unknownYInput by remember { mutableStateOf("") }
    var calculatedX by remember { mutableStateOf<Double?>(null) }
    var selectedExperimentId by remember { mutableStateOf<Int?>(null) }
    var selectedExperimentLabel by remember { mutableStateOf("") }
    var selectedExperimentName by remember { mutableStateOf("") }
    var isExperimentDropdownExpanded by remember { mutableStateOf(false) }
    var unknownSamples by remember { mutableStateOf<List<UnknownSampleResult>>(emptyList()) }

    // Automatically recalculate active unknown input and unknownSamples list when activeFeature or regression result changes
    LaunchedEffect(activeFeature, result) {
        val currentExpId = selectedExperimentId
        if (currentExpId != null) {
            val exp = experiments.find { it.id == currentExpId }
            if (exp != null) {
                val newYVal = when (activeFeature) {
                    "Peak Value" -> exp.peakIntensity
                    "Total AUC" -> exp.totalAuc
                    "Max Emission AUC" -> exp.maxWindowAuc
                    else -> exp.maxWindowAuc
                }
                selectedExperimentLabel = "${exp.experimentName} ($activeFeature: ${String.format(Locale.US, "%.2f", newYVal)})"
                unknownYInput = newYVal.toString()
                calculatedX = if (result.slope != 0.0) (newYVal - result.intercept) / result.slope else null
            }
        } else {
            val yVal = unknownYInput.toDoubleOrNull()
            calculatedX = if (yVal != null && result.slope != 0.0) {
                (yVal - result.intercept) / result.slope
            } else {
                null
            }
        }

        if (unknownSamples.isNotEmpty() && result.slope != 0.0) {
            unknownSamples = unknownSamples.map { sample ->
                val matchingExp = experiments.find { it.experimentName == sample.name }
                val updatedY = if (matchingExp != null) {
                    when (activeFeature) {
                        "Peak Value" -> matchingExp.peakIntensity
                        "Total AUC" -> matchingExp.totalAuc
                        "Max Emission AUC" -> matchingExp.maxWindowAuc
                        else -> matchingExp.maxWindowAuc
                    }
                } else {
                    sample.yValue
                }
                val updatedX = (updatedY - result.intercept) / result.slope
                sample.copy(yValue = updatedY, calculatedX = updatedX)
            }
        }
    }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Calibration") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Saves all 3 analytical features (Peak Value, Total AUC, Max Emission AUC) so you can switch between them anytime.",
                        style = MaterialTheme.typography.bodySmall,
                        color = LabTextSecondary
                    )
                    OutlinedTextField(
                        value = saveCalibrationName,
                        onValueChange = { saveCalibrationName = it },
                        label = { Text("Calibration Name") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_calibration_name_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val finalName = saveCalibrationName.trim().ifBlank {
                            "Calibration - ${SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date())}"
                        }
                        onSaveCalibration(
                            CalibrationEntity(
                                name = finalName,
                                slope = result.slope,
                                intercept = result.intercept,
                                rSquared = result.rSquared,
                                unit = concentrationUnit,
                                featureName = activeFeature,
                                standardPointsJson = CalibrationStandardJsonHelper.toJson(standards),
                                timestamp = System.currentTimeMillis()
                            )
                        )
                        showSaveDialog = false
                        Toast.makeText(context, "Calibration saved successfully", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("confirm_save_calibration_button")
                ) {
                    Text("Save", color = LabPrimaryPurple, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    val sortedPoints = remember(result) { result.points.sortedBy { it.first } }

    val chartEntryModel = remember(result) {
        val minXRaw = sortedPoints.minOfOrNull { it.first } ?: 0.0
        val maxXRaw = sortedPoints.maxOfOrNull { it.first } ?: 1.0
        val range = if (maxXRaw == minXRaw) 1.0 else (maxXRaw - minXRaw)

        val stepFactor = when {
            range >= 10000 -> 10.0
            range >= 1000 -> 1.0
            range >= 100 -> 0.1
            range >= 10 -> 0.01
            range >= 1 -> 0.001
            range >= 0.1 -> 0.0001
            else -> 0.00001
        }
        fun Double.snap(): Float = (kotlin.math.round(this / stepFactor) * stepFactor).toFloat()

        val scatterSeries = sortedPoints
            .map { FloatEntry(it.first.snap(), it.second.toFloat()) }
            .distinctBy { it.x }

        val snappedMin = minXRaw.snap()
        val snappedMax = if (minXRaw == maxXRaw || snappedMin == maxXRaw.snap()) snappedMin + stepFactor.toFloat() else maxXRaw.snap()

        val lineSeries = listOf(
            FloatEntry(snappedMin, (result.slope * snappedMin + result.intercept).toFloat()),
            FloatEntry(snappedMax, (result.slope * snappedMax + result.intercept).toFloat())
        )

        entryModelOf(scatterSeries, lineSeries)
    }

    fun handleExport() {
        if (isExporting) return
        isExporting = true
        coroutineScope.launch {
            val yVal = unknownYInput.toDoubleOrNull()
            val uri = CalibrationCsvExporter.exportCalibrationReport(
                context = context,
                result = result,
                featureName = activeFeature,
                unit = concentrationUnit,
                unknownSamples = unknownSamples,
                unknownY = yVal,
                calculatedX = calculatedX,
                unknownSampleLabel = selectedExperimentName.ifBlank { if (yVal != null) "Manual Input" else null }
            )
            isExporting = false
            if (uri != null) {
                Toast.makeText(context, "Calibration Report Saved to Downloads folder", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Failed to export calibration report", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        containerColor = LabBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Calibration Curve",
                            color = LabTextPrimary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Feature: $activeFeature${if (concentrationUnit.isNotBlank()) " • Unit: $concentrationUnit" else ""}",
                            color = LabTextSecondary,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = LabTextPrimary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            val dateStr = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date())
                            saveCalibrationName = "Calibration - $dateStr"
                            showSaveDialog = true
                        },
                        modifier = Modifier.testTag("save_calibration_top_button")
                    ) {
                        Icon(
                            Icons.Default.Save,
                            contentDescription = "Save Calibration",
                            tint = LabPrimaryPurple
                        )
                    }
                    IconButton(
                        onClick = { handleExport() },
                        enabled = !isExporting
                    ) {
                        Icon(
                            Icons.Default.FileDownload,
                            contentDescription = "Export Calibration Report",
                            tint = LabPrimaryPurple
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = LabSurface,
                    titleContentColor = LabTextPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(LabBackground)
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 0. 3-State Y-Axis Feature Selector at the top of the screen
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LabSurface),
                border = BorderStroke(1.dp, LabBorderColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Y-Axis Analytical Feature",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = LabTextSecondary
                    )
                    SingleChoiceSegmentedButtonRow(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CalibrationFeatures.forEachIndexed { index, feature ->
                            val isSelected = activeFeature == feature
                            SegmentedButton(
                                selected = isSelected,
                                onClick = { activeFeature = feature },
                                shape = SegmentedButtonDefaults.itemShape(
                                    index = index,
                                    count = CalibrationFeatures.size
                                ),
                                colors = SegmentedButtonDefaults.colors(
                                    activeContainerColor = LabPrimaryPurple,
                                    activeContentColor = Color.White,
                                    inactiveContainerColor = LabSurface,
                                    inactiveContentColor = LabTextPrimary,
                                    activeBorderColor = LabPrimaryPurple,
                                    inactiveBorderColor = LabBorderColor
                                ),
                                modifier = Modifier.testTag("feature_segment_$index")
                            ) {
                                Text(
                                    text = feature,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // 1. Top Summary Cards (Split Two-Column Layout: Equation & R²)
            val r2 = result.rSquared
            val (r2Color, r2BadgeBg, r2BadgeLabel) = when {
                r2 >= 0.99 -> Triple(Color(0xFF16A34A), Color(0xFFDCFCE7), "Excellent")
                r2 >= 0.95 -> Triple(Color(0xFFEA580C), Color(0xFFFFEDD5), "Good")
                else -> Triple(Color(0xFFDC2626), Color(0xFFFEE2E2), "Poor")
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LabSurface),
                border = BorderStroke(1.dp, LabBorderColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Column: Best-Fit Equation (Linear)
                    Column(
                        modifier = Modifier
                            .weight(1.35f)
                            .padding(end = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Best-Fit Equation (Linear)",
                            style = MaterialTheme.typography.labelMedium,
                            color = LabTextSecondary
                        )
                        val sign = if (result.intercept >= 0) "+" else "-"
                        val interceptAbs = kotlin.math.abs(result.intercept)
                        Text(
                            text = "y = ${String.format(Locale.US, "%.4f", result.slope)}x $sign ${String.format(Locale.US, "%.4f", interceptAbs)}",
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 18.sp),
                            fontWeight = FontWeight.ExtraBold,
                            color = LabPrimaryPurple
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Slope (m): ${String.format(Locale.US, "%.4f", result.slope)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = LabTextSecondary
                        )
                        Text(
                            text = "Intercept (b): ${String.format(Locale.US, "%.4f", result.intercept)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = LabTextSecondary
                        )
                    }

                    // Vertical Divider
                    VerticalDivider(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(1.dp),
                        color = LabBorderColor
                    )

                    // Right Column: Coefficient (R²)
                    Column(
                        modifier = Modifier
                            .weight(0.95f)
                            .padding(start = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Coefficient (R²)",
                            style = MaterialTheme.typography.labelMedium,
                            color = LabTextSecondary,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = String.format(Locale.US, "%.4f", r2),
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = r2Color
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = r2BadgeBg,
                            shape = RoundedCornerShape(50),
                        ) {
                            Text(
                                text = r2BadgeLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = r2Color,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            // 2. Chart Card with Straight Trendline & Legend
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LabSurface),
                border = BorderStroke(1.dp, LabBorderColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Standard Calibration Curve ($activeFeature)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = LabTextPrimary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp)
                            .background(LabSurface)
                    ) {
                        val axisLabelComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                            color = LabTextSecondary
                        )
                        Chart(
                            chart = lineChart(
                                lines = listOf(
                                    // Series 1: Standard Points (small dots, no connecting line)
                                    lineSpec(
                                        lineColor = Color.Transparent,
                                        lineBackgroundShader = null,
                                        point = com.patrykandpatrick.vico.compose.component.shapeComponent(
                                            shape = Shapes.pillShape,
                                            color = LabStandardPointColor
                                        ),
                                        pointSize = 7.dp,
                                        pointConnector = DefaultPointConnector(cubicStrength = 0f)
                                    ),
                                    // Series 2: Regression Line (strictly straight line, deep purple, no points)
                                    lineSpec(
                                        lineColor = LabPrimaryPurple,
                                        lineThickness = 2.5.dp,
                                        lineBackgroundShader = null,
                                        point = null,
                                        pointConnector = DefaultPointConnector(cubicStrength = 0f)
                                    )
                                )
                            ),
                            model = chartEntryModel,
                            startAxis = rememberStartAxis(
                                guideline = null,
                                label = axisLabelComponent,
                                title = activeFeature,
                                titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = LabTextPrimary,
                                    margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(end = 4.dp)
                                )
                            ),
                            bottomAxis = rememberBottomAxis(
                                guideline = null,
                                label = axisLabelComponent,
                                title = if (concentrationUnit.isNotBlank()) "Concentration ($concentrationUnit)" else "Concentration",
                                titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = LabTextPrimary,
                                    margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(top = 4.dp)
                                ),
                                itemPlacer = AxisItemPlacer.Horizontal.default()
                            ),
                            chartScrollSpec = rememberChartScrollSpec(isScrollEnabled = false)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = LabBorderColor)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Custom Chart Legend
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Standards (X, Y)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .clip(CircleShape)
                                    .background(LabStandardPointColor)
                            )
                            Text(
                                text = "Standards (X, Y)",
                                style = MaterialTheme.typography.labelSmall,
                                color = LabTextSecondary
                            )
                        }

                        // Linear Fit (y=mx+b)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(16.dp)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(LabPrimaryPurple)
                            )
                            Text(
                                text = "Linear Fit (y=mx+b)",
                                style = MaterialTheme.typography.labelSmall,
                                color = LabTextSecondary
                            )
                        }
                    }
                }
            }

            // 3. Unknown Samples Calculator Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = LabSurface),
                border = BorderStroke(1.dp, LabBorderColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Header with Title and Red "Clear" TextButton
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Unknown Samples Calculator",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = LabTextPrimary
                            )
                            Text(
                                text = "Select an experiment or enter $activeFeature Response (Y) to quantify concentration.",
                                style = MaterialTheme.typography.bodySmall,
                                color = LabTextSecondary
                            )
                        }
                        TextButton(
                            onClick = {
                                unknownYInput = ""
                                calculatedX = null
                                selectedExperimentId = null
                                selectedExperimentLabel = ""
                                selectedExperimentName = ""
                                unknownSamples = emptyList()
                            },
                            modifier = Modifier.testTag("clear_unknown_samples_button")
                        ) {
                            Text(
                                text = "Clear",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Optional Experiment Picker Dropdown
                    ExposedDropdownMenuBox(
                        expanded = isExperimentDropdownExpanded,
                        onExpandedChange = { if (experiments.isNotEmpty()) isExperimentDropdownExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedExperimentLabel,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Saved Experiment (Optional)") },
                            placeholder = { Text(if (experiments.isEmpty()) "No saved experiments available" else "Choose an experiment...") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExperimentDropdownExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = LabSoftPurple.copy(alpha = 0.35f),
                                unfocusedContainerColor = LabSoftPurple.copy(alpha = 0.2f),
                                focusedBorderColor = LabPrimaryPurple,
                                unfocusedBorderColor = LabBorderColor,
                                focusedTextColor = LabTextPrimary,
                                unfocusedTextColor = LabTextPrimary
                            ),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        if (experiments.isNotEmpty()) {
                            ExposedDropdownMenu(
                                expanded = isExperimentDropdownExpanded,
                                onDismissRequest = { isExperimentDropdownExpanded = false },
                                modifier = Modifier.background(LabSurface)
                            ) {
                                experiments.forEach { exp ->
                                    val yVal = when (activeFeature) {
                                        "Peak Value" -> exp.peakIntensity
                                        "Total AUC" -> exp.totalAuc
                                        "Max Emission AUC" -> exp.maxWindowAuc
                                        else -> exp.maxWindowAuc
                                    }
                                    val label = "${exp.experimentName} ($activeFeature: ${String.format(Locale.US, "%.2f", yVal)})"
                                    DropdownMenuItem(
                                        text = { Text(label, color = LabTextPrimary) },
                                        onClick = {
                                            selectedExperimentId = exp.id
                                            selectedExperimentLabel = label
                                            selectedExperimentName = exp.experimentName
                                            unknownYInput = yVal.toString()
                                            calculatedX = if (result.slope != 0.0) (yVal - result.intercept) / result.slope else null
                                            isExperimentDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Input Row: OutlinedTextField for "Response (Y)" on left + tall "Add Sample" Button on right
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = unknownYInput,
                            onValueChange = {
                                unknownYInput = it
                                selectedExperimentId = null
                                selectedExperimentLabel = if (it.isEmpty()) "" else "Manual Input"
                                selectedExperimentName = if (it.isEmpty()) "" else "Manual Input"
                                val yValue = it.toDoubleOrNull()
                                if (yValue != null && result.slope != 0.0) {
                                    calculatedX = (yValue - result.intercept) / result.slope
                                } else {
                                    calculatedX = null
                                }
                            },
                            label = { Text("Response (Y)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = LabSurface,
                                unfocusedContainerColor = LabSurface,
                                focusedBorderColor = LabPrimaryPurple,
                                unfocusedBorderColor = LabBorderColor,
                                focusedTextColor = LabTextPrimary,
                                unfocusedTextColor = LabTextPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        Button(
                            onClick = {
                                val xVal = calculatedX
                                val yVal = unknownYInput.toDoubleOrNull()
                                if (xVal != null && yVal != null) {
                                    val sampleName = selectedExperimentName.ifBlank { "Sample #${unknownSamples.size + 1}" }
                                    unknownSamples = unknownSamples + UnknownSampleResult(
                                        name = sampleName,
                                        yValue = yVal,
                                        calculatedX = xVal
                                    )
                                    unknownYInput = ""
                                    calculatedX = null
                                    selectedExperimentId = null
                                    selectedExperimentLabel = ""
                                    selectedExperimentName = ""
                                }
                            },
                            enabled = calculatedX != null && unknownYInput.toDoubleOrNull() != null,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = LabPrimaryPurple,
                                contentColor = Color.White,
                                disabledContainerColor = LabBorderColor,
                                disabledContentColor = LabTextSecondary
                            ),
                            modifier = Modifier
                                .height(56.dp)
                                .padding(top = 4.dp)
                                .testTag("add_unknown_to_list_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Add Sample",
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    if (calculatedX != null) {
                        Surface(
                            color = LabSoftPurple,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Estimated Concentration (X) = ${String.format(Locale.US, "%.4f", calculatedX)}${if (concentrationUnit.isNotBlank()) " $concentrationUnit" else ""}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = LabPrimaryPurple,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }

                    if (unknownSamples.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        HorizontalDivider(color = LabBorderColor)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Added Unknown Samples (${unknownSamples.size})",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = LabTextSecondary
                        )
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            unknownSamples.forEachIndexed { index, sample ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = LabSoftPurple.copy(alpha = 0.45f)
                                    ),
                                    border = BorderStroke(1.dp, LabPrimaryPurple.copy(alpha = 0.15f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = sample.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = LabTextPrimary
                                            )
                                            Text(
                                                text = "Y ($activeFeature): ${String.format(Locale.US, "%.4f", sample.yValue)}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = LabTextSecondary
                                            )
                                            Text(
                                                text = "Concentration: ${String.format(Locale.US, "%.4f", sample.calculatedX)}${if (concentrationUnit.isNotBlank()) " $concentrationUnit" else ""}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = LabPrimaryPurple
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                unknownSamples = unknownSamples.filterIndexed { i, _ -> i != index }
                                            },
                                            modifier = Modifier.testTag("delete_unknown_sample_$index")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Delete Unknown Sample",
                                                tint = Color(0xFFDC2626)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Export Button
            Button(
                onClick = { handleExport() },
                enabled = !isExporting,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = LabPrimaryPurple,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.FileDownload,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isExporting) "Exporting Report..." else "Export Calibration Report (CSV/Excel)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
