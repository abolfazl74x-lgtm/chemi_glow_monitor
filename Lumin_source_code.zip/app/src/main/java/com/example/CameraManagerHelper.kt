package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

class CameraManagerHelper(private val context: Context) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    var cameraDevice: CameraDevice? = null
    var captureSession: CameraCaptureSession? = null
    var previewRequestBuilder: CaptureRequest.Builder? = null
    private var imageReader: ImageReader? = null
    
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    
    init {
        startBackgroundThread()
    }
    
    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also {
            it.start()
            backgroundHandler = Handler(it.looper)
        }
    }
    
    fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }

    fun getBackCameraId(): String? {
        return cameraManager.cameraIdList.firstOrNull { id ->
            val chars = cameraManager.getCameraCharacteristics(id)
            val facing = chars.get(CameraCharacteristics.LENS_FACING)
            facing == CameraCharacteristics.LENS_FACING_BACK
        }
    }

    fun getPreviewSize(cameraId: String): android.util.Size {
        return try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val jpegSizes = map?.getOutputSizes(ImageFormat.JPEG)
            val largestJpeg = jpegSizes?.maxByOrNull { it.width * it.height }
            val targetAspect = if (largestJpeg != null && largestJpeg.height > 0) {
                largestJpeg.width.toFloat() / largestJpeg.height.toFloat()
            } else {
                4f / 3f
            }
            val previewSizes = map?.getOutputSizes(android.graphics.SurfaceTexture::class.java)
            if (!previewSizes.isNullOrEmpty()) {
                val matchingAspect = previewSizes.filter { size ->
                    size.height > 0 &&
                        kotlin.math.abs((size.width.toFloat() / size.height.toFloat()) - targetAspect) < 0.05f &&
                        size.width <= 1920 && size.height <= 1920
                }
                (matchingAspect.maxByOrNull { it.width * it.height }
                    ?: previewSizes.filter { it.width <= 1920 && it.height <= 1920 }.maxByOrNull { it.width * it.height }
                    ?: previewSizes.first())
            } else {
                android.util.Size(1440, 1080)
            }
        } catch (e: Exception) {
            android.util.Size(1440, 1080)
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun openCamera(cameraId: String): Boolean = suspendCoroutine { cont ->
        var resumed = false
        try {
            cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    if (!resumed) {
                        resumed = true
                        cont.resume(true)
                    }
                }
                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    cameraDevice = null
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    cameraDevice = null
                    if (!resumed) {
                        resumed = true
                        cont.resume(false)
                    }
                }
            }, backgroundHandler)
        } catch (e: Exception) {
            if (!resumed) {
                resumed = true
                cont.resume(false)
            }
        }
    }
    
    suspend fun startPreview(previewSurface: Surface): Boolean = suspendCoroutine { cont ->
        val camera = cameraDevice ?: return@suspendCoroutine cont.resume(false)
        try {
            val requestBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            requestBuilder.addTarget(previewSurface)
            previewRequestBuilder = requestBuilder
            
            camera.createCaptureSession(listOf(previewSurface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    try {
                        requestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                        session.setRepeatingRequest(requestBuilder.build(), null, backgroundHandler)
                        cont.resume(true)
                    } catch (e: Exception) {
                        cont.resume(false)
                    }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    cont.resume(false)
                }
            }, backgroundHandler)
        } catch (e: Exception) {
            cont.resume(false)
        }
    }

    fun getMinimumFocusDistance(): Float {
        val camera = cameraDevice ?: return 0f
        val chars = cameraManager.getCameraCharacteristics(camera.id)
        return chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    }
    
    fun updatePreviewFocus(distance: Float) {
        val session = captureSession ?: return
        val builder = previewRequestBuilder ?: return
        val minFocus = getMinimumFocusDistance()
        val clampedFocus = if (minFocus > 0f) distance.coerceIn(0f, minFocus) else 0f
        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
        builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, clampedFocus)
        try {
            session.setRepeatingRequest(builder.build(), null, backgroundHandler)
        } catch (e: Exception) {
            Log.e("CameraManagerHelper", "Failed to update focus", e)
        }
    }

    fun updatePreviewParameters(iso: Int, exposureSeconds: Float, focusDistance: Float) {
        val camera = cameraDevice ?: return
        val session = captureSession ?: return
        val builder = previewRequestBuilder ?: return
        try {
            val clampedIso = clampSensitivity(camera.id, iso)
            // Cap live preview shutter at 0.25s so the viewfinder remains responsive while reflecting ISO/exposure changes
            val previewExposureNs = clampExposureNanos(
                camera.id,
                (exposureSeconds.toDouble().coerceAtMost(0.25) * 1_000_000_000.0).toLong()
            )
            val minFocus = getMinimumFocusDistance()
            val clampedFocus = if (minFocus > 0f) focusDistance.coerceIn(0f, minFocus) else 0f

            builder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
            builder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            builder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            builder.set(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_AUTO)
            builder.set(CaptureRequest.SENSOR_SENSITIVITY, clampedIso)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, previewExposureNs)
            builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, clampedFocus)
            session.setRepeatingRequest(builder.build(), null, backgroundHandler)
        } catch (e: Exception) {
            Log.e("CameraManagerHelper", "Failed to update preview parameters", e)
        }
    }

    fun getMaxExposureSeconds(): Float {
        val camera = cameraDevice ?: return 20f
        return try {
            val chars = cameraManager.getCameraCharacteristics(camera.id)
            val range = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
            if (range != null) {
                (range.upper / 1_000_000_000.0).toFloat().coerceAtLeast(0.1f)
            } else {
                20f
            }
        } catch (e: Exception) {
            20f
        }
    }

    private fun clampExposureNanos(cameraId: String, requestedNanos: Long): Long {
        return try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            val range = chars.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
            if (range != null) {
                requestedNanos.coerceIn(range.lower, range.upper)
            } else {
                requestedNanos
            }
        } catch (e: Exception) {
            requestedNanos
        }
    }

    private fun computeFrameDurationNanos(cameraId: String, clampedExposureNs: Long): Long {
        val desiredDuration = clampedExposureNs + 100_000_000L
        return try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            val maxFrameDuration = chars.get(CameraCharacteristics.SENSOR_INFO_MAX_FRAME_DURATION)
            if (maxFrameDuration != null && maxFrameDuration > 0L) {
                desiredDuration.coerceAtMost(maxFrameDuration)
            } else {
                desiredDuration
            }
        } catch (e: Exception) {
            desiredDuration
        }
    }

    private fun clampSensitivity(cameraId: String, requestedIso: Int): Int {
        return try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            val range = chars.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
            if (range != null) {
                requestedIso.coerceIn(range.lower, range.upper)
            } else {
                requestedIso
            }
        } catch (e: Exception) {
            requestedIso
        }
    }

    @Volatile
    private var stopRequested = false

    fun stopCaptureSequence() {
        stopRequested = true
    }

    suspend fun captureSequence(
        previewSurface: Surface,
        outputDir: File,
        numFrames: Int,
        exposureNanos: Long = 4_000_000_000L,
        iso: Int = 800,
        focusDistance: Float = 0f,
        onTelemetry: (actualExposureNs: Long?, actualIso: Int?, hwMaxExposureSec: Float) -> Unit = { _, _, _ -> },
        onProgress: (Int, File) -> Unit
    ): Int = withContext(Dispatchers.IO) {
        stopRequested = false
        val camera = cameraDevice ?: return@withContext 0

        val chars = cameraManager.getCameraCharacteristics(camera.id)
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val sizes = map?.getOutputSizes(ImageFormat.JPEG)
        val largest = sizes?.maxByOrNull { it.width * it.height } ?: return@withContext 0

        val reader = ImageReader.newInstance(largest.width, largest.height, ImageFormat.JPEG, 2)
        imageReader = reader

        val session = suspendCoroutine<CameraCaptureSession?> { cont ->
            try {
                camera.createCaptureSession(listOf(previewSurface, reader.surface), object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        cont.resume(session)
                    }
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        cont.resume(null)
                    }
                }, backgroundHandler)
            } catch (e: Exception) {
                Log.e("CameraManagerHelper", "Failed to create capture session", e)
                cont.resume(null)
            }
        } ?: return@withContext 0

        captureSession = session

        val requestBuilder = try {
            val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            builder.addTarget(reader.surface)
            builder.addTarget(previewSurface)

            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposureNanos)
            builder.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusDistance)
            builder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF)
            builder
        } catch (e: Exception) {
            Log.e("CameraManagerHelper", "Error setting manual parameters", e)
            return@withContext 0
        }

        if (!outputDir.exists()) outputDir.mkdirs()
        else {
            // clear old frames
            outputDir.listFiles()?.forEach { it.delete() }
        }

        var capturedCount = 0
        for (i in 1..numFrames) {
            if (stopRequested) {
                break
            }
            val fileName = String.format("frame_%03d.jpg", i)
            val file = File(outputDir, fileName)

            val imageSaved = suspendCoroutine<Boolean> { cont ->
                var imageAcquired = false
                reader.setOnImageAvailableListener({ ir ->
                    if (imageAcquired) return@setOnImageAvailableListener
                    try {
                        val image: Image? = ir.acquireLatestImage()
                        image?.let {
                            val buffer = it.planes[0].buffer
                            val bytes = ByteArray(buffer.remaining())
                            buffer.get(bytes)

                            FileOutputStream(file).use { out ->
                                out.write(bytes)
                            }
                            it.close()
                            imageAcquired = true
                            cont.resume(true)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, backgroundHandler)

                try {
                    session.capture(requestBuilder.build(), null, backgroundHandler)
                } catch (e: Exception) {
                    if (!imageAcquired) {
                        imageAcquired = true
                        cont.resume(false)
                    }
                }
            }
            if (imageSaved) {
                capturedCount++
                onProgress(i, file)
                if (stopRequested) {
                    break
                }
            } else {
                break
            }
        }

        // clear listener
        reader.setOnImageAvailableListener(null, null)
        reader.close()
        imageReader = null

        // restart preview
        startPreview(previewSurface)

        return@withContext capturedCount
    }

    fun stopCamera() {
        try {
            captureSession?.stopRepeating()
        } catch (e: Exception) {}
        captureSession?.close()
        captureSession = null
        cameraDevice?.close()
        cameraDevice = null
    }

    fun close() {
        captureSession?.close()
        captureSession = null
        cameraDevice?.close()
        cameraDevice = null
        imageReader?.close()
        imageReader = null
        stopBackgroundThread()
    }
}
