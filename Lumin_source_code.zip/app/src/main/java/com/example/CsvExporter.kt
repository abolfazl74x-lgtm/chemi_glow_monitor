package com.example

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.OutputStreamWriter

object CsvExporter {
    /**
     * Exports the analyzed ROI kinetics data to a CSV file in the Downloads folder via MediaStore.
     * Note: [exposureTimeSeconds] is strictly the frame extraction interval used for X-axis math,
     * while [originalExposure] is optional metadata for labeling only.
     */
    suspend fun exportKineticsToCsv(
        context: Context,
        results: List<IntensityResult>,
        exposureTimeSeconds: Float,
        testTitle: String = "Chemi",
        originalExposure: Float? = null
    ): Uri? = withContext(Dispatchers.IO) {
        if (results.isEmpty()) return@withContext null

        try {
            val fileName = "${testTitle}_kinetics_${System.currentTimeMillis()}.csv"

            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
            }

            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)

            uri?.let {
                resolver.openOutputStream(it)?.use { outputStream ->
                    BufferedWriter(OutputStreamWriter(outputStream, Charsets.UTF_8)).use { writer ->
                        if (originalExposure != null) {
                            writer.write("Original Exposure Time: ${originalExposure}s")
                            writer.newLine()
                        }
                        // Header
                        writer.write("Time(s),Intensity")
                        writer.newLine()

                        // Data loop (strictly uses exposureTimeSeconds / interval for X-axis math)
                        results.forEach { result ->
                            val timeSeconds = (result.frameIndex + 1) * exposureTimeSeconds
                            writer.write("$timeSeconds,${result.averageIntensity}")
                            writer.newLine()
                        }
                        writer.flush()
                    }
                }
            }
            uri
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
