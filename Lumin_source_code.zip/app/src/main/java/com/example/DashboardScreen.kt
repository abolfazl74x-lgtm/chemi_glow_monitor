package com.example

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.ExperimentEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: ExperimentViewModel,
    onNewExperiment: () -> Unit,
    onNavigateToCalibration: () -> Unit,
    onNavigateToSavedCalibrations: () -> Unit = {},
    onPickVideo: () -> Unit,
    onBatchImport: () -> Unit,
    onOpenWhiteConstantSettings: () -> Unit = {},
    onExperimentClick: (ExperimentEntity) -> Unit = {}
) {
    val experiments by viewModel.allExperiments.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var experimentToRename by remember { mutableStateOf<ExperimentEntity?>(null) }
    var experimentToDelete by remember { mutableStateOf<ExperimentEntity?>(null) }

    if (experimentToRename != null) {
        TestNamingDialog(
            initialTitle = experimentToRename!!.experimentName,
            showIntervalInput = false,
            onConfirm = { newName, _, _ ->
                if (newName.isNotBlank()) {
                    viewModel.insert(experimentToRename!!.copy(experimentName = newName.trim()))
                }
                experimentToRename = null
            },
            onDismiss = {
                experimentToRename = null
            }
        )
    }

    if (experimentToDelete != null) {
        AlertDialog(
            onDismissRequest = { experimentToDelete = null },
            title = { Text("Delete Experiment") },
            text = {
                Text(
                    "Are you sure you want to delete '${experimentToDelete?.experimentName}'? This action cannot be undone and associated data will be removed from the list."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.delete(experimentToDelete!!.id)
                        experimentToDelete = null
                    },
                    modifier = Modifier.testTag("confirm_delete_experiment_button")
                ) {
                    Text(
                        text = "Delete",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { experimentToDelete = null },
                    modifier = Modifier.testTag("cancel_delete_experiment_button")
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Experiments",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(onClick = onBatchImport) {
                        Icon(Icons.Default.Add, contentDescription = "Batch Import")
                    }
                    IconButton(onClick = onPickVideo) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = "Pick Video from Gallery")
                    }
                    IconButton(onClick = onNavigateToCalibration) {
                        Icon(Icons.Default.Timeline, contentDescription = "Calibration Curve Setup")
                    }
                    IconButton(
                        onClick = onNavigateToSavedCalibrations,
                        modifier = Modifier.testTag("dashboard_saved_calibrations_button")
                    ) {
                        Icon(Icons.Default.Bookmarks, contentDescription = "Saved Calibrations")
                    }
                    IconButton(onClick = {
                        scope.launch {
                            if (experiments.isNotEmpty()) {
                                val uri = MasterCsvExporter.exportMasterCsv(context, experiments)
                                if (uri != null) {
                                    snackbarHostState.showSnackbar("Exported Master CSV to Downloads")
                                } else {
                                    snackbarHostState.showSnackbar("Export failed")
                                }
                            } else {
                                snackbarHostState.showSnackbar("No experiments to export")
                            }
                        }
                    }) {
                        Icon(Icons.Default.Share, contentDescription = "Export All to Master CSV")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewExperiment) {
                Icon(Icons.Default.Add, contentDescription = "New Experiment")
            }
        }
    ) { padding ->
        if (experiments.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_app_logo_1794082435896),
                        contentDescription = "lumin Chemiluminescence Analysis Logo",
                        modifier = Modifier
                            .size(96.dp)
                            .clip(RoundedCornerShape(24.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Text(
                        text = "No experiments yet. Click + to start.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(experiments) { experiment ->
                    ExperimentCard(
                        experiment = experiment,
                        onEditNameClick = { experimentToRename = experiment },
                        onDeleteClick = { experimentToDelete = experiment },
                        onClick = { onExperimentClick(experiment) }
                    )
                }
            }
        }
    }
}

@Composable
fun ExperimentCard(
    experiment: ExperimentEntity,
    onEditNameClick: () -> Unit,
    onDeleteClick: () -> Unit = {},
    onClick: () -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    val dateString = dateFormat.format(Date(experiment.timestamp))

    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("experiment_card_${experiment.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = experiment.experimentName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEditNameClick,
                        modifier = Modifier.testTag("edit_experiment_button_${experiment.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Rename Experiment",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.testTag("delete_experiment_button_${experiment.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Experiment",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Date: $dateString",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Max Emission AUC: ${String.format(Locale.US, "%.2f", experiment.maxWindowAuc)}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )
            if (experiment.originalExposure != null) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Original Exposure Time: ${experiment.originalExposure}s",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
