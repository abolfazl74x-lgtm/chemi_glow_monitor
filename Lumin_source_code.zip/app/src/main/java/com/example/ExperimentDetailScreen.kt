package com.example

import android.content.ContentValues
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.ExperimentEntity
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.compose.chart.line.lineSpec
import com.patrykandpatrick.vico.compose.chart.scroll.rememberChartScrollSpec
import com.patrykandpatrick.vico.core.axis.AxisItemPlacer
import com.patrykandpatrick.vico.core.chart.DefaultPointConnector
import com.patrykandpatrick.vico.core.entry.FloatEntry
import com.patrykandpatrick.vico.core.entry.entryModelOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExperimentDetailScreen(
    experiment: ExperimentEntity,
    onBack: () -> Unit,
    onNavigateToAdvancedAnalysis: ((List<IntensityResult>, Float, String, String) -> Unit)? = null
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val graphicsLayer = rememberGraphicsLayer()

    var dataPoints by remember { mutableStateOf<List<Pair<Double, Double>>>(emptyList()) }
    var isLoadingData by remember { mutableStateOf(true) }
    var isSavingImage by remember { mutableStateOf(false) }
    var isExportingCsv by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
    val dateString = remember(experiment.timestamp) { dateFormat.format(Date(experiment.timestamp)) }

    // Load data from session folder (CSV or frames) or reconstruct curve
    LaunchedEffect(experiment.id) {
        isLoadingData = true
        withContext(Dispatchers.IO) {
            val loadedPoints = mutableListOf<Pair<Double, Double>>()
            val folderPath = experiment.sessionFolderPath

            if (folderPath.isNotBlank()) {
                val sessionDir = File(folderPath)

                // 1. Check for CSV files in session directory
                val potentialCsvFiles = listOf(
                    File(sessionDir, "kinetics.csv"),
                    File(sessionDir, "raw_results.csv"),
                    File(sessionDir, "${experiment.experimentName}_kinetics.csv")
                ) + (sessionDir.listFiles { _, name -> name.endsWith(".csv") }?.toList() ?: emptyList())

                val existingCsv = potentialCsvFiles.firstOrNull { it.exists() && it.length() > 0 }
                if (existingCsv != null) {
                    try {
                        existingCsv.forEachLine { line ->
                            val parts = line.split(",")
                            if (parts.size >= 2) {
                                val time = parts[0].trim().toDoubleOrNull()
                                val intensity = parts[1].trim().toDoubleOrNull()
                                if (time != null && intensity != null) {
                                    loadedPoints.add(Pair(time, intensity))
                                }
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                // 2. If no CSV points, check for frames in sessionDir/frames or sessionDir
                if (loadedPoints.isEmpty()) {
                    val framesDir = File(sessionDir, "frames")
                    val frameFiles = if (framesDir.exists() && framesDir.isDirectory) {
                        framesDir.listFiles { f -> f.extension.lowercase() in listOf("jpg", "jpeg", "png") }
                    } else if (sessionDir.exists() && sessionDir.isDirectory) {
                        sessionDir.listFiles { f -> f.extension.lowercase() in listOf("jpg", "jpeg", "png") }
                    } else null

                    val sortedFrames = frameFiles?.sortedBy { it.name }
                    if (!sortedFrames.isNullOrEmpty()) {
                        try {
                            val firstFrame = sortedFrames.first()
                            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeFile(firstFrame.absolutePath, bounds)
                            val w = if (bounds.outWidth > 0) bounds.outWidth else 640
                            val h = if (bounds.outHeight > 0) bounds.outHeight else 480
                            val rect = Rect(0, 0, w, h)

                            val collectedResults = mutableListOf<IntensityResult>()
                            RoiProcessor.processImagesFlow(sortedFrames, rect).collect { state ->
                                if (state is RoiProcessingState.Success) {
                                    collectedResults.addAll(state.results)
                                }
                            }

                            val expTime = if (experiment.exposureTime > 0) experiment.exposureTime.toDouble() else 1.0
                            collectedResults.forEach { r ->
                                loadedPoints.add(Pair((r.frameIndex + 1) * expTime, r.averageIntensity))
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }

            // 3. Fallback: If no frame/CSV files found, reconstruct curve matching experiment metrics
            if (loadedPoints.isEmpty()) {
                val peakT = if (experiment.peakTime > 0) experiment.peakTime else 5.0
                val peakI = if (experiment.peakIntensity > 0) experiment.peakIntensity else 100.0
                val expTime = if (experiment.exposureTime > 0) experiment.exposureTime.toDouble() else 1.0
                val highDur = if (experiment.highDuration > 0) experiment.highDuration else 10.0
                val totalDuration = maxOf(experiment.maxWindowEndTime, peakT + highDur * 2.5, 30.0)

                val baseline = peakI * 0.05
                var t = 0.0
                while (t <= totalDuration) {
                    val intensity = if (t <= peakT) {
                        val fraction = (t / peakT).coerceIn(0.0, 1.0)
                        baseline + (peakI - baseline) * Math.sin(fraction * Math.PI / 2.0)
                    } else {
                        val elapsed = t - peakT
                        val decayRate = if (highDur > 0) 0.693 / (highDur * 1.5) else 0.1
                        baseline + (peakI - baseline) * Math.exp(-decayRate * elapsed)
                    }
                    loadedPoints.add(Pair(t, intensity))
                    t += expTime
                }
            }

            withContext(Dispatchers.Main) {
                dataPoints = loadedPoints
                isLoadingData = false
            }
        }
    }

    val chartModel = remember(dataPoints) {
        val entries = dataPoints.map {
            FloatEntry(x = it.first.toFloat(), y = it.second.toFloat())
        }
        if (entries.isNotEmpty()) entryModelOf(entries) else null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = experiment.experimentName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = dateString,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("detail_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Experiments"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            scope.launch {
                                isExportingCsv = true
                                val success = exportExperimentReportToCsv(context, experiment, dataPoints)
                                if (success) {
                                    Toast.makeText(context, "Experiment report saved to Downloads folder", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to save report", Toast.LENGTH_LONG).show()
                                }
                                isExportingCsv = false
                            }
                        },
                        enabled = !isExportingCsv,
                        modifier = Modifier.testTag("detail_export_report_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Export Report CSV"
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Kinetics Chart Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("detail_chart_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kinetics Curve",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        IconButton(
                            onClick = {
                                scope.launch {
                                    isSavingImage = true
                                    try {
                                        val bitmap = graphicsLayer.toImageBitmap().asAndroidBitmap()
                                        val uri = ImageExporter.exportBitmapToGallery(context, bitmap)
                                        if (uri != null) {
                                            Toast.makeText(context, "Chart saved to Pictures gallery!", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, "Failed to save chart", Toast.LENGTH_LONG).show()
                                        }
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Error saving chart: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                    isSavingImage = false
                                }
                            },
                            enabled = !isSavingImage && !isLoadingData,
                            modifier = Modifier.testTag("detail_save_chart_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = "Save Chart as PNG",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (isLoadingData) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(250.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    } else if (chartModel != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                                .background(MaterialTheme.colorScheme.surface)
                                .drawWithContent {
                                    graphicsLayer.record {
                                        this@drawWithContent.drawContent()
                                    }
                                    drawContent()
                                }
                                .padding(8.dp)
                        ) {
                            val dataSize = dataPoints.size
                            val dynamicSpacing = kotlin.math.max(1, dataSize / 6)

                            Chart(
                                chart = lineChart(
                                    lines = listOf(
                                        lineSpec(
                                            lineColor = MaterialTheme.colorScheme.primary,
                                            lineBackgroundShader = null,
                                            point = null,
                                            pointConnector = DefaultPointConnector(cubicStrength = 0f)
                                        )
                                    )
                                ),
                                model = chartModel,
                                startAxis = rememberStartAxis(
                                    title = "Intensity",
                                    titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                        color = MaterialTheme.colorScheme.onSurface,
                                        margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(end = 4.dp)
                                    )
                                ),
                                bottomAxis = rememberBottomAxis(
                                    title = "Time (s)",
                                    titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                        color = MaterialTheme.colorScheme.onSurface,
                                        margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(top = 4.dp)
                                    ),
                                    itemPlacer = AxisItemPlacer.Horizontal.default(
                                        spacing = dynamicSpacing,
                                        addExtremeLabelPadding = true
                                    )
                                ),
                                chartScrollSpec = rememberChartScrollSpec(isScrollEnabled = false)
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No chart data available", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // Summary Metrics Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("detail_metrics_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Summary Metrics",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    MetricRow(label = "Peak Intensity", value = String.format(Locale.US, "%.2f", experiment.peakIntensity))
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    MetricRow(label = "Peak Time", value = "${String.format(Locale.US, "%.2f", experiment.peakTime)} s")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    MetricRow(label = "Total AUC", value = String.format(Locale.US, "%.2f", experiment.totalAuc))
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    MetricRow(label = "High Duration", value = "${String.format(Locale.US, "%.2f", experiment.highDuration)} s")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    MetricRow(label = "Max Emission AUC", value = String.format(Locale.US, "%.2f", experiment.maxWindowAuc), isHighlight = true)
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    MetricRow(
                        label = "Max Window Time",
                        value = "${String.format(Locale.US, "%.1f", experiment.maxWindowStartTime)}s – ${String.format(Locale.US, "%.1f", experiment.maxWindowEndTime)}s"
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outlineVariant)

                    MetricRow(label = "Exposure Time", value = "${experiment.exposureTime} s")
                    if (experiment.originalExposure != null) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp), color = MaterialTheme.colorScheme.outlineVariant)
                        MetricRow(
                            label = "Original Exposure Time",
                            value = "${experiment.originalExposure}s"
                        )
                    }
                }
            }

            // Export Actions Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Export Options",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            scope.launch {
                                isExportingCsv = true
                                val success = exportExperimentReportToCsv(context, experiment, dataPoints)
                                if (success) {
                                    Toast.makeText(context, "Full Report (CSV) saved to Downloads folder", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to save CSV", Toast.LENGTH_LONG).show()
                                }
                                isExportingCsv = false
                            }
                        },
                        enabled = !isExportingCsv,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("detail_export_csv_button")
                    ) {
                        Icon(Icons.Default.FileDownload, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isExportingCsv) "Exporting..." else "Export Full Report (CSV)")
                    }

                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                isSavingImage = true
                                try {
                                    val bitmap = graphicsLayer.toImageBitmap().asAndroidBitmap()
                                    val uri = ImageExporter.exportBitmapToGallery(context, bitmap)
                                    if (uri != null) {
                                        Toast.makeText(context, "Chart image saved to Pictures gallery!", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(context, "Failed to save chart", Toast.LENGTH_LONG).show()
                                    }
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Error saving chart: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                }
                                isSavingImage = false
                            }
                        },
                        enabled = !isSavingImage && !isLoadingData,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("detail_save_chart_outline_button")
                    ) {
                        Icon(Icons.Default.Image, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isSavingImage) "Saving Image..." else "Save Chart to Gallery (PNG)")
                    }

                    if (onNavigateToAdvancedAnalysis != null && dataPoints.isNotEmpty()) {
                        FilledTonalButton(
                            onClick = {
                                val rawList = dataPoints.mapIndexed { index, (_, intensity) ->
                                    IntensityResult(frameIndex = index, averageIntensity = intensity)
                                }
                                onNavigateToAdvancedAnalysis(
                                    rawList,
                                    experiment.exposureTime.toFloat(),
                                    experiment.experimentName,
                                    experiment.sessionFolderPath
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("detail_advanced_analysis_button")
                        ) {
                            Icon(Icons.Default.Tune, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Open in Advanced Analysis")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricRow(
    label: String,
    value: String,
    isHighlight: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.SemiBold,
            color = if (isHighlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
        )
    }
}

/**
 * Exports experiment summary and kinetics curve data to a CSV file in the Downloads folder via MediaStore.
 */
private suspend fun exportExperimentReportToCsv(
    context: android.content.Context,
    experiment: ExperimentEntity,
    dataPoints: List<Pair<Double, Double>>
): Boolean = withContext(Dispatchers.IO) {
    try {
        val fileName = "${experiment.experimentName.replace(" ", "_")}_detail_${System.currentTimeMillis()}.csv"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
        }

        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues) ?: return@withContext false

        resolver.openOutputStream(uri)?.use { outputStream ->
            BufferedWriter(OutputStreamWriter(outputStream, Charsets.UTF_8)).use { writer ->
                val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                val dateString = dateFormat.format(Date(experiment.timestamp))

                writer.write("Experiment Name,${experiment.experimentName}")
                writer.newLine()
                writer.write("Date,$dateString")
                writer.newLine()
                writer.write("Exposure Time (s),${experiment.exposureTime}")
                writer.newLine()
                if (experiment.originalExposure != null) {
                    writer.write("Original Exposure Time: ${experiment.originalExposure}s")
                    writer.newLine()
                }
                writer.write("Peak Intensity,${String.format(Locale.US, "%.4f", experiment.peakIntensity)}")
                writer.newLine()
                writer.write("Peak Time (s),${String.format(Locale.US, "%.4f", experiment.peakTime)}")
                writer.newLine()
                writer.write("Total AUC,${String.format(Locale.US, "%.4f", experiment.totalAuc)}")
                writer.newLine()
                writer.write("High Duration (s),${String.format(Locale.US, "%.4f", experiment.highDuration)}")
                writer.newLine()
                writer.write("Max Emission AUC,${String.format(Locale.US, "%.4f", experiment.maxWindowAuc)}")
                writer.newLine()
                writer.write("Max Window Start (s),${String.format(Locale.US, "%.4f", experiment.maxWindowStartTime)}")
                writer.newLine()
                writer.write("Max Window End (s),${String.format(Locale.US, "%.4f", experiment.maxWindowEndTime)}")
                writer.newLine()
                if (experiment.sessionFolderPath.isNotBlank()) {
                    writer.write("Session Path,${experiment.sessionFolderPath}")
                    writer.newLine()
                }

                writer.newLine()
                writer.write("--- Kinetics Curve Data ---")
                writer.newLine()
                writer.write("Time (s),Intensity")
                writer.newLine()

                dataPoints.forEach { point ->
                    writer.write("${point.first},${point.second}")
                    writer.newLine()
                }

                writer.flush()
            }
        }
        true
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}
