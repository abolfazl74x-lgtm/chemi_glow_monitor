package com.example

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExperimentSessionManager {
    /**
     * Creates a unique session directory in the internal filesDir.
     * Format: filesDir/Experiment_YYYYMMDD_HHMMSS/
     */
    fun createNewSessionDir(context: Context): File {
        val formatter = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
        val timestamp = formatter.format(Date())
        val dirName = "Experiment_$timestamp"
        val sessionDir = File(context.filesDir, dirName)
        if (!sessionDir.exists()) {
            sessionDir.mkdirs()
        }
        return sessionDir
    }
}
