package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CalibrationDao
import com.example.data.CalibrationEntity
import com.example.data.ExperimentEntity
import com.example.data.ExperimentRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ExperimentViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ExperimentRepository
    private val calibrationDao: CalibrationDao
    val allExperiments: StateFlow<List<ExperimentEntity>>
    val savedCalibrations: StateFlow<List<CalibrationEntity>>

    init {
        val database = AppDatabase.getDatabase(application)
        val dao = database.experimentDao()
        calibrationDao = database.calibrationDao()
        repository = ExperimentRepository(dao, calibrationDao)
        allExperiments = repository.allExperiments.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        savedCalibrations = calibrationDao.getAllCalibrations().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    fun insert(experiment: ExperimentEntity) = viewModelScope.launch {
        repository.insertExperiment(experiment)
    }

    fun delete(id: Int) = viewModelScope.launch {
        repository.deleteExperimentById(id)
    }

    fun insertCalibration(calibration: CalibrationEntity) = viewModelScope.launch {
        repository.insertCalibration(calibration)
    }

    fun deleteCalibration(calibration: CalibrationEntity) = viewModelScope.launch {
        repository.deleteCalibration(calibration)
    }
}
