package com.example

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile

object FileUtil {
    // Kept to maintain compatibility with existing call sites
    fun extractOriginalFilename(context: Context, uri: Uri): String {
        return getRealFileName(context, uri)
    }

    fun getRealFileName(context: Context, uri: Uri): String {
        var result: String? = null
        
        // 1. Primary Attempt: DocumentFile
        try {
            result = DocumentFile.fromSingleUri(context, uri)?.name
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2. Secondary Attempt: Cursor with MediaStore.MediaColumns.DISPLAY_NAME
        if (result == null && uri.scheme == "content") {
            try {
                context.contentResolver.query(
                    uri, 
                    arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), 
                    null, null, null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                        if (index != -1) {
                            result = cursor.getString(index)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 3. String Manipulation: Remove extension
        if (result != null) {
            val dotIndex = result!!.lastIndexOf('.')
            if (dotIndex > 0) {
                result = result!!.substring(0, dotIndex)
            }
        }

        // 4. Fallback: Check if purely numeric or null/blank
        val isNumeric = result?.matches(Regex("\\d+")) ?: false
        if (result.isNullOrBlank() || isNumeric) {
            return "Imported_Video_${System.currentTimeMillis()}"
        }

        return result!!
    }
}
