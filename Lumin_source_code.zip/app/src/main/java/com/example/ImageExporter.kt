package com.example

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object ImageExporter {
    /**
     * Exports a Bitmap (screenshot) to the Android MediaStore (Pictures directory).
     * Safely compatible with Android 10+ Scoped Storage.
     */
    suspend fun exportBitmapToGallery(
        context: Context,
        bitmap: Bitmap
    ): Uri? = withContext(Dispatchers.IO) {
        try {
            val timestamp = System.currentTimeMillis()
            val fileName = "Kinetics_Chart_$timestamp.png"
            val resolver = context.contentResolver
            var resultUri: Uri? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES)
                }

                val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                resultUri = resolver.insert(collection, contentValues)

                resultUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                if (!picturesDir.exists()) {
                    picturesDir.mkdirs()
                }
                val file = File(picturesDir, fileName)
                file.outputStream().use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                resultUri = Uri.fromFile(file)
            }

            resultUri
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
