package com.example

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.pow

data class CalibrationStandard(
    val name: String,
    val concentration: Double,
    val peakValue: Double,
    val totalAuc: Double,
    val maxEmissionAuc: Double
) {
    fun getValueForFeature(featureName: String): Double {
        return when (featureName) {
            "Peak Value" -> peakValue
            "Total AUC" -> totalAuc
            "Max Emission AUC" -> maxEmissionAuc
            else -> totalAuc
        }
    }
}

object CalibrationStandardJsonHelper {
    fun toJson(standards: List<CalibrationStandard>): String {
        val array = JSONArray()
        for (std in standards) {
            val obj = JSONObject().apply {
                put("name", std.name)
                put("concentration", std.concentration)
                put("peakValue", std.peakValue)
                put("totalAuc", std.totalAuc)
                put("maxEmissionAuc", std.maxEmissionAuc)
            }
            array.put(obj)
        }
        return array.toString()
    }

    fun fromJson(json: String): List<CalibrationStandard> {
        if (json.isBlank()) return emptyList()
        return try {
            val array = JSONArray(json)
            val list = mutableListOf<CalibrationStandard>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    CalibrationStandard(
                        name = obj.optString("name", "Standard ${i + 1}"),
                        concentration = obj.optDouble("concentration", 0.0),
                        peakValue = obj.optDouble("peakValue", 0.0),
                        totalAuc = obj.optDouble("totalAuc", 0.0),
                        maxEmissionAuc = obj.optDouble("maxEmissionAuc", 0.0)
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }
}

data class CalibrationResult(
    val slope: Double,
    val intercept: Double,
    val rSquared: Double,
    val points: List<Pair<Double, Double>>
)

object LinearRegressionHelper {
    /**
     * Calculates Simple Linear Regression for a list of [CalibrationStandard] and a given Y-axis feature.
     */
    fun calculateForStandards(
        standards: List<CalibrationStandard>,
        featureName: String
    ): CalibrationResult? {
        val points = standards.map { std ->
            std.concentration to std.getValueForFeature(featureName)
        }
        return calculate(points)
    }

    /**
     * Calculates Simple Linear Regression from a list of (X, Y) points.
     * X = Standard Concentration
     * Y = Analytical Feature (e.g., Peak Value)
     *
     * @param points List of (X, Y) pairs
     * @return CalibrationResult containing slope (m), intercept (b), R-squared (R^2) and original points.
     *         Returns null if less than 2 points are provided or if variance in X is 0.
     */
    fun calculate(points: List<Pair<Double, Double>>): CalibrationResult? {
        val n = points.size
        if (n < 2) return null

        var sumX = 0.0
        var sumY = 0.0
        var sumXY = 0.0
        var sumX2 = 0.0

        for ((x, y) in points) {
            sumX += x
            sumY += y
            sumXY += x * y
            sumX2 += x * x
        }

        val denominator = (n * sumX2) - (sumX * sumX)
        // Prevent division by zero if all X values are exactly the same
        if (denominator == 0.0) return null

        // Calculate slope (m) and y-intercept (b)
        val slope = ((n * sumXY) - (sumX * sumY)) / denominator
        val intercept = (sumY - slope * sumX) / n

        // Calculate R-squared (Coefficient of Determination)
        // R^2 = 1 - (SSres / SStot)
        val meanY = sumY / n
        var ssTot = 0.0
        var ssRes = 0.0

        for ((x, y) in points) {
            val predictedY = slope * x + intercept
            ssTot += (y - meanY).pow(2)
            ssRes += (y - predictedY).pow(2)
        }

        val rSquared = if (ssTot == 0.0) {
            1.0 // Perfect correlation if there is no variance in Y and it perfectly matches the line
        } else {
            1.0 - (ssRes / ssTot)
        }

        return CalibrationResult(
            slope = slope,
            intercept = intercept,
            rSquared = rSquared,
            points = points
        )
    }
}
