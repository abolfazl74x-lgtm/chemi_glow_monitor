@file:Suppress("DEPRECATION")
package com.example

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.text.input.KeyboardType
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.core.entry.entryModelOf
import com.patrykandpatrick.vico.core.entry.FloatEntry
import com.patrykandpatrick.vico.compose.chart.line.lineSpec
import com.patrykandpatrick.vico.compose.chart.scroll.rememberChartScrollSpec
import com.patrykandpatrick.vico.core.axis.AxisItemPlacer
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.asAndroidBitmap
import android.graphics.BitmapFactory
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material.icons.filled.Close
import com.example.ui.theme.MyApplicationTheme
import com.google.accompanist.permissions.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

import androidx.activity.compose.BackHandler
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ExperimentEntity

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val scope = rememberCoroutineScope()
                val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)
                var currentRoute by rememberSaveable { mutableStateOf("dashboard") }
                val viewModel: ExperimentViewModel = viewModel()
                var calibrationStandards by remember { mutableStateOf<List<CalibrationStandard>>(emptyList()) }
                var calibrationFeature by rememberSaveable { mutableStateOf("Total AUC") }
                var calibrationUnit by rememberSaveable { mutableStateOf("mg/L") }
                var calibrationResult by remember { mutableStateOf<CalibrationResult?>(null) }
                var extractedVideoFrames by remember { mutableStateOf<List<java.io.File>>(emptyList()) }
                var currentTestTitle by rememberSaveable { mutableStateOf("") }
                var currentExposureTime by remember { mutableFloatStateOf(1f) }
                var currentOriginalExposure by remember { mutableStateOf<Float?>(null) }
                var showImportNamingDialog by remember { mutableStateOf(false) }
                var pendingImportFiles by remember { mutableStateOf<List<java.io.File>>(emptyList()) }
                var pendingDefaultTitle by remember { mutableStateOf("") }
                var isFromBatchImport by remember { mutableStateOf(false) }
                
                var advancedAnalysisRawData by remember { mutableStateOf<List<IntensityResult>?>(null) }
                var advancedAnalysisExposureTime by remember { mutableStateOf(1f) }
                var advancedAnalysisOriginalExposure by remember { mutableStateOf<Float?>(null) }
                var advancedAnalysisTestTitle by remember { mutableStateOf("") }
                var advancedAnalysisSessionPath by remember { mutableStateOf("") }
                var selectedExperimentDetail by remember { mutableStateOf<ExperimentEntity?>(null) }
                
                if (showImportNamingDialog) {
                    TestNamingDialog(
                        initialTitle = pendingDefaultTitle,
                        showIntervalInput = true,
                        isVideoImport = !isFromBatchImport,
                        onConfirm = { name, interval, origExposure ->
                            showImportNamingDialog = false
                            currentTestTitle = name
                            currentExposureTime = interval
                            currentOriginalExposure = origExposure
                            extractedVideoFrames = pendingImportFiles
                            currentRoute = "video_analysis"

                            if (isFromBatchImport) {
                                val sessionDir = pendingImportFiles.firstOrNull()?.parentFile?.parentFile
                                if (sessionDir != null) {
                                    val videoFile = java.io.File(sessionDir, "${name}.mp4")
                                    val framesDir = java.io.File(sessionDir, "frames")
                                    
                                    scope.launch {
                                        VideoEncoder.encodeImagesToVideoFlow(
                                            imageDir = framesDir,
                                            outputFile = videoFile,
                                            totalFrames = pendingImportFiles.size,
                                            exposureTimeSeconds = interval
                                        ).collect { state ->
                                            when (state) {
                                                is EncodingState.Success -> {
                                                    android.widget.Toast.makeText(this@MainActivity, "Video Encoding Complete!", android.widget.Toast.LENGTH_SHORT).show()
                                                }
                                                is EncodingState.Error -> {
                                                    android.util.Log.e("BatchImport", "Video encoding failed: ${state.message}")
                                                }
                                                else -> {}
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        onDismiss = {
                            showImportNamingDialog = false
                        }
                    )
                }

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        if (selectedExperimentDetail != null) {
                            ExperimentDetailScreen(
                                experiment = selectedExperimentDetail!!,
                                onBack = { selectedExperimentDetail = null },
                                onNavigateToAdvancedAnalysis = { data, exposure, title, path ->
                                    advancedAnalysisRawData = data
                                    advancedAnalysisExposureTime = exposure
                                    advancedAnalysisOriginalExposure = selectedExperimentDetail?.originalExposure
                                    advancedAnalysisTestTitle = title
                                    advancedAnalysisSessionPath = path
                                    selectedExperimentDetail = null
                                    currentRoute = "advanced_analysis"
                                }
                            )
                        } else if (currentRoute == "dashboard") {
                            DashboardScreen(
                                viewModel = viewModel,
                                onNewExperiment = {
                                    if (cameraPermissionState.status.isGranted) {
                                        currentRoute = "camera"
                                    } else {
                                        cameraPermissionState.launchPermissionRequest()
                                    }
                                },
                                onNavigateToCalibration = {
                                    currentRoute = "calibration_setup"
                                },
                                onNavigateToSavedCalibrations = {
                                    currentRoute = "saved_calibrations"
                                },
                                onPickVideo = {
                                    currentRoute = "video_picker"
                                },
                                onBatchImport = {
                                    currentRoute = "batch_import"
                                },
                                onExperimentClick = { experiment ->
                                    selectedExperimentDetail = experiment
                                }
                            )
                        } else if (currentRoute == "batch_import") {
                            BatchImportScreen(
                                onBack = { currentRoute = "dashboard" },
                                onImportComplete = { files, title ->
                                    pendingImportFiles = files
                                    pendingDefaultTitle = title
                                    isFromBatchImport = true
                                    showImportNamingDialog = true
                                }
                            )
                        } else if (currentRoute == "camera") {
                            if (cameraPermissionState.status.isGranted) {
                                CameraScreen(
                                    onBack = { currentRoute = "dashboard" },
                                    onSaveExperiment = { exp ->
                                        viewModel.insert(exp)
                                        currentRoute = "dashboard"
                                    },
                                    onNavigateToAdvancedAnalysis = { data, exposure, title, path ->
                                        advancedAnalysisRawData = data
                                        advancedAnalysisExposureTime = exposure
                                        advancedAnalysisOriginalExposure = null
                                        advancedAnalysisTestTitle = title
                                        advancedAnalysisSessionPath = path
                                        currentRoute = "advanced_analysis"
                                    }
                                )
                            } else {
                                PermissionRationale(
                                    onRequestPermission = { cameraPermissionState.launchPermissionRequest() }
                                )
                            }
                        } else if (currentRoute == "video_picker") {
                            VideoPickerScreen(
                                onBack = { currentRoute = "dashboard" },
                                onFramesExtracted = { files, title, interval, origExposure ->
                                    extractedVideoFrames = files
                                    currentTestTitle = title
                                    currentExposureTime = interval
                                    currentOriginalExposure = origExposure
                                    currentRoute = "video_analysis"
                                }
                            )
                        } else if (currentRoute == "video_analysis") {
                            VideoAnalysisScreen(
                                files = extractedVideoFrames,
                                testTitle = currentTestTitle,
                                exposureTime = currentExposureTime,
                                originalExposure = currentOriginalExposure,
                                onBack = { currentRoute = "dashboard" },
                                onSaveExperiment = { exp ->
                                    viewModel.insert(exp)
                                    currentRoute = "dashboard"
                                },
                                onNavigateToAdvancedAnalysis = { data, exposure, title, path, origExposure ->
                                    advancedAnalysisRawData = data
                                    advancedAnalysisExposureTime = exposure
                                    advancedAnalysisOriginalExposure = origExposure
                                    advancedAnalysisTestTitle = title
                                    advancedAnalysisSessionPath = path
                                    currentRoute = "advanced_analysis"
                                }
                            )
                        } else if (currentRoute == "calibration_setup") {
                            CalibrationCurveSetupScreen(
                                viewModel = viewModel,
                                onBack = { currentRoute = "dashboard" },
                                onGenerate = { standards, feature, unit ->
                                    val result = LinearRegressionHelper.calculateForStandards(standards, feature)
                                    if (result != null) {
                                        calibrationStandards = standards
                                        calibrationResult = result
                                        calibrationFeature = feature
                                        calibrationUnit = unit
                                        currentRoute = "calibration_result"
                                    }
                                }
                            )
                        } else if (currentRoute == "calibration_result") {
                            if (calibrationStandards.isNotEmpty() || calibrationResult != null) {
                                val allExperiments by viewModel.allExperiments.collectAsState()
                                CalibrationResultScreen(
                                    standards = calibrationStandards,
                                    initialFeature = calibrationFeature,
                                    concentrationUnit = calibrationUnit,
                                    experiments = allExperiments,
                                    fallbackResult = calibrationResult,
                                    onSaveCalibration = { cal ->
                                        viewModel.insertCalibration(cal)
                                    },
                                    onBack = { currentRoute = "dashboard" }
                                )
                            }
                        } else if (currentRoute == "saved_calibrations") {
                            SavedCalibrationsScreen(
                                viewModel = viewModel,
                                onOpenCalibration = { savedCal ->
                                    val deserializedStandards = CalibrationStandardJsonHelper.fromJson(savedCal.standardPointsJson)
                                    calibrationStandards = deserializedStandards
                                    calibrationFeature = savedCal.featureName
                                    calibrationUnit = savedCal.unit
                                    calibrationResult = CalibrationResult(
                                        slope = savedCal.slope,
                                        intercept = savedCal.intercept,
                                        rSquared = savedCal.rSquared,
                                        points = deserializedStandards.map {
                                            it.concentration to it.getValueForFeature(savedCal.featureName)
                                        }
                                    )
                                    currentRoute = "calibration_result"
                                },
                                onBack = { currentRoute = "dashboard" }
                            )
                        } else if (currentRoute == "advanced_analysis") {
                            AdvancedAnalysisScreen(
                                rawResults = advancedAnalysisRawData,
                                exposureTime = advancedAnalysisExposureTime,
                                testTitle = advancedAnalysisTestTitle,
                                sessionFolderPath = advancedAnalysisSessionPath,
                                originalExposure = advancedAnalysisOriginalExposure,
                                onBack = { currentRoute = "dashboard" },
                                onSaveExperiment = { exp ->
                                    viewModel.insert(exp)
                                    currentRoute = "dashboard"
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionRationale(onRequestPermission: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.Warning, contentDescription = "Warning", modifier = Modifier.size(64.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("Camera permission is required for lumin.")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onRequestPermission) {
            Text("Grant Permission")
        }
    }
}

enum class ActiveCameraSetting { ISO, EXPOSURE, FOCUS, FRAMES }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit,
    onNavigateToAdvancedAnalysis: (List<IntensityResult>, Float, String, String) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    DisposableEffect(Unit) {
        // Keep the screen on when this composable enters the composition
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        onDispose {
            // Clear the flag when the user leaves the camera screen to save battery
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    val prefs = remember { context.getSharedPreferences("CameraSettingsPrefs", android.content.Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val cameraManagerHelper = remember { CameraManagerHelper(context) }
    
    BackHandler { onBack() }
    
    var activeSetting by remember { mutableStateOf<ActiveCameraSetting?>(null) }
    var isCapturing by remember { mutableStateOf(false) }
    var isEncoding by remember { mutableStateOf(false) }
    var captureProgress by remember { mutableStateOf(0) }
    var encodingProgress by remember { mutableStateOf(0) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var outputVideo by remember { mutableStateOf<File?>(null) }
    var selectedIso by rememberSaveable { mutableFloatStateOf(prefs.getFloat("iso", 800f)) }
    var selectedExposure by rememberSaveable { mutableFloatStateOf(prefs.getFloat("exposure", 1f).coerceIn(0.1f, 20f)) }
    var maxFocusDistance by rememberSaveable { mutableFloatStateOf(0f) }
    var selectedFocusDistance by rememberSaveable { mutableFloatStateOf(prefs.getFloat("focus", 0f)) }
    var totalFramesText by rememberSaveable { mutableStateOf(prefs.getString("frames", "5") ?: "5") }
    
    val totalFrames = totalFramesText.toIntOrNull()?.coerceAtLeast(1) ?: 1
    var latestCapturedBitmap by remember { mutableStateOf<ImageBitmap?>(null) }
    var actualCapturedFrames by remember { mutableIntStateOf(0) }
    
    var showRoiSelector by remember { mutableStateOf(false) }
    var isProcessingRoi by remember { mutableStateOf(false) }
    var roiProcessingProgress by remember { mutableStateOf(0) }
    var roiResults by remember { mutableStateOf<List<IntensityResult>?>(null) }
    
    var previewSurface by remember { mutableStateOf<android.view.Surface?>(null) }
    

    var currentSessionDir by remember { mutableStateOf<File?>(null) }
    var showNamingDialog by remember { mutableStateOf(false) }
    var testTitle by remember { mutableStateOf("") }
    
    if (showNamingDialog) {
        TestNamingDialog(
            showIntervalInput = false,
            onConfirm = { name, _, _ ->
                showNamingDialog = false
                testTitle = name
                
                scope.launch {
                    isEncoding = true
                    encodingProgress = 0
                    val sessionDir = currentSessionDir!!
                    val outputDir = File(sessionDir, "frames")
                    val videoFile = File(sessionDir, "${name}.mp4")
                    
                    VideoEncoder.encodeImagesToVideoFlow(
                        imageDir = outputDir,
                        outputFile = videoFile,
                        totalFrames = actualCapturedFrames,
                        exposureTimeSeconds = selectedExposure
                    ).collect { state ->
                        when (state) {
                            is EncodingState.Progress -> {
                                encodingProgress = state.percent
                            }
                            is EncodingState.Success -> {
                                isEncoding = false
                                outputVideo = state.file
                            }
                            is EncodingState.Error -> {
                                isEncoding = false
                                errorMessage = "Video encoding failed: ${state.message}"
                            }
                        }
                    }
                }
            },
            onDismiss = {
                showNamingDialog = false
                errorMessage = "Capture sequence completed, but video encoding was cancelled."
            }
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            cameraManagerHelper.close()
        }
    }
    
    LaunchedEffect(selectedIso, selectedExposure, selectedFocusDistance, previewSurface, isCapturing) {
        if (previewSurface != null && !isCapturing) {
            cameraManagerHelper.updatePreviewParameters(
                iso = selectedIso.toInt(),
                exposureSeconds = selectedExposure,
                focusDistance = selectedFocusDistance
            )
        }
    }
    
    var showChartDialog by remember { mutableStateOf(false) }
    
    if (showChartDialog && roiResults != null) {
        val graphicsLayer = rememberGraphicsLayer()
        var isSavingImage by remember { mutableStateOf(false) }
        var imageSaveMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChartDialog = false },
            title = { Text("Kinetics Curve") },
            text = {
                Column {
                    if (imageSaveMessage != null) {
                        Text(
                            text = imageSaveMessage!!,
                            color = if (imageSaveMessage!!.contains("Failed") || imageSaveMessage!!.contains("Error")) Color.Red else Color.Green,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    val chartEntryModel = remember(roiResults) {
                        val entries = roiResults!!.map { 
                            FloatEntry(x = ((it.frameIndex + 1) * selectedExposure).toFloat(), y = it.averageIntensity.toFloat()) 
                        }
                        entryModelOf(entries)
                    }
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .background(MaterialTheme.colorScheme.surface) // Solid background for the exported PNG
                            .drawWithContent {
                                graphicsLayer.record {
                                    this@drawWithContent.drawContent()
                                }
                                drawContent()
                            }
                    ) {
                        val dataSize = roiResults?.size ?: 1
                        val dynamicSpacing = kotlin.math.max(1, dataSize / 6)

                        Chart(
                            chart = lineChart(
                                lines = listOf(lineSpec(
                                    lineColor = MaterialTheme.colorScheme.primary,
                                    point = null,
                                    pointConnector = com.patrykandpatrick.vico.core.chart.DefaultPointConnector(cubicStrength = 0f)
                                ))
                            ),
                            model = chartEntryModel,
                            startAxis = rememberStartAxis(
                                title = "Intensity",
                                titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(end = 4.dp)
                                )
                            ),
                            bottomAxis = rememberBottomAxis(
                                title = "Time (s)",
                                titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(top = 4.dp)
                                ),
                                itemPlacer = AxisItemPlacer.Horizontal.default(
                                    spacing = dynamicSpacing,
                                    addExtremeLabelPadding = true
                                )
                            ),
                            chartScrollSpec = rememberChartScrollSpec(isScrollEnabled = false)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showChartDialog = false }) {
                    Text("Close")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            isSavingImage = true
                            try {
                                val bitmap = graphicsLayer.toImageBitmap().asAndroidBitmap()
                                val uri = ImageExporter.exportBitmapToGallery(context, bitmap)
                                imageSaveMessage = if (uri != null) "Chart saved to MediaStore!" else "Failed to save chart"
                            } catch (e: Exception) {
                                imageSaveMessage = "Error: ${e.localizedMessage}"
                            }
                            isSavingImage = false
                        }
                    },
                    enabled = !isSavingImage
                ) {
                    Text(if (isSavingImage) "Saving..." else "Save as PNG")
                }
            }
        )
    }



    if (showRoiSelector && currentSessionDir != null) {
        val framesDir = File(currentSessionDir, "frames")
        val frames = (1..actualCapturedFrames).map { File(framesDir, String.format("frame_%03d.jpg", it)) }.filter { it.exists() }
        RoiSelector(
            imageFiles = frames,
            onRoiConfirmed = { rect ->
                showRoiSelector = false
                isProcessingRoi = true
                roiResults = null
                scope.launch {
                    RoiProcessor.processImagesFlow(frames, rect).collect { state ->
                        when (state) {
                            is RoiProcessingState.Progress -> roiProcessingProgress = state.percent
                            is RoiProcessingState.Success -> {
                                isProcessingRoi = false
                                roiResults = state.results
                                showChartDialog = true
                            }
                            is RoiProcessingState.Error -> {
                                isProcessingRoi = false
                                errorMessage = "ROI Processing failed: ${state.message}"
                            }
                        }
                    }
                }
            },
            onCancel = { showRoiSelector = false }
        )
        return
    }
    
    var previewSize by remember { mutableStateOf(android.util.Size(1440, 1080)) }

    fun configureTransform(
        textureView: android.view.TextureView,
        viewWidth: Int,
        viewHeight: Int,
        bufferSize: android.util.Size
    ) {
        if (viewWidth <= 0 || viewHeight <= 0 || bufferSize.width <= 0 || bufferSize.height <= 0) return
        val rotation = activity?.windowManager?.defaultDisplay?.rotation ?: android.view.Surface.ROTATION_0
        val matrix = android.graphics.Matrix()
        val viewRect = android.graphics.RectF(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat())
        val bufferRect = android.graphics.RectF(0f, 0f, bufferSize.height.toFloat(), bufferSize.width.toFloat())
        val centerX = viewRect.centerX()
        val centerY = viewRect.centerY()

        if (android.view.Surface.ROTATION_90 == rotation || android.view.Surface.ROTATION_270 == rotation) {
            bufferRect.offset(centerX - bufferRect.centerX(), centerY - bufferRect.centerY())
            matrix.setRectToRect(viewRect, bufferRect, android.graphics.Matrix.ScaleToFit.FILL)
            val scale = kotlin.math.min(
                viewHeight.toFloat() / bufferSize.height.toFloat(),
                viewWidth.toFloat() / bufferSize.width.toFloat()
            )
            matrix.postScale(scale, scale, centerX, centerY)
            matrix.postRotate(90f * (rotation - 2), centerX, centerY)
        } else {
            val previewW = bufferSize.height.toFloat()
            val previewH = bufferSize.width.toFloat()
            val scale = kotlin.math.min(viewWidth.toFloat() / previewW, viewHeight.toFloat() / previewH)
            val scaleX = (previewW * scale) / viewWidth.toFloat()
            val scaleY = (previewH * scale) / viewHeight.toFloat()
            matrix.postScale(scaleX, scaleY, centerX, centerY)
            if (android.view.Surface.ROTATION_180 == rotation) {
                matrix.postRotate(180f, centerX, centerY)
            }
        }
        textureView.setTransform(matrix)
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                android.view.TextureView(ctx).apply {
                    surfaceTextureListener = object : android.view.TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(
                            texture: android.graphics.SurfaceTexture,
                            width: Int,
                            height: Int
                        ) {
                            val tv = this@apply
                            scope.launch {
                                val id = cameraManagerHelper.getBackCameraId()
                                if (id != null) {
                                    val chosenSize = cameraManagerHelper.getPreviewSize(id)
                                    previewSize = chosenSize
                                    texture.setDefaultBufferSize(chosenSize.width, chosenSize.height)
                                    configureTransform(tv, width, height, chosenSize)
                                    val surface = android.view.Surface(texture)
                                    previewSurface = surface
                                    val opened = cameraManagerHelper.openCamera(id)
                                    if (opened) {
                                        maxFocusDistance = cameraManagerHelper.getMinimumFocusDistance()
                                        val savedExposure = prefs.getFloat("exposure", selectedExposure)
                                        selectedExposure = savedExposure.coerceIn(0.1f, 20f)
                                        val savedIso = prefs.getFloat("iso", selectedIso)
                                        selectedIso = savedIso.coerceIn(100f, 3200f)
                                        val savedFocus = prefs.getFloat("focus", selectedFocusDistance)
                                        selectedFocusDistance = if (maxFocusDistance > 0f) {
                                            savedFocus.coerceIn(0f, maxFocusDistance)
                                        } else {
                                            savedFocus
                                        }
                                        cameraManagerHelper.startPreview(surface)
                                        cameraManagerHelper.updatePreviewParameters(
                                            iso = selectedIso.toInt(),
                                            exposureSeconds = selectedExposure,
                                            focusDistance = selectedFocusDistance
                                        )
                                    } else {
                                        errorMessage = "Failed to open camera."
                                    }
                                } else {
                                    errorMessage = "No back camera found."
                                }
                            }
                        }

                        override fun onSurfaceTextureSizeChanged(
                            texture: android.graphics.SurfaceTexture,
                            width: Int,
                            height: Int
                        ) {
                            texture.setDefaultBufferSize(previewSize.width, previewSize.height)
                            configureTransform(this@apply, width, height, previewSize)
                        }

                        override fun onSurfaceTextureDestroyed(texture: android.graphics.SurfaceTexture): Boolean {
                            cameraManagerHelper.stopCamera()
                            previewSurface?.release()
                            previewSurface = null
                            return true
                        }

                        override fun onSurfaceTextureUpdated(texture: android.graphics.SurfaceTexture) {}
                    }
                }
            },
            update = { tv ->
                if (tv.width > 0 && tv.height > 0) {
                    configureTransform(tv, tv.width, tv.height, previewSize)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (isCapturing && latestCapturedBitmap != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = latestCapturedBitmap!!,
                    contentDescription = "Last captured frame",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 16.dp, end = 16.dp)
                ) {
                    Text(
                        text = "Last Captured Frame: #$captureProgress",
                        color = Color.White,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
        
        if (errorMessage != null) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.9f), 
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 64.dp, start = 16.dp, end = 16.dp),
                shape = MaterialTheme.shapes.medium
            ) {
                Text(
                    text = errorMessage!!, 
                    color = MaterialTheme.colorScheme.onErrorContainer, 
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
        
        // Compact, slim bottom-docked progress pill for capturing / encoding without blocking the frame
        if (isCapturing || isEncoding) {
            Surface(
                color = Color.Black.copy(alpha = 0.72f),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .widthIn(max = 460.dp)
                    .fillMaxWidth()
            ) {
                if (isCapturing) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = String.format(
                                    "Exposing frame %d of %d (%.1fs shutter)...",
                                    (captureProgress + 1).coerceAtMost(totalFrames),
                                    totalFrames,
                                    selectedExposure
                                ),
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(5.dp))
                            LinearProgressIndicator(
                                progress = if (totalFrames > 0) captureProgress.toFloat() / totalFrames else 0f,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = Color.DarkGray
                            )
                        }
                        Button(
                            onClick = {
                                cameraManagerHelper.stopCaptureSequence()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error,
                                contentColor = MaterialTheme.colorScheme.onError
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Stop Capture", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Stop", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                } else if (isEncoding) {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Stitching frames into video ($encodingProgress%)...",
                            color = Color.White,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(modifier = Modifier.height(5.dp))
                        LinearProgressIndicator(
                            progress = encodingProgress / 100f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = Color.DarkGray
                        )
                    }
                }
            }
        }

        // Two-Layer DSLR Interface aligned to BottomCenter
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (!isCapturing && !isEncoding) {
                // Top Layer: Contextual Menu Card for the active setting
                AnimatedVisibility(visible = activeSetting != null) {
                    val setting = activeSetting
                    if (setting != null) {
                        Card(
                            modifier = Modifier
                                .widthIn(max = 440.dp)
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color.Black.copy(alpha = 0.7f)
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val headerText = when (setting) {
                                        ActiveCameraSetting.ISO -> "ISO Sensitivity: ${selectedIso.toInt()}"
                                        ActiveCameraSetting.EXPOSURE -> String.format("Exposure Time: %.1f seconds", selectedExposure)
                                        ActiveCameraSetting.FOCUS -> String.format("Focus Distance: %.2f", selectedFocusDistance)
                                        ActiveCameraSetting.FRAMES -> "Total Frames: $totalFrames"
                                    }
                                    Text(
                                        text = headerText,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White
                                    )
                                    IconButton(
                                        onClick = {
                                            prefs.edit()
                                                .putFloat("iso", selectedIso)
                                                .putFloat("exposure", selectedExposure)
                                                .putFloat("focus", selectedFocusDistance)
                                                .putString("frames", totalFramesText)
                                                .apply()
                                            activeSetting = null
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Close Setting",
                                            tint = Color.White
                                        )
                                    }
                                }

                                when (setting) {
                                    ActiveCameraSetting.ISO -> {
                                        Slider(
                                            value = selectedIso,
                                            onValueChange = {
                                                selectedIso = it
                                                prefs.edit().putFloat("iso", it).apply()
                                            },
                                            valueRange = 100f..3200f,
                                            steps = 30,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    ActiveCameraSetting.EXPOSURE -> {
                                        Slider(
                                            value = selectedExposure.coerceIn(0.1f, 20f),
                                            onValueChange = {
                                                val rounded = (kotlin.math.round(it * 10f) / 10f).coerceIn(0.1f, 20f)
                                                selectedExposure = rounded
                                                prefs.edit().putFloat("exposure", rounded).apply()
                                            },
                                            valueRange = 0.1f..20f,
                                            steps = 198,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    ActiveCameraSetting.FOCUS -> {
                                        if (maxFocusDistance > 0f) {
                                            Slider(
                                                value = selectedFocusDistance.coerceIn(0f, maxFocusDistance),
                                                onValueChange = {
                                                    selectedFocusDistance = it
                                                    prefs.edit().putFloat("focus", it).apply()
                                                },
                                                valueRange = 0f..maxFocusDistance,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        } else {
                                            Text(
                                                text = "Manual focus not supported on this lens.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color.LightGray,
                                                modifier = Modifier.padding(vertical = 4.dp)
                                            )
                                        }
                                    }
                                    ActiveCameraSetting.FRAMES -> {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        OutlinedTextField(
                                            value = totalFramesText,
                                            onValueChange = {
                                                val filtered = it.filter { char -> char.isDigit() }
                                                totalFramesText = filtered
                                                prefs.edit().putString("frames", filtered).apply()
                                            },
                                            label = { Text("Total Frames", color = Color.White) },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedTextColor = Color.White,
                                                unfocusedTextColor = Color.White,
                                                focusedBorderColor = Color.White,
                                                unfocusedBorderColor = Color.LightGray,
                                                focusedLabelColor = Color.White,
                                                unfocusedLabelColor = Color.LightGray,
                                                cursorColor = Color.White
                                            ),
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Layer: Quick Settings Bar (ISO, EXP, FOC, FRM) + Start Capture Button
                Row(
                    modifier = Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val chipItems = listOf(
                        ActiveCameraSetting.ISO to "ISO ${selectedIso.toInt()}",
                        ActiveCameraSetting.EXPOSURE to String.format("EXP %.1fs", selectedExposure),
                        ActiveCameraSetting.FOCUS to String.format("FOC %.1f", selectedFocusDistance),
                        ActiveCameraSetting.FRAMES to "FRM $totalFrames"
                    )
                    chipItems.forEach { (setting, label) ->
                        val isSelected = activeSetting == setting
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                activeSetting = if (isSelected) null else setting
                            },
                            label = {
                                Text(
                                    text = label,
                                    color = Color.White,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color.Black.copy(alpha = 0.55f),
                                labelColor = Color.White,
                                selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                selectedLabelColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = Color.White.copy(alpha = 0.45f),
                                selectedBorderColor = Color.White
                            )
                        )
                    }
                }

                Button(
                    onClick = {
                        activeSetting = null
                        scope.launch {
                            val surface = previewSurface ?: return@launch
                            isCapturing = true
                            errorMessage = null
                            outputVideo = null
                            captureProgress = 0
                            latestCapturedBitmap = null
                            actualCapturedFrames = 0

                            val exposureNanos = (selectedExposure.toDouble() * 1_000_000_000.0).toLong()
                            val sessionDir = ExperimentSessionManager.createNewSessionDir(context)
                            currentSessionDir = sessionDir
                            val outputDir = File(sessionDir, "frames")
                            outputDir.mkdirs()
                            val capturedCount = cameraManagerHelper.captureSequence(
                                previewSurface = surface,
                                outputDir = outputDir,
                                numFrames = totalFrames,
                                exposureNanos = exposureNanos,
                                iso = selectedIso.toInt(),
                                focusDistance = selectedFocusDistance,
                                onProgress = { progress, file ->
                                    captureProgress = progress
                                    actualCapturedFrames = progress
                                    scope.launch(Dispatchers.IO) {
                                        try {
                                            val options = BitmapFactory.Options().apply {
                                                inSampleSize = 2
                                            }
                                            val bmp = BitmapFactory.decodeFile(file.absolutePath, options)
                                            if (bmp != null) {
                                                val imgBmp = bmp.asImageBitmap()
                                                withContext(Dispatchers.Main) {
                                                    latestCapturedBitmap = imgBmp
                                                }
                                            }
                                        } catch (e: Exception) {
                                            Log.w("CameraScreen", "Could not decode preview frame", e)
                                        }
                                    }
                                }
                            )

                            cameraManagerHelper.updatePreviewParameters(
                                iso = selectedIso.toInt(),
                                exposureSeconds = selectedExposure,
                                focusDistance = selectedFocusDistance
                            )

                            isCapturing = false
                            if (capturedCount > 0) {
                                actualCapturedFrames = capturedCount
                                showNamingDialog = true
                            } else {
                                errorMessage = "Capture sequence failed or no frames were captured."
                            }
                        }
                    },
                    enabled = previewSurface != null,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.height(52.dp)
                ) {
                    Text("Start Capture ($totalFrames frames)", color = Color.White)
                }

                if (outputVideo != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = Color.Black.copy(alpha = 0.78f),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .widthIn(max = 460.dp)
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                    ) {
                        Column(
                            modifier = Modifier
                                .verticalScroll(rememberScrollState())
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                "Video saved to: ${outputVideo?.absolutePath}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.LightGray
                            )

                            var isExporting by remember { mutableStateOf(false) }
                            var exportResult by remember { mutableStateOf<String?>(null) }

                            @OptIn(ExperimentalPermissionsApi::class)
                            val exportPermissionState = rememberPermissionState(Manifest.permission.WRITE_EXTERNAL_STORAGE)

                            Spacer(modifier = Modifier.height(10.dp))

                            if (exportResult != null) {
                                Text(exportResult!!, style = MaterialTheme.typography.bodyMedium, color = Color.Green)
                            } else if (isExporting) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White)
                            } else {
                                Button(
                                    onClick = {
                                        @OptIn(ExperimentalPermissionsApi::class)
                                        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q && !exportPermissionState.status.isGranted) {
                                            exportPermissionState.launchPermissionRequest()
                                        } else {
                                            scope.launch {
                                                isExporting = true
                                                val cleanTitle = testTitle.replace("\\s+".toRegex(), "_").ifBlank { "Kinetics_Video" }
                                                val uri = MediaHelper.exportVideoToGallery(
                                                    context = context,
                                                    sourceFile = outputVideo!!,
                                                    fileName = "${cleanTitle}_${System.currentTimeMillis()}.mp4"
                                                )
                                                isExporting = false
                                                exportResult = if (uri != null) "Successfully exported to Gallery!" else "Export failed."
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Save to Gallery")
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (isProcessingRoi) {
                                Text(
                                    text = "Analyzing ROI ($roiProcessingProgress%)...",
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = roiProcessingProgress / 100f,
                                    modifier = Modifier.fillMaxWidth(),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = Color.DarkGray
                                )
                            } else if (roiResults != null) {
                                SharedResultsView(
                                    roiResults = roiResults!!,
                                    sessionFolder = currentSessionDir,
                                    testTitle = testTitle,
                                    exposureTime = selectedExposure,
                                    onBack = { },
                                    onSaveExperiment = { exp ->
                                        onSaveExperiment(exp)
                                        onBack()
                                    },
                                    onNavigateToAdvancedAnalysis = {
                                        onNavigateToAdvancedAnalysis(
                                            roiResults!!,
                                            selectedExposure,
                                            testTitle,
                                            currentSessionDir?.absolutePath ?: ""
                                        )
                                    }
                                )
                            } else {
                                Button(
                                    onClick = { showRoiSelector = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Analyze Data (ROI)")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
