package com.example

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.ExperimentEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.OutputStream

object MasterCsvExporter {
    suspend fun exportMasterCsv(context: Context, experiments: List<ExperimentEntity>): Uri? = withContext(Dispatchers.IO) {
        try {
            val timestamp = System.currentTimeMillis()
            val fileName = "Master_Experiments_$timestamp.csv"
            val resolver = context.contentResolver
            var resultUri: Uri? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                resultUri = resolver.insert(collection, contentValues)
                resultUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        writeCsvData(outputStream, experiments)
                    }
                }
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) {
                    downloadsDir.mkdirs()
                }
                val file = File(downloadsDir, fileName)
                file.outputStream().use { outputStream ->
                    writeCsvData(outputStream, experiments)
                }
                resultUri = Uri.fromFile(file)
            }
            resultUri
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun writeCsvData(outputStream: OutputStream, experiments: List<ExperimentEntity>) {
        val header = "ID,Experiment Name,Timestamp,Exposure Time,Original Exposure Time,Peak Time,Peak Intensity,Total AUC,High Duration,Max Window AUC,Max Window Start,Max Window End,Session Folder\n"
        outputStream.write(header.toByteArray(Charsets.UTF_8))

        experiments.forEach { exp ->
            val origExpStr = if (exp.originalExposure != null) "Original Exposure Time: ${exp.originalExposure}s" else ""
            val row = "${exp.id},${exp.experimentName},${exp.timestamp},${exp.exposureTime},\"$origExpStr\",${exp.peakTime},${exp.peakIntensity},${exp.totalAuc},${exp.highDuration},${exp.maxWindowAuc},${exp.maxWindowStartTime},${exp.maxWindowEndTime},${exp.sessionFolderPath}\n"
            outputStream.write(row.toByteArray(Charsets.UTF_8))
        }
    }
}
