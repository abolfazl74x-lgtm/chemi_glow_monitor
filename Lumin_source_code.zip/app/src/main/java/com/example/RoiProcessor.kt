package com.example

import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File

data class IntensityResult(
    val frameIndex: Int,
    val averageIntensity: Double
)

sealed class RoiProcessingState {
    data class Progress(val percent: Int) : RoiProcessingState()
    data class Success(val results: List<IntensityResult>) : RoiProcessingState()
    data class Error(val message: String) : RoiProcessingState()
}

object RoiProcessor {
    
    /**
     * Processes a sequence of images to calculate the average intensity of a specific Region of Interest (ROI).
     * Uses BitmapRegionDecoder to decode only the selected region, preventing OutOfMemory errors.
     */
    fun processImagesFlow(
        files: List<File>,
        roi: Rect,
        whiteConfig: WhiteConstantConfig = WhiteConstantConfig()
    ): Flow<RoiProcessingState> = flow {
        try {
            val results = mutableListOf<IntensityResult>()
            val total = files.size
            
            if (total == 0) {
                emit(RoiProcessingState.Success(emptyList()))
                return@flow
            }

            files.forEachIndexed { index, file ->
                // Ensure the file exists
                if (!file.exists()) return@forEachIndexed

                // Memory efficient decoding: decode only the requested bounds
                val decoder = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    BitmapRegionDecoder.newInstance(file.absolutePath)
                } else {
                    @Suppress("DEPRECATION")
                    BitmapRegionDecoder.newInstance(file.absolutePath, false)
                }
                
                val options = BitmapFactory.Options().apply {
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                    inDither = false
                    inPremultiplied = false
                    inScaled = false
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        inPreferredColorSpace = android.graphics.ColorSpace.get(android.graphics.ColorSpace.Named.SRGB)
                    }
                }
                // Decode only the exact ROI crop directly into memory
                val bitmap = decoder?.decodeRegion(roi, options)
                
                if (bitmap != null) {
                    val width = bitmap.width
                    val height = bitmap.height
                    val pixels = IntArray(width * height)
                    
                    // Extract all raw pixels from the cropped bitmap
                    bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
                    
                    var sumIntensity = 0.0
                    
                    for (pixel in pixels) {
                        // Calculate intensity using configured white constants (RGB weights, baseline offset, scale)
                        val intensity = whiteConfig.calculatePixelIntensity(pixel)
                        sumIntensity += intensity
                    }
                    
                    val average = if (pixels.isNotEmpty()) sumIntensity / pixels.size else 0.0
                    results.add(IntensityResult(index, average))
                    
                    // Immediately free native memory
                    bitmap.recycle()
                }
                
                decoder?.recycle()
                
                // Report progress safely on the background thread
                val percent = (((index + 1).toFloat() / total.toFloat()) * 100).toInt()
                emit(RoiProcessingState.Progress(percent))
            }
            
            emit(RoiProcessingState.Success(results))
            
        } catch (e: Exception) {
            emit(RoiProcessingState.Error(e.message ?: "Unknown error during ROI processing"))
        }
    }.flowOn(Dispatchers.IO)
}
