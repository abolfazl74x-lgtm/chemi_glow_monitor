package com.example

import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ControlCamera
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RoiSelector(
    imageFiles: List<File>,
    onRoiConfirmed: (android.graphics.Rect) -> Unit,
    onCancel: () -> Unit
) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val prefs = remember { context.getSharedPreferences("RoiPrefs", Context.MODE_PRIVATE) }

    if (imageFiles.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            Text("No images available", color = Color.Red)
        }
        return
    }

    val scope = rememberCoroutineScope()
    var isRotating by remember { mutableStateOf(false) }
    var rotationDegrees by remember { mutableFloatStateOf(0f) }
    var currentFrameIndex by remember { mutableFloatStateOf(0f) }
    var imageBitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(currentFrameIndex.toInt()) {
        val currentFile = imageFiles[currentFrameIndex.toInt()]
        withContext(Dispatchers.IO) {
            val options = BitmapFactory.Options()
            options.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565
            val bitmap = BitmapFactory.decodeFile(currentFile.absolutePath, options)
            if (bitmap != null) {
                val imgBitmap = bitmap.asImageBitmap()
                withContext(Dispatchers.Main) {
                    imageBitmap = imgBitmap
                }
            }
        }
    }

    var drawStartOffset by remember { mutableStateOf<Offset?>(null) }
    var roiRect by remember { mutableStateOf<Rect?>(null) }
    var imageRectInCanvas by remember { mutableStateOf(Rect.Zero) }
    var isMoving by remember { mutableStateOf(false) }
    var isDragging by remember { mutableStateOf(false) }
    var currentTouchOffset by remember { mutableStateOf<Offset?>(null) }
    var showPrecisionControls by remember { mutableStateOf(false) }
    val textMeasurer = rememberTextMeasurer()

    fun rotateImages(deltaDegrees: Float) {
        scope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                isRotating = true
            }
            try {
                for (file in imageFiles) {
                    val originalBitmap = BitmapFactory.decodeFile(file.absolutePath)
                    if (originalBitmap != null) {
                        val matrix = Matrix().apply {
                            postRotate(
                                deltaDegrees,
                                originalBitmap.width / 2f,
                                originalBitmap.height / 2f
                            )
                        }
                        val rotatedBitmap = Bitmap.createBitmap(
                            originalBitmap,
                            0,
                            0,
                            originalBitmap.width,
                            originalBitmap.height,
                            matrix,
                            true
                        )
                        FileOutputStream(file).use { out ->
                            val format = if (file.name.endsWith(".png", ignoreCase = true)) {
                                Bitmap.CompressFormat.PNG
                            } else {
                                Bitmap.CompressFormat.JPEG
                            }
                            rotatedBitmap.compress(format, 100, out)
                        }
                        if (rotatedBitmap != originalBitmap) {
                            rotatedBitmap.recycle()
                        }
                        originalBitmap.recycle()
                    }
                }
                val currentIdx = currentFrameIndex.toInt().coerceIn(0, imageFiles.size - 1)
                val currentFile = imageFiles[currentIdx]
                val options = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val reloadedBitmap = BitmapFactory.decodeFile(currentFile.absolutePath, options)
                val newImgBitmap = reloadedBitmap?.asImageBitmap()

                withContext(Dispatchers.Main) {
                    imageBitmap = newImgBitmap
                    roiRect = null
                    isRotating = false
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isRotating = false
                    Toast.makeText(context, "Rotation failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun shiftRoi(dx: Float, dy: Float) {
        val current = roiRect ?: return
        if (current.isEmpty || imageRectInCanvas.isEmpty) return
        val translated = current.translate(translateX = dx, translateY = dy)
        val width = current.width
        val height = current.height
        var newLeft = translated.left
        var newTop = translated.top
        if (newLeft < imageRectInCanvas.left) newLeft = imageRectInCanvas.left
        if (newLeft + width > imageRectInCanvas.right) {
            newLeft = max(imageRectInCanvas.left, imageRectInCanvas.right - width)
        }
        if (newTop < imageRectInCanvas.top) newTop = imageRectInCanvas.top
        if (newTop + height > imageRectInCanvas.bottom) {
            newTop = max(imageRectInCanvas.top, imageRectInCanvas.bottom - height)
        }
        roiRect = Rect(newLeft, newTop, newLeft + width, newTop + height)
    }

    @Composable
    fun RoiCanvasSection(modifier: Modifier = Modifier) {
        Box(modifier = modifier) {
            if (imageBitmap != null) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(imageRectInCanvas, isRotating) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    if (isRotating) return@detectDragGestures
                                    isDragging = true
                                    currentTouchOffset = offset
                                    if (roiRect != null && roiRect!!.contains(offset)) {
                                        isMoving = true
                                    } else {
                                        isMoving = false
                                        val clampedX = offset.x.coerceIn(imageRectInCanvas.left, imageRectInCanvas.right)
                                        val clampedY = offset.y.coerceIn(imageRectInCanvas.top, imageRectInCanvas.bottom)
                                        drawStartOffset = Offset(clampedX, clampedY)
                                        roiRect = Rect(clampedX, clampedY, clampedX, clampedY)
                                    }
                                },
                                onDrag = { change, dragAmount ->
                                    if (isRotating) return@detectDragGestures
                                    change.consume()
                                    currentTouchOffset = change.position
                                    val currentRoi = roiRect ?: return@detectDragGestures

                                    if (isMoving) {
                                        val width = currentRoi.width
                                        val height = currentRoi.height

                                        var newLeft = currentRoi.left + dragAmount.x
                                        var newTop = currentRoi.top + dragAmount.y
                                        var newRight = newLeft + width
                                        var newBottom = newTop + height

                                        if (newLeft < imageRectInCanvas.left) {
                                            newLeft = imageRectInCanvas.left
                                            newRight = newLeft + width
                                        }
                                        if (newRight > imageRectInCanvas.right) {
                                            newRight = imageRectInCanvas.right
                                            newLeft = newRight - width
                                        }
                                        if (newTop < imageRectInCanvas.top) {
                                            newTop = imageRectInCanvas.top
                                            newBottom = newTop + height
                                        }
                                        if (newBottom > imageRectInCanvas.bottom) {
                                            newBottom = imageRectInCanvas.bottom
                                            newTop = newBottom - height
                                        }
                                        roiRect = Rect(newLeft, newTop, newRight, newBottom)
                                    } else {
                                        val start = drawStartOffset ?: return@detectDragGestures
                                        val endX = change.position.x.coerceIn(imageRectInCanvas.left, imageRectInCanvas.right)
                                        val endY = change.position.y.coerceIn(imageRectInCanvas.top, imageRectInCanvas.bottom)

                                        val rectLeft = min(start.x, endX)
                                        val rectTop = min(start.y, endY)
                                        val rectRight = max(start.x, endX)
                                        val rectBottom = max(start.y, endY)

                                        roiRect = Rect(rectLeft, rectTop, rectRight, rectBottom)
                                    }
                                },
                                onDragEnd = {
                                    isDragging = false
                                    currentTouchOffset = null
                                },
                                onDragCancel = {
                                    isDragging = false
                                    currentTouchOffset = null
                                }
                            )
                        }
                ) {
                    val canvasWidth = size.width
                    val canvasHeight = size.height
                    val imageWidth = imageBitmap!!.width.toFloat()
                    val imageHeight = imageBitmap!!.height.toFloat()

                    val scale = min(canvasWidth / imageWidth, canvasHeight / imageHeight)
                    val scaledWidth = imageWidth * scale
                    val scaledHeight = imageHeight * scale
                    val offsetX = (canvasWidth - scaledWidth) / 2f
                    val offsetY = (canvasHeight - scaledHeight) / 2f

                    imageRectInCanvas = Rect(
                        left = offsetX,
                        top = offsetY,
                        right = offsetX + scaledWidth,
                        bottom = offsetY + scaledHeight
                    )

                    drawImage(
                        image = imageBitmap!!,
                        dstOffset = IntOffset(offsetX.toInt(), offsetY.toInt()),
                        dstSize = IntSize(scaledWidth.toInt(), scaledHeight.toInt())
                    )

                    val rect = roiRect
                    if (rect != null && !rect.isEmpty) {
                        drawPath(
                            path = Path().apply {
                                addRect(imageRectInCanvas)
                                addRect(rect)
                                fillType = PathFillType.EvenOdd
                            },
                            color = Color.Black.copy(alpha = 0.5f)
                        )

                        drawRect(
                            color = Color.Yellow,
                            topLeft = Offset(rect.left, rect.top),
                            size = Size(rect.width, rect.height),
                            style = Stroke(width = 5f)
                        )

                        if (scale > 0f) {
                            val magSizePx = 150.dp.toPx()
                            val paddingPx = 16.dp.toPx()
                            val cornerRadiusPx = 12.dp.toPx()

                            // Check overlap with top-left area (including touch and badge margin)
                            val topLeftCheckZone = Rect(
                                left = 0f,
                                top = 0f,
                                right = paddingPx + magSizePx + 20.dp.toPx(),
                                bottom = paddingPx + magSizePx + 40.dp.toPx()
                            )
                            val touchOverlaps = currentTouchOffset?.let { touch ->
                                topLeftCheckZone.contains(touch)
                            } ?: false
                            val roiOverlaps = rect.overlaps(topLeftCheckZone)

                            val moveToTopRight = touchOverlaps || roiOverlaps
                            val rawMagLeft = if (moveToTopRight) canvasWidth - paddingPx - magSizePx else paddingPx
                            val magLeft = rawMagLeft.coerceIn(0f, max(0f, canvasWidth - magSizePx))
                            val magTop = paddingPx
                            val magRect = Rect(magLeft, magTop, magLeft + magSizePx, magTop + magSizePx)

                            // Original image pixel coordinates
                            val origRoiLeft = (rect.left - offsetX) / scale
                            val origRoiTop = (rect.top - offsetY) / scale
                            val origRoiRight = (rect.right - offsetX) / scale
                            val origRoiBottom = (rect.bottom - offsetY) / scale

                            val origW = max(1f, origRoiRight - origRoiLeft)
                            val origH = max(1f, origRoiBottom - origRoiTop)
                            val origCenterX = (origRoiLeft + origRoiRight) / 2f
                            val origCenterY = (origRoiTop + origRoiBottom) / 2f

                            // Square crop region: 35% larger than ROI max dimension, min 80px
                            val desiredCropSpan = max(max(origW, origH) * 1.35f, 80f)
                            val clampedCropSpan = min(desiredCropSpan, min(imageWidth, imageHeight))

                            var cropLeft = origCenterX - clampedCropSpan / 2f
                            var cropTop = origCenterY - clampedCropSpan / 2f

                            if (cropLeft < 0f) cropLeft = 0f
                            if (cropLeft + clampedCropSpan > imageWidth) cropLeft = max(0f, imageWidth - clampedCropSpan)
                            if (cropTop < 0f) cropTop = 0f
                            if (cropTop + clampedCropSpan > imageHeight) cropTop = max(0f, imageHeight - clampedCropSpan)

                            val finalSpan = min(clampedCropSpan, min(imageWidth - cropLeft, imageHeight - cropTop))
                            val srcDim = finalSpan.toInt().coerceAtLeast(1)
                            val srcLeftInt = cropLeft.toInt().coerceIn(0, max(0, imageBitmap!!.width - srcDim))
                            val srcTopInt = cropTop.toInt().coerceIn(0, max(0, imageBitmap!!.height - srcDim))

                            // Clip to RoundRect and draw zoomed crop & magnifier elements
                            val magRoundRect = RoundRect(magRect, CornerRadius(cornerRadiusPx, cornerRadiusPx))
                            clipPath(Path().apply { addRoundRect(magRoundRect) }) {
                                drawImage(
                                    image = imageBitmap!!,
                                    srcOffset = IntOffset(srcLeftInt, srcTopInt),
                                    srcSize = IntSize(srcDim, srcDim),
                                    dstOffset = IntOffset(magRect.left.toInt(), magRect.top.toInt()),
                                    dstSize = IntSize(magRect.width.toInt(), magRect.height.toInt())
                                )

                                val scaleToMag = magSizePx / srcDim.toFloat()
                                val magRoiLeft = magRect.left + (origRoiLeft - srcLeftInt) * scaleToMag
                                val magRoiTop = magRect.top + (origRoiTop - srcTopInt) * scaleToMag
                                val magRoiRight = magRect.left + (origRoiRight - srcLeftInt) * scaleToMag
                                val magRoiBottom = magRect.top + (origRoiBottom - srcTopInt) * scaleToMag
                                val magRoiRect = Rect(magRoiLeft, magRoiTop, magRoiRight, magRoiBottom)

                                // Dark semi-transparent overlay outside ROI
                                val magOverlayPath = Path().apply {
                                    addRect(magRect)
                                    addRect(magRoiRect)
                                    fillType = PathFillType.EvenOdd
                                }
                                drawPath(path = magOverlayPath, color = Color.Black.copy(alpha = 0.45f))

                                // Proportional yellow ROI border
                                drawRect(
                                    color = Color.Yellow,
                                    topLeft = Offset(magRoiRect.left, magRoiRect.top),
                                    size = Size(max(0f, magRoiRect.width), max(0f, magRoiRect.height)),
                                    style = Stroke(width = 2.dp.toPx())
                                )

                                // Small cyan crosshair (+) at exact center of ROI
                                val crosshairCenterX = (magRoiLeft + magRoiRight) / 2f
                                val crosshairCenterY = (magRoiTop + magRoiBottom) / 2f
                                val chLen = 7.dp.toPx()
                                drawLine(
                                    color = Color.Cyan,
                                    start = Offset(crosshairCenterX - chLen, crosshairCenterY),
                                    end = Offset(crosshairCenterX + chLen, crosshairCenterY),
                                    strokeWidth = 2.dp.toPx()
                                )
                                drawLine(
                                    color = Color.Cyan,
                                    start = Offset(crosshairCenterX, crosshairCenterY - chLen),
                                    end = Offset(crosshairCenterX, crosshairCenterY + chLen),
                                    strokeWidth = 2.dp.toPx()
                                )
                            }

                            // Magnifier Border: Cyan while dragging, White when idle
                            drawRoundRect(
                                color = if (isDragging) Color.Cyan else Color.White,
                                topLeft = Offset(magRect.left, magRect.top),
                                size = Size(magRect.width, magRect.height),
                                cornerRadius = CornerRadius(cornerRadiusPx, cornerRadiusPx),
                                style = Stroke(width = if (isDragging) 2.5.dp.toPx() else 1.5.dp.toPx())
                            )

                            // Live Info Badge directly below the magnifier box
                            val origWInt = origW.toInt().coerceAtLeast(0)
                            val origHInt = origH.toInt().coerceAtLeast(0)
                            val totalPixels = imageWidth.toDouble() * imageHeight.toDouble()
                            val roiPixels = origWInt.toDouble() * origHInt.toDouble()
                            val percentage = if (totalPixels > 0.0) (roiPixels / totalPixels) * 100.0 else 0.0
                            val badgeText = String.format(java.util.Locale.US, "%d×%d px (%.1f%%)", origWInt, origHInt, percentage)

                            val textLayoutResult = textMeasurer.measure(
                                text = badgeText,
                                style = TextStyle(
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )
                            )
                            val badgePaddingH = 8.dp.toPx()
                            val badgePaddingV = 4.dp.toPx()
                            val badgeW = textLayoutResult.size.width + badgePaddingH * 2f
                            val badgeH = textLayoutResult.size.height + badgePaddingV * 2f
                            val badgeTop = magRect.bottom + 6.dp.toPx()
                            val rawBadgeLeft = magRect.left + (magRect.width - badgeW) / 2f
                            val badgeLeft = rawBadgeLeft.coerceIn(8.dp.toPx(), max(8.dp.toPx(), canvasWidth - badgeW - 8.dp.toPx()))
                            val badgeCorner = CornerRadius(6.dp.toPx(), 6.dp.toPx())

                            drawRoundRect(
                                color = Color.Black.copy(alpha = 0.8f),
                                topLeft = Offset(badgeLeft, badgeTop),
                                size = Size(badgeW, badgeH),
                                cornerRadius = badgeCorner
                            )

                            drawRoundRect(
                                color = Color.White.copy(alpha = 0.3f),
                                topLeft = Offset(badgeLeft, badgeTop),
                                size = Size(badgeW, badgeH),
                                cornerRadius = badgeCorner,
                                style = Stroke(width = 1.dp.toPx())
                            )

                            drawText(
                                textLayoutResult = textLayoutResult,
                                topLeft = Offset(badgeLeft + badgePaddingH, badgeTop + badgePaddingV)
                            )
                        }
                    }
                }
            } else {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }

            if (isRotating) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = Color.White)
                }
            }
        }
    }

    @Composable
    fun RoiControlsSection(modifier: Modifier = Modifier) {
        Column(
            modifier = modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Fine-Tune ROI Toggle Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { showPrecisionControls = !showPrecisionControls },
                    modifier = Modifier.testTag("fine_tune_roi_toggle_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ControlCamera,
                        contentDescription = "Fine-Tune ROI",
                        tint = if (showPrecisionControls) Color.Cyan else Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (showPrecisionControls) "Hide Fine-Tune ROI" else "Fine-Tune ROI",
                        color = if (showPrecisionControls) Color.Cyan else Color.White,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            // Inline Precision Control Pad (never overlapping the video frame)
            if (showPrecisionControls) {
                val hasValidRoi = roiRect != null && !roiRect!!.isEmpty
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("precision_control_pad_card"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.Black.copy(alpha = 0.78f)
                    ),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .height(IntrinsicSize.Min),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
                    ) {
                        // Move Section (D-pad style)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = "Move",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(
                                onClick = { if (roiRect != null) shiftRoi(0f, -2f) },
                                enabled = hasValidRoi,
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("roi_move_up_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowUp,
                                    contentDescription = "Move ROI Up",
                                    tint = if (hasValidRoi) Color.Cyan else Color.Gray
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                IconButton(
                                    onClick = { if (roiRect != null) shiftRoi(-2f, 0f) },
                                    enabled = hasValidRoi,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .testTag("roi_move_left_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                        contentDescription = "Move ROI Left",
                                        tint = if (hasValidRoi) Color.Cyan else Color.Gray
                                    )
                                }
                                IconButton(
                                    onClick = { if (roiRect != null) shiftRoi(2f, 0f) },
                                    enabled = hasValidRoi,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .testTag("roi_move_right_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                        contentDescription = "Move ROI Right",
                                        tint = if (hasValidRoi) Color.Cyan else Color.Gray
                                    )
                                }
                            }
                            IconButton(
                                onClick = { if (roiRect != null) shiftRoi(0f, 2f) },
                                enabled = hasValidRoi,
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("roi_move_down_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowDown,
                                    contentDescription = "Move ROI Down",
                                    tint = if (hasValidRoi) Color.Cyan else Color.Gray
                                )
                            }
                        }

                        VerticalDivider(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(1.dp),
                            color = Color.White.copy(alpha = 0.25f)
                        )

                        // Size Section (+W, -W, +H, -H)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Size",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            // Width Row
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "W",
                                    color = Color.LightGray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.width(16.dp)
                                )
                                IconButton(
                                    onClick = {
                                        if (roiRect != null) {
                                            roiRect = roiRect?.copy(
                                                right = maxOf(roiRect!!.right - 2f, roiRect!!.left + 10f)
                                            )
                                        }
                                    },
                                    enabled = hasValidRoi,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .testTag("roi_size_minus_w_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Decrease ROI Width",
                                        tint = if (hasValidRoi) Color.Yellow else Color.Gray
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        if (roiRect != null) {
                                            roiRect = roiRect?.copy(
                                                right = minOf(roiRect!!.right + 2f, imageRectInCanvas.right)
                                            )
                                        }
                                    },
                                    enabled = hasValidRoi,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .testTag("roi_size_plus_w_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Increase ROI Width",
                                        tint = if (hasValidRoi) Color.Yellow else Color.Gray
                                    )
                                }
                            }
                            // Height Row
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "H",
                                    color = Color.LightGray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.width(16.dp)
                                )
                                IconButton(
                                    onClick = {
                                        if (roiRect != null) {
                                            roiRect = roiRect?.copy(
                                                bottom = maxOf(roiRect!!.bottom - 2f, roiRect!!.top + 10f)
                                            )
                                        }
                                    },
                                    enabled = hasValidRoi,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .testTag("roi_size_minus_h_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Decrease ROI Height",
                                        tint = if (hasValidRoi) Color.Yellow else Color.Gray
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        if (roiRect != null) {
                                            roiRect = roiRect?.copy(
                                                bottom = minOf(roiRect!!.bottom + 2f, imageRectInCanvas.bottom)
                                            )
                                        }
                                    },
                                    enabled = hasValidRoi,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .testTag("roi_size_plus_h_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Increase ROI Height",
                                        tint = if (hasValidRoi) Color.Yellow else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Frame Scrubber UI below the pad
            if (imageFiles.size > 1) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Frame: ${currentFrameIndex.toInt() + 1} / ${imageFiles.size}",
                        color = Color.White
                    )
                    Slider(
                        value = currentFrameIndex,
                        onValueChange = { currentFrameIndex = it },
                        valueRange = 0f..(imageFiles.size - 1).toFloat(),
                        steps = max(0, imageFiles.size - 2),
                        enabled = !isRotating
                    )
                }
            }

            // Action Buttons in a wrapping FlowRow
            FlowRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                rotationDegrees = (rotationDegrees - 90f) % 360f
                                rotateImages(-90f)
                            },
                            enabled = !isRotating,
                            modifier = Modifier.testTag("rotate_left_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.RotateLeft,
                                contentDescription = "Rotate Left",
                                tint = if (!isRotating) Color.White else Color.Gray
                            )
                        }
                        IconButton(
                            onClick = {
                                rotationDegrees = (rotationDegrees + 90f) % 360f
                                rotateImages(90f)
                            },
                            enabled = !isRotating,
                            modifier = Modifier.testTag("rotate_right_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.RotateRight,
                                contentDescription = "Rotate Right",
                                tint = if (!isRotating) Color.White else Color.Gray
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        val rect = roiRect
                        if (rect != null && !rect.isEmpty && imageBitmap != null) {
                            val scale = imageRectInCanvas.width / imageBitmap!!.width.toFloat()
                            val originalX = ((rect.left - imageRectInCanvas.left) / scale).toInt()
                            val originalY = ((rect.top - imageRectInCanvas.top) / scale).toInt()
                            val originalWidth = (rect.width / scale).toInt()
                            val originalHeight = (rect.height / scale).toInt()

                            val maxDim = kotlin.math.max(imageBitmap!!.width, imageBitmap!!.height).toFloat()
                            val centerX = imageBitmap!!.width / 2f
                            val centerY = imageBitmap!!.height / 2f

                            val roiCenterX = originalX + originalWidth / 2f
                            val roiCenterY = originalY + originalHeight / 2f

                            val ratioDx = (roiCenterX - centerX) / maxDim
                            val ratioDy = (roiCenterY - centerY) / maxDim
                            val ratioW = originalWidth.toFloat() / maxDim
                            val ratioH = originalHeight.toFloat() / maxDim

                            prefs.edit()
                                .putFloat("roi_center_dx", ratioDx)
                                .putFloat("roi_center_dy", ratioDy)
                                .putFloat("roi_center_w", ratioW)
                                .putFloat("roi_center_h", ratioH)
                                .putInt("roi_x", originalX)
                                .putInt("roi_y", originalY)
                                .putInt("roi_width", originalWidth)
                                .putInt("roi_height", originalHeight)
                                .apply()
                            Toast.makeText(context, "ROI Position & Size Saved", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = !isRotating && roiRect != null && !roiRect!!.isEmpty
                ) {
                    Text("Save ROI")
                }

                Button(
                    onClick = {
                        if (imageBitmap != null) {
                            val maxDim = kotlin.math.max(imageBitmap!!.width, imageBitmap!!.height).toFloat()
                            val centerX = imageBitmap!!.width / 2f
                            val centerY = imageBitmap!!.height / 2f

                            val ratioDx = prefs.getFloat("roi_center_dx", 0f)
                            val ratioDy = prefs.getFloat("roi_center_dy", 0f)
                            val ratioW = prefs.getFloat("roi_center_w", 0f)
                            val ratioH = prefs.getFloat("roi_center_h", 0f)

                            if (ratioW > 0f && ratioH > 0f) {
                                val roiCenterX = centerX + (ratioDx * maxDim)
                                val roiCenterY = centerY + (ratioDy * maxDim)
                                val origW = ratioW * maxDim
                                val origH = ratioH * maxDim

                                val origLeft = roiCenterX - origW / 2f
                                val origTop = roiCenterY - origH / 2f

                                val scale = imageRectInCanvas.width / imageBitmap!!.width.toFloat()
                                val scaledWidth = origW * scale
                                val scaledHeight = origH * scale

                                var newLeft = imageRectInCanvas.left + (origLeft * scale)
                                var newTop = imageRectInCanvas.top + (origTop * scale)
                                var newRight = newLeft + scaledWidth
                                var newBottom = newTop + scaledHeight

                                if (newLeft < imageRectInCanvas.left) {
                                    newLeft = imageRectInCanvas.left
                                    newRight = newLeft + scaledWidth
                                }
                                if (newRight > imageRectInCanvas.right) {
                                    newRight = imageRectInCanvas.right
                                    newLeft = kotlin.math.max(imageRectInCanvas.left, newRight - scaledWidth)
                                }
                                if (newTop < imageRectInCanvas.top) {
                                    newTop = imageRectInCanvas.top
                                    newBottom = newTop + scaledHeight
                                }
                                if (newBottom > imageRectInCanvas.bottom) {
                                    newBottom = imageRectInCanvas.bottom
                                    newTop = kotlin.math.max(imageRectInCanvas.top, newBottom - scaledHeight)
                                }

                                roiRect = Rect(newLeft, newTop, newRight, newBottom)
                                Toast.makeText(context, "ROI Position & Size Loaded", Toast.LENGTH_SHORT).show()
                            } else {
                                val savedX = prefs.getInt("roi_x", -1)
                                val savedY = prefs.getInt("roi_y", -1)
                                val savedWidth = prefs.getInt("roi_width", 0)
                                val savedHeight = prefs.getInt("roi_height", 0)
                                if (savedWidth > 0 && savedHeight > 0) {
                                    val scale = imageRectInCanvas.width / imageBitmap!!.width.toFloat()
                                    val scaledWidth = savedWidth * scale
                                    val scaledHeight = savedHeight * scale

                                    var newLeft: Float
                                    var newTop: Float
                                    if (savedX >= 0 && savedY >= 0) {
                                        newLeft = imageRectInCanvas.left + (savedX * scale)
                                        newTop = imageRectInCanvas.top + (savedY * scale)
                                    } else {
                                        val cX = imageRectInCanvas.left + imageRectInCanvas.width / 2f
                                        val cY = imageRectInCanvas.top + imageRectInCanvas.height / 2f
                                        newLeft = cX - scaledWidth / 2f
                                        newTop = cY - scaledHeight / 2f
                                    }

                                    var newRight = newLeft + scaledWidth
                                    var newBottom = newTop + scaledHeight

                                    if (newLeft < imageRectInCanvas.left) {
                                        newLeft = imageRectInCanvas.left
                                        newRight = newLeft + scaledWidth
                                    }
                                    if (newRight > imageRectInCanvas.right) {
                                        newRight = imageRectInCanvas.right
                                        newLeft = newRight - scaledWidth
                                    }
                                    if (newTop < imageRectInCanvas.top) {
                                        newTop = imageRectInCanvas.top
                                        newBottom = newTop + scaledHeight
                                    }
                                    if (newBottom > imageRectInCanvas.bottom) {
                                        newBottom = imageRectInCanvas.bottom
                                        newTop = newBottom - scaledHeight
                                    }

                                    roiRect = Rect(newLeft, newTop, newRight, newBottom)
                                    Toast.makeText(context, "ROI Position & Size Loaded", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "No saved ROI found", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            Toast.makeText(context, "No saved ROI found", Toast.LENGTH_SHORT).show()
                        }
                    },
                    enabled = !isRotating
                ) {
                    Text("Load ROI")
                }

                Button(
                    onClick = onCancel,
                    enabled = !isRotating
                ) {
                    Text("Cancel")
                }

                Button(
                    onClick = {
                        val rect = roiRect
                        if (rect != null && !imageRectInCanvas.isEmpty && imageBitmap != null) {
                            val scale = imageRectInCanvas.width / imageBitmap!!.width.toFloat()
                            val originalX = ((rect.left - imageRectInCanvas.left) / scale).toInt()
                            val originalY = ((rect.top - imageRectInCanvas.top) / scale).toInt()
                            val originalWidth = (rect.width / scale).toInt()
                            val originalHeight = (rect.height / scale).toInt()

                            val resultRect = android.graphics.Rect(
                                originalX,
                                originalY,
                                originalX + originalWidth,
                                originalY + originalHeight
                            )
                            onRoiConfirmed(resultRect)
                        }
                    },
                    enabled = !isRotating && roiRect != null && !roiRect!!.isEmpty
                ) {
                    Text("Confirm ROI")
                }
            }
        }
    }

    if (isLandscape) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            RoiCanvasSection(
                modifier = Modifier
                    .weight(0.6f)
                    .fillMaxHeight()
            )
            RoiControlsSection(
                modifier = Modifier
                    .weight(0.4f)
                    .fillMaxHeight()
            )
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            RoiCanvasSection(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            )
            RoiControlsSection(
                modifier = Modifier
                    .fillMaxWidth()
            )
        }
    }
}
