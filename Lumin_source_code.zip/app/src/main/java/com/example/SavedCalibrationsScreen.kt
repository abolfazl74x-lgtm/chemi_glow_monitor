package com.example

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CalibrationEntity
import com.example.data.ExperimentEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SavedCalBg = Color(0xFFF6F7FB)
private val SavedCalSurface = Color(0xFFFFFFFF)
private val SavedCalSoftPurple = Color(0xFFF3F0FF)
private val SavedCalPrimaryPurple = Color(0xFF4F46E5)
private val SavedCalBorder = Color(0xFFE5E7EB)
private val SavedCalTextPrimary = Color(0xFF111827)
private val SavedCalTextSecondary = Color(0xFF6B7280)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedCalibrationsScreen(
    viewModel: ExperimentViewModel,
    onOpenCalibration: (CalibrationEntity) -> Unit = {},
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val savedCalibrations by viewModel.savedCalibrations.collectAsState()
    val allExperiments by viewModel.allExperiments.collectAsState()
    var expandedCalibrationId by remember { mutableStateOf<Int?>(null) }
    var calibrationToDelete by remember { mutableStateOf<CalibrationEntity?>(null) }

    if (calibrationToDelete != null) {
        AlertDialog(
            onDismissRequest = { calibrationToDelete = null },
            title = { Text("Delete Saved Calibration") },
            text = {
                Text(
                    "Are you sure you want to delete '${calibrationToDelete?.name}'? This action cannot be undone."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteCalibration(calibrationToDelete!!)
                        if (expandedCalibrationId == calibrationToDelete!!.id) {
                            expandedCalibrationId = null
                        }
                        calibrationToDelete = null
                    },
                    modifier = Modifier.testTag("confirm_delete_calibration_button")
                ) {
                    Text("Delete", color = Color(0xFFDC2626))
                }
            },
            dismissButton = {
                TextButton(onClick = { calibrationToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        containerColor = SavedCalBg,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Saved Calibrations",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = SavedCalTextPrimary
                        )
                        Text(
                            text = "Tap a curve to open full 3-state view or expand calculator",
                            style = MaterialTheme.typography.labelSmall,
                            color = SavedCalTextSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("saved_calibrations_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = SavedCalTextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SavedCalSurface,
                    titleContentColor = SavedCalTextPrimary
                )
            )
        }
    ) { padding ->
        if (savedCalibrations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SavedCalBg)
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Functions,
                        contentDescription = null,
                        tint = SavedCalPrimaryPurple,
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = "No saved calibration curves yet.",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SavedCalTextPrimary
                    )
                    Text(
                        text = "Generate a calibration curve and tap the Save icon in the top bar to store it here for instant reuse.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SavedCalTextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SavedCalBg)
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(savedCalibrations, key = { it.id }) { calibration ->
                    SavedCalibrationCard(
                        calibration = calibration,
                        experiments = allExperiments,
                        isExpanded = expandedCalibrationId == calibration.id,
                        onOpenFullCurve = { onOpenCalibration(calibration) },
                        onToggleExpand = {
                            expandedCalibrationId = if (expandedCalibrationId == calibration.id) {
                                null
                            } else {
                                calibration.id
                            }
                        },
                        onDeleteClick = { calibrationToDelete = calibration }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SavedCalibrationCard(
    calibration: CalibrationEntity,
    experiments: List<ExperimentEntity>,
    isExpanded: Boolean,
    onOpenFullCurve: () -> Unit,
    onToggleExpand: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
    val dateStr = dateFormat.format(Date(calibration.timestamp))

    var unknownYInput by remember(calibration.id) { mutableStateOf("") }
    var calculatedX by remember(calibration.id) { mutableStateOf<Double?>(null) }
    var selectedExperimentLabel by remember(calibration.id) { mutableStateOf("") }
    var selectedExperimentName by remember(calibration.id) { mutableStateOf("") }
    var isExperimentDropdownExpanded by remember(calibration.id) { mutableStateOf(false) }
    var unknownSamples by remember(calibration.id) { mutableStateOf<List<UnknownSampleResult>>(emptyList()) }
    var isExporting by remember(calibration.id) { mutableStateOf(false) }

    val r2 = calibration.rSquared
    val (r2Color, r2BadgeBg, r2BadgeLabel) = when {
        r2 >= 0.99 -> Triple(Color(0xFF16A34A), Color(0xFFDCFCE7), "Excellent")
        r2 >= 0.95 -> Triple(Color(0xFFEA580C), Color(0xFFFFEDD5), "Good")
        else -> Triple(Color(0xFFDC2626), Color(0xFFFEE2E2), "Poor")
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("saved_calibration_card_${calibration.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SavedCalSurface),
        border = BorderStroke(
            width = if (isExpanded) 1.5.dp else 1.dp,
            color = if (isExpanded) SavedCalPrimaryPurple else SavedCalBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Card Header (Clickable to open full 3-state CalibrationResultScreen)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenFullCurve() }
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = calibration.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SavedCalTextPrimary
                    )
                    Text(
                        text = "Saved: $dateStr • Feature: ${calibration.featureName}${if (calibration.unit.isNotBlank()) " (${calibration.unit})" else ""}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SavedCalTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    val sign = if (calibration.intercept >= 0) "+" else "-"
                    val interceptAbs = kotlin.math.abs(calibration.intercept)
                    Text(
                        text = "y = ${String.format(Locale.US, "%.4f", calibration.slope)}x $sign ${String.format(Locale.US, "%.4f", interceptAbs)}",
                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 17.sp),
                        fontWeight = FontWeight.ExtraBold,
                        color = SavedCalPrimaryPurple
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            text = "R² = ${String.format(Locale.US, "%.4f", r2)}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = r2Color
                        )
                        Surface(
                            color = r2BadgeBg,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = r2BadgeLabel,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = r2Color,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onOpenFullCurve,
                        modifier = Modifier.testTag("open_saved_calibration_${calibration.id}")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = "Open 3-State Calibration Curve",
                            tint = SavedCalPrimaryPurple
                        )
                    }
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.testTag("delete_saved_calibration_${calibration.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Saved Calibration",
                            tint = Color(0xFFDC2626)
                        )
                    }
                    IconButton(onClick = onToggleExpand) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (isExpanded) "Collapse Calculator" else "Expand Calculator",
                            tint = SavedCalTextSecondary
                        )
                    }
                }
            }

            // Expandable Unknown Samples Calculator Section
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SavedCalSoftPurple.copy(alpha = 0.25f))
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(color = SavedCalBorder)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Unknown Samples Calculator",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SavedCalTextPrimary
                            )
                            Text(
                                text = "Calculate concentrations using ${calibration.name}",
                                style = MaterialTheme.typography.bodySmall,
                                color = SavedCalTextSecondary
                            )
                        }
                        TextButton(
                            onClick = {
                                unknownYInput = ""
                                calculatedX = null
                                selectedExperimentLabel = ""
                                selectedExperimentName = ""
                                unknownSamples = emptyList()
                            }
                        ) {
                            Text(
                                text = "Clear",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Saved Experiment Dropdown
                    ExposedDropdownMenuBox(
                        expanded = isExperimentDropdownExpanded,
                        onExpandedChange = { if (experiments.isNotEmpty()) isExperimentDropdownExpanded = it },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = selectedExperimentLabel,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Saved Experiment (Optional)") },
                            placeholder = { Text(if (experiments.isEmpty()) "No saved experiments available" else "Choose an experiment...") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isExperimentDropdownExpanded) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = SavedCalSurface,
                                unfocusedContainerColor = SavedCalSurface,
                                focusedBorderColor = SavedCalPrimaryPurple,
                                unfocusedBorderColor = SavedCalBorder,
                                focusedTextColor = SavedCalTextPrimary,
                                unfocusedTextColor = SavedCalTextPrimary
                            ),
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        if (experiments.isNotEmpty()) {
                            ExposedDropdownMenu(
                                expanded = isExperimentDropdownExpanded,
                                onDismissRequest = { isExperimentDropdownExpanded = false },
                                modifier = Modifier.background(SavedCalSurface)
                            ) {
                                experiments.forEach { exp ->
                                    val yVal = when (calibration.featureName) {
                                        "Peak Value" -> exp.peakIntensity
                                        "Total AUC" -> exp.totalAuc
                                        "Max Emission AUC" -> exp.maxWindowAuc
                                        else -> exp.maxWindowAuc
                                    }
                                    val label = "${exp.experimentName} (${calibration.featureName}: ${String.format(Locale.US, "%.2f", yVal)})"
                                    DropdownMenuItem(
                                        text = { Text(label, color = SavedCalTextPrimary) },
                                        onClick = {
                                            selectedExperimentLabel = label
                                            selectedExperimentName = exp.experimentName
                                            unknownYInput = yVal.toString()
                                            calculatedX = if (calibration.slope != 0.0) {
                                                (yVal - calibration.intercept) / calibration.slope
                                            } else null
                                            isExperimentDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Input Row: Response (Y) + Add Sample Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = unknownYInput,
                            onValueChange = {
                                unknownYInput = it
                                selectedExperimentLabel = if (it.isEmpty()) "" else "Manual Input"
                                selectedExperimentName = if (it.isEmpty()) "" else "Manual Input"
                                val yValue = it.toDoubleOrNull()
                                if (yValue != null && calibration.slope != 0.0) {
                                    calculatedX = (yValue - calibration.intercept) / calibration.slope
                                } else {
                                    calculatedX = null
                                }
                            },
                            label = { Text("Response (Y)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = SavedCalSurface,
                                unfocusedContainerColor = SavedCalSurface,
                                focusedBorderColor = SavedCalPrimaryPurple,
                                unfocusedBorderColor = SavedCalBorder,
                                focusedTextColor = SavedCalTextPrimary,
                                unfocusedTextColor = SavedCalTextPrimary
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        Button(
                            onClick = {
                                val xVal = calculatedX
                                val yVal = unknownYInput.toDoubleOrNull()
                                if (xVal != null && yVal != null) {
                                    val sampleName = selectedExperimentName.ifBlank { "Sample #${unknownSamples.size + 1}" }
                                    unknownSamples = unknownSamples + UnknownSampleResult(
                                        name = sampleName,
                                        yValue = yVal,
                                        calculatedX = xVal
                                    )
                                    unknownYInput = ""
                                    calculatedX = null
                                    selectedExperimentLabel = ""
                                    selectedExperimentName = ""
                                }
                            },
                            enabled = calculatedX != null && unknownYInput.toDoubleOrNull() != null,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SavedCalPrimaryPurple,
                                contentColor = Color.White,
                                disabledContainerColor = SavedCalBorder,
                                disabledContentColor = SavedCalTextSecondary
                            ),
                            modifier = Modifier
                                .height(56.dp)
                                .padding(top = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Sample", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    if (calculatedX != null) {
                        Surface(
                            color = SavedCalSoftPurple,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Estimated Concentration (X) = ${String.format(Locale.US, "%.4f", calculatedX)}${if (calibration.unit.isNotBlank()) " ${calibration.unit}" else ""}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = SavedCalPrimaryPurple,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }

                    if (unknownSamples.isNotEmpty()) {
                        Text(
                            text = "Calculated Unknown Samples (${unknownSamples.size})",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = SavedCalTextSecondary
                        )
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            unknownSamples.forEachIndexed { index, sample ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = SavedCalSurface),
                                    border = BorderStroke(1.dp, SavedCalBorder)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = sample.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = SavedCalTextPrimary
                                            )
                                            Text(
                                                text = "Y: ${String.format(Locale.US, "%.4f", sample.yValue)}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = SavedCalTextSecondary
                                            )
                                            Text(
                                                text = "Concentration: ${String.format(Locale.US, "%.4f", sample.calculatedX)}${if (calibration.unit.isNotBlank()) " ${calibration.unit}" else ""}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = SavedCalPrimaryPurple
                                            )
                                        }
                                        IconButton(
                                            onClick = {
                                                unknownSamples = unknownSamples.filterIndexed { i, _ -> i != index }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Remove Sample",
                                                tint = Color(0xFFDC2626)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Button(
                        onClick = {
                            if (isExporting) return@Button
                            isExporting = true
                            coroutineScope.launch {
                                val yVal = unknownYInput.toDoubleOrNull()
                                val savedStandards = CalibrationStandardJsonHelper.fromJson(calibration.standardPointsJson)
                                val exportPoints = savedStandards.map {
                                    it.concentration to it.getValueForFeature(calibration.featureName)
                                }
                                val syntheticResult = CalibrationResult(
                                    slope = calibration.slope,
                                    intercept = calibration.intercept,
                                    rSquared = calibration.rSquared,
                                    points = exportPoints
                                )
                                val uri = CalibrationCsvExporter.exportCalibrationReport(
                                    context = context,
                                    result = syntheticResult,
                                    featureName = calibration.featureName,
                                    unit = calibration.unit,
                                    unknownSamples = unknownSamples,
                                    unknownY = yVal,
                                    calculatedX = calculatedX,
                                    unknownSampleLabel = selectedExperimentName.ifBlank { if (yVal != null) "Manual Input" else null }
                                )
                                isExporting = false
                                if (uri != null) {
                                    Toast.makeText(
                                        context,
                                        "Calibration Report Saved to Downloads folder",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } else {
                                    Toast.makeText(
                                        context,
                                        "Failed to export calibration report",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        },
                        enabled = !isExporting,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SavedCalPrimaryPurple,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isExporting) "Exporting..." else "Export Unknowns Report (CSV/Excel)",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
