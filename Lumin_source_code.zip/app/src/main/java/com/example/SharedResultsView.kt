package com.example

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.ExperimentEntity
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.compose.chart.line.lineSpec
import com.patrykandpatrick.vico.compose.chart.scroll.rememberChartScrollSpec
import com.patrykandpatrick.vico.core.axis.AxisItemPlacer
import com.patrykandpatrick.vico.core.entry.FloatEntry
import com.patrykandpatrick.vico.core.entry.entryModelOf
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SharedResultsView(
    roiResults: List<IntensityResult>,
    sessionFolder: File?,
    testTitle: String,
    exposureTime: Float,
    originalExposure: Float? = null,
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit,
    onNavigateToAdvancedAnalysis: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showChartDialog by remember { mutableStateOf(false) }

    var isExportingCsv by remember { mutableStateOf(false) }

    if (showChartDialog) {
        val graphicsLayer = rememberGraphicsLayer()
        var isSavingImage by remember { mutableStateOf(false) }
        var imageSaveMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChartDialog = false },
            title = { Text("Kinetics Curve") },
            text = {
                Column {
                    if (imageSaveMessage != null) {
                        Text(
                            text = imageSaveMessage!!,
                            color = if (imageSaveMessage!!.contains("Failed") || imageSaveMessage!!.contains("Error")) Color.Red else Color.Green,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    val chartEntryModel = remember(roiResults) {
                        val entries = roiResults.map {
                            FloatEntry(x = ((it.frameIndex + 1) * exposureTime), y = it.averageIntensity.toFloat())
                        }
                        entryModelOf(entries)
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .background(MaterialTheme.colorScheme.surface) // Solid background for the exported PNG
                            .drawWithContent {
                                graphicsLayer.record {
                                    this@drawWithContent.drawContent()
                                }
                                drawContent()
                            }
                    ) {
                        val dataSize = roiResults.size
                        val dynamicSpacing = kotlin.math.max(1, dataSize / 6)

                        Chart(
                            chart = lineChart(
                                lines = listOf(
                                    lineSpec(
                                        lineColor = MaterialTheme.colorScheme.primary,
                                        lineBackgroundShader = null,
                                        point = null,
                                        pointConnector = com.patrykandpatrick.vico.core.chart.DefaultPointConnector(cubicStrength = 0f)
                                    )
                                )
                            ),
                            model = chartEntryModel,
                            startAxis = rememberStartAxis(
                                title = "Intensity",
                                titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(end = 4.dp)
                                )
                            ),
                            bottomAxis = rememberBottomAxis(
                                title = "Time (s)",
                                titleComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    margins = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(top = 4.dp)
                                ),
                                itemPlacer = AxisItemPlacer.Horizontal.default(
                                    spacing = dynamicSpacing,
                                    addExtremeLabelPadding = true
                                )
                            ),
                            chartScrollSpec = rememberChartScrollSpec(isScrollEnabled = false)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showChartDialog = false }) {
                    Text("Close")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            isSavingImage = true
                            try {
                                val bitmap = graphicsLayer.toImageBitmap().asAndroidBitmap()
                                val uri = ImageExporter.exportBitmapToGallery(context, bitmap)
                                imageSaveMessage = if (uri != null) "Chart saved to MediaStore!" else "Failed to save chart"
                            } catch (e: Exception) {
                                imageSaveMessage = "Error: ${e.localizedMessage}"
                            }
                            isSavingImage = false
                        }
                    },
                    enabled = !isSavingImage
                ) {
                    Text(if (isSavingImage) "Saving..." else "Save as PNG")
                }
            }
        )
    }


    
    // Main Content
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Analysis Complete", style = MaterialTheme.typography.titleLarge)
        if (originalExposure != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Original Exposure Time: ${originalExposure}s",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(modifier = Modifier.height(24.dp))

        if (isExportingCsv) {
            CircularProgressIndicator(modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(12.dp))
        } else {
            Button(
                onClick = {
                    scope.launch {
                        isExportingCsv = true
                        if (roiResults.isEmpty()) {
                            Toast.makeText(context, "No data to export", Toast.LENGTH_LONG).show()
                        } else {
                            val uri = CsvExporter.exportKineticsToCsv(
                                context = context,
                                results = roiResults,
                                exposureTimeSeconds = exposureTime,
                                testTitle = testTitle,
                                originalExposure = originalExposure
                            )
                            if (uri != null) {
                                Toast.makeText(context, "CSV Saved to Downloads folder", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Failed to save CSV", Toast.LENGTH_LONG).show()
                            }
                        }
                        isExportingCsv = false
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Text("Export ROI Kinetics (CSV)")
            }
        }
        
        Button(
            onClick = { showChartDialog = true },
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        ) {
            Text("View Kinetics Chart")
        }
        
        Button(
            onClick = onNavigateToAdvancedAnalysis,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Advanced Analysis")
        }
    }
}
