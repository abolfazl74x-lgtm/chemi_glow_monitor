package com.example

import kotlin.math.abs
import kotlin.math.pow

data class AnalysisResults(
    val smoothedData: List<Pair<Double, Double>>,
    val peakTime: Double,
    val peakIntensity: Double,
    val totalAuc: Double,
    val highDuration: Double,
    val maxWindowAuc: Double,
    val maxWindowStartTime: Double,
    val maxWindowEndTime: Double
)

object SignalProcessor {

    /**
     * Executes the full numerical signal processing pipeline matching
     * scipy.signal.savgol_filter (polyorder=3) and scipy.integrate.trapezoid.
     */
    fun analyze(
        rawData: List<Pair<Double, Double>>,
        params: AdvancedAnalysisParams
    ): AnalysisResults {
        if (rawData.isEmpty()) {
            return AnalysisResults(emptyList(), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
        }

        // 1. Savitzky-Golay Smoothing (Degree 3, dynamic window length)
        val smoothedData = savitzkyGolay(
            data = rawData,
            windowSize = params.smoothingWindowSize,
            polyOrder = 3
        )

        // 2. Peak Detection: peak_index = np.argmax(signal_smooth)
        var peakIndex = 0
        for (i in 1 until smoothedData.size) {
            if (smoothedData[i].second > smoothedData[peakIndex].second) {
                peakIndex = i
            }
        }
        val peakTime = smoothedData[peakIndex].first
        val peakIntensity = smoothedData[peakIndex].second

        // 3. Threshold Logic: Calculate Total AUC until signal drops below Cutoff % after peak
        val cutoffValue = peakIntensity * (params.totalIntegralCutoff / 100.0)
        var cutoffIndex = smoothedData.size - 1
        for (i in peakIndex until smoothedData.size) {
            if (smoothedData[i].second < cutoffValue) {
                cutoffIndex = i
                break
            }
        }
        val totalAuc = calculateAUC(smoothedData.subList(0, cutoffIndex + 1))

        // 4. High Duration: Time span where smoothed signal >= High Duration Threshold %
        val highThresholdValue = peakIntensity * (params.highDurationThreshold / 100.0)
        val highIndices = smoothedData.indices.filter { smoothedData[it].second >= highThresholdValue }
        val highDuration = if (highIndices.size >= 2) {
            smoothedData[highIndices.last()].first - smoothedData[highIndices.first()].first
        } else {
            0.0
        }

        // 5. Sliding Window (Input 7 - Max Emission AUC):
        // For each start_idx, find t_end_target = t_start + windowDuration, find exact end_idx,
        // slice [start_idx : end_idx + 1], and compute trapezoidal AUC on that slice.
        var maxWindowAuc = 0.0
        var maxWindowStart = 0.0
        var maxWindowEnd = 0.0
        val windowDuration = params.maxEmissionWindowDuration.toDouble()

        if (smoothedData.size >= 2 && windowDuration > 0.0) {
            for (startIdx in smoothedData.indices) {
                val tStart = smoothedData[startIdx].first
                val tEndTarget = tStart + windowDuration

                var endIdx = startIdx
                for (idx in startIdx until smoothedData.size) {
                    if (smoothedData[idx].first <= tEndTarget + 1e-9) {
                        endIdx = idx
                    } else {
                        break
                    }
                }

                if (endIdx > startIdx) {
                    val windowSlice = smoothedData.subList(startIdx, endIdx + 1)
                    val windowAuc = calculateAUC(windowSlice)
                    if (windowAuc > maxWindowAuc) {
                        maxWindowAuc = windowAuc
                        maxWindowStart = windowSlice.first().first
                        maxWindowEnd = windowSlice.last().first
                    }
                }
            }
        }

        return AnalysisResults(
            smoothedData = smoothedData,
            peakTime = peakTime,
            peakIntensity = peakIntensity,
            totalAuc = totalAuc,
            highDuration = highDuration,
            maxWindowAuc = maxWindowAuc,
            maxWindowStartTime = maxWindowStart,
            maxWindowEndTime = maxWindowEnd
        )
    }

    /**
     * Savitzky-Golay filter matching scipy.signal.savgol_filter(y, window_length, polyorder=3, mode='interp').
     *
     * Generates least-squares polynomial projection coefficients via normal equations (A^T A)^-1 A^T:
     * - Interior points are convolved with the central Savitzky-Golay coefficients (row 0 of B).
     * - Boundary points (first and last halfWindow samples) are evaluated using the least-squares
     *   polynomial fitted to the first/last windowSize samples (exact match to SciPy's mode='interp').
     */
    fun savitzkyGolay(
        data: List<Pair<Double, Double>>,
        windowSize: Int,
        polyOrder: Int = 3
    ): List<Pair<Double, Double>> {
        val n = data.size
        if (n < 3 || windowSize <= 1) return data

        // Force windowSize to an odd integer >= 3, and <= n (largest odd integer <= n)
        var mWindow = maxOf(3, if (windowSize % 2 == 0) windowSize + 1 else windowSize)
        if (mWindow > n) {
            mWindow = if (n % 2 == 0) n - 1 else n
        }
        if (mWindow < 3) return data

        val effectivePolyOrder = polyOrder.coerceIn(1, mWindow - 1)
        val halfWindow = mWindow / 2

        // Build projection matrix B = (A^T A)^(-1) A^T of shape (effectivePolyOrder + 1) x mWindow
        // where A[r, j] = (r - halfWindow)^j for r in 0 until mWindow, j in 0..effectivePolyOrder.
        val basisMatrix = computeSavGolProjectionMatrix(mWindow, effectivePolyOrder)
        val centerCoeffs = basisMatrix[0] // Standard central Savitzky-Golay convolution coefficients

        val yValues = DoubleArray(n) { data[it].second }
        val smoothedY = DoubleArray(n)

        // 1. Interior points: standard sliding window convolution
        for (i in halfWindow until (n - halfWindow)) {
            var acc = 0.0
            val baseIdx = i - halfWindow
            for (r in 0 until mWindow) {
                acc += centerCoeffs[r] * yValues[baseIdx + r]
            }
            smoothedY[i] = acc
        }

        // 2. Left edge (0 until halfWindow): polynomial fit on first mWindow points evaluated at k = i - halfWindow
        val leftPolyCoeffs = DoubleArray(effectivePolyOrder + 1) { j ->
            var sum = 0.0
            for (r in 0 until mWindow) {
                sum += basisMatrix[j][r] * yValues[r]
            }
            sum
        }
        for (i in 0 until halfWindow) {
            val k = (i - halfWindow).toDouble()
            smoothedY[i] = evaluatePolynomial(leftPolyCoeffs, k)
        }

        // 3. Right edge ((n - halfWindow) until n): polynomial fit on last mWindow points evaluated at k = i - (n - 1 - halfWindow)
        val rightStart = n - mWindow
        val rightCenter = n - 1 - halfWindow
        val rightPolyCoeffs = DoubleArray(effectivePolyOrder + 1) { j ->
            var sum = 0.0
            for (r in 0 until mWindow) {
                sum += basisMatrix[j][r] * yValues[rightStart + r]
            }
            sum
        }
        for (i in (n - halfWindow) until n) {
            val k = (i - rightCenter).toDouble()
            smoothedY[i] = evaluatePolynomial(rightPolyCoeffs, k)
        }

        return List(n) { idx -> Pair(data[idx].first, smoothedY[idx]) }
    }

    /**
     * Trapezoidal Integration matching numpy.trapz / scipy.integrate.trapezoid.
     */
    fun calculateAUC(data: List<Pair<Double, Double>>): Double {
        if (data.size < 2) return 0.0
        var auc = 0.0
        for (i in 0 until data.size - 1) {
            val x0 = data[i].first
            val y0 = data[i].second
            val x1 = data[i + 1].first
            val y1 = data[i + 1].second
            auc += (x1 - x0) * (y1 + y0) / 2.0
        }
        return auc
    }

    private fun evaluatePolynomial(coeffs: DoubleArray, x: Double): Double {
        var result = 0.0
        var xPow = 1.0
        for (c in coeffs) {
            result += c * xPow
            xPow *= x
        }
        return result
    }

    /**
     * Computes B = (A^T A)^(-1) A^T of dimensions (polyOrder + 1) x windowSize
     * using Gauss-Jordan elimination with partial pivoting.
     */
    private fun computeSavGolProjectionMatrix(windowSize: Int, polyOrder: Int): Array<DoubleArray> {
        val p = polyOrder + 1
        val half = windowSize / 2

        // Vandermonde design matrix A: windowSize x p
        val a = Array(windowSize) { r ->
            val k = (r - half).toDouble()
            DoubleArray(p) { j -> if (j == 0) 1.0 else k.pow(j) }
        }

        // Normal matrix A^T A: p x p
        val ata = Array(p) { row ->
            DoubleArray(p) { col ->
                var sum = 0.0
                for (r in 0 until windowSize) {
                    sum += a[r][row] * a[r][col]
                }
                sum
            }
        }

        // Invert (A^T A) via Gauss-Jordan elimination
        val invAta = invertMatrix(ata)

        // Multiply B = (A^T A)^(-1) * A^T -> p x windowSize
        return Array(p) { row ->
            DoubleArray(windowSize) { r ->
                var sum = 0.0
                for (k in 0 until p) {
                    sum += invAta[row][k] * a[r][k]
                }
                sum
            }
        }
    }

    private fun invertMatrix(matrix: Array<DoubleArray>): Array<DoubleArray> {
        val n = matrix.size
        val aug = Array(n) { i ->
            DoubleArray(2 * n) { j ->
                if (j < n) matrix[i][j] else if (j - n == i) 1.0 else 0.0
            }
        }

        for (col in 0 until n) {
            var pivotRow = col
            var maxVal = abs(aug[col][col])
            for (row in (col + 1) until n) {
                val v = abs(aug[row][col])
                if (v > maxVal) {
                    maxVal = v
                    pivotRow = row
                }
            }

            if (pivotRow != col) {
                val tmp = aug[col]
                aug[col] = aug[pivotRow]
                aug[pivotRow] = tmp
            }

            val pivot = aug[col][col]
            if (abs(pivot) < 1e-14) continue

            for (j in 0 until 2 * n) {
                aug[col][j] /= pivot
            }

            for (row in 0 until n) {
                if (row != col) {
                    val factor = aug[row][col]
                    if (factor != 0.0) {
                        for (j in 0 until 2 * n) {
                            aug[row][j] -= factor * aug[col][j]
                        }
                    }
                }
            }
        }

        return Array(n) { i ->
            DoubleArray(n) { j -> aug[i][j + n] }
        }
    }
}
