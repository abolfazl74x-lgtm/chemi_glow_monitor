package com.example

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

@Composable
fun TestNamingDialog(
    initialTitle: String = "",
    showIntervalInput: Boolean = false,
    isVideoImport: Boolean = false,
    onConfirm: (name: String, interval: Float, originalExposure: Float?) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("ExtractionPrefs", Context.MODE_PRIVATE)

    var text by rememberSaveable { mutableStateOf(initialTitle) }
    var frameIntervalText by rememberSaveable {
        mutableStateOf(prefs.getString("frame_interval", "1.0") ?: "1.0")
    }
    var originalExposureText by rememberSaveable {
        mutableStateOf(prefs.getString("original_exposure", "") ?: "")
    }
    var isError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Test Title") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = {
                        text = it
                        isError = false
                        errorMessage = ""
                    },
                    label = { Text("Enter a Test Title") },
                    isError = isError,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("test_title_input")
                )
                if (isError) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (showIntervalInput) {
                    OutlinedTextField(
                        value = frameIntervalText,
                        onValueChange = { newValue ->
                            frameIntervalText = newValue
                            prefs.edit().putString("frame_interval", newValue).apply()
                        },
                        label = {
                            Text(
                                if (isVideoImport) "Frame Extraction Interval (s)"
                                else "Time interval per frame (seconds)"
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("frame_interval_input")
                    )
                }
                if (isVideoImport) {
                    OutlinedTextField(
                        value = originalExposureText,
                        onValueChange = { newValue ->
                            originalExposureText = newValue
                            prefs.edit().putString("original_exposure", newValue).apply()
                        },
                        label = { Text("Original Camera Exposure (s) [Optional, for labels]") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("original_exposure_input")
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmed = text.trim()
                    if (trimmed.isEmpty()) {
                        isError = true
                        errorMessage = "Title cannot be empty"
                        return@Button
                    }
                    if (trimmed.matches(".*[\\\\/:*?\"<>|].*".toRegex())) {
                        isError = true
                        errorMessage = "Invalid characters: \\ / : * ? \" < > |"
                        return@Button
                    }
                    val interval = if (showIntervalInput) {
                        frameIntervalText.toFloatOrNull()?.takeIf { it > 0f } ?: 1.0f
                    } else {
                        1.0f
                    }
                    val parsedOriginalExposure = if (isVideoImport) {
                        originalExposureText.trim().toFloatOrNull()?.takeIf { it > 0f }
                    } else {
                        null
                    }
                    onConfirm(trimmed, interval, parsedOriginalExposure)
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
