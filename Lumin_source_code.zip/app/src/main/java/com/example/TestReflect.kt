package com.example

import com.patrykandpatrick.vico.core.chart.line.LineChart

fun testReflect() {
    val classes = LineChart::class.java.classes
    for (c in classes) {
        println("INNER CLASS: " + c.name)
    }
}
