@file:Suppress("DEPRECATION")
package com.example

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.core.entry.FloatEntry
import com.patrykandpatrick.vico.core.entry.entryModelOf
import com.patrykandpatrick.vico.compose.chart.line.lineSpec
import com.patrykandpatrick.vico.compose.chart.scroll.rememberChartScrollSpec
import com.patrykandpatrick.vico.core.axis.AxisItemPlacer
import kotlinx.coroutines.launch
import java.io.File
import com.example.data.ExperimentEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoAnalysisScreen(
    files: List<File>,
    testTitle: String,
    exposureTime: Float = 1f,
    originalExposure: Float? = null,
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit,
    onNavigateToAdvancedAnalysis: (List<IntensityResult>, Float, String, String, Float?) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var showRoiSelector by remember { mutableStateOf(true) }
    var isProcessingRoi by remember { mutableStateOf(false) }
    var roiProcessingProgress by remember { mutableStateOf(0) }
    var roiResults by remember { mutableStateOf<List<IntensityResult>?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    

    
    val fps = 1f // based on the FFmpeg extraction setting -vf fps=1
    
    if (showRoiSelector && files.isNotEmpty()) {
        RoiSelector(
            imageFiles = files,
            onRoiConfirmed = { rect ->
                showRoiSelector = false
                isProcessingRoi = true
                roiResults = null
                scope.launch {
                    RoiProcessor.processImagesFlow(files, rect).collect { state ->
                        when (state) {
                            is RoiProcessingState.Progress -> roiProcessingProgress = state.percent
                            is RoiProcessingState.Success -> {
                                isProcessingRoi = false
                                roiResults = state.results
                                
                            }
                            is RoiProcessingState.Error -> {
                                isProcessingRoi = false
                                errorMessage = "ROI Processing failed: ${state.message}"
                            }
                        }
                    }
                }
            },
            onCancel = onBack
        )
        return
    }
    


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Video Analysis") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (isProcessingRoi) {
                CircularProgressIndicator(progress = { roiProcessingProgress / 100f }, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Analyzing frames: $roiProcessingProgress%")
            } else if (errorMessage != null) {
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error)
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onBack) {
                    Text("Go Back")
                }
            } else if (roiResults != null) {
                SharedResultsView(
                    roiResults = roiResults!!,
                    sessionFolder = files.firstOrNull()?.parentFile,
                    testTitle = testTitle,
                    exposureTime = exposureTime,
                    originalExposure = originalExposure,
                    onBack = onBack,
                    onSaveExperiment = { exp -> 
                        onSaveExperiment(exp)
                        onBack()
                    },
                    onNavigateToAdvancedAnalysis = {
                        onNavigateToAdvancedAnalysis(
                            roiResults!!,
                            exposureTime,
                            testTitle,
                            files.firstOrNull()?.parentFile?.absolutePath ?: "",
                            originalExposure
                        )
                    }
                )
            }
        }
    }
}
