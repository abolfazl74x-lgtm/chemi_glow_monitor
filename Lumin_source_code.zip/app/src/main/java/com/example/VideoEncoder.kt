package com.example

import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import java.io.File

sealed class EncodingState {
    data class Progress(val percent: Int) : EncodingState()
    data class Success(val file: File) : EncodingState()
    data class Error(val message: String) : EncodingState()
}

object VideoEncoder {
    fun encodeImagesToVideoFlow(
        imageDir: File,
        outputFile: File,
        totalFrames: Int,
        exposureTimeSeconds: Float
    ): Flow<EncodingState> = callbackFlow {
        val inputPattern = File(imageDir, "frame_%03d.jpg").absolutePath
        
        if (outputFile.exists()) {
            outputFile.delete()
        }
        
        val command = "-y -framerate 1/${exposureTimeSeconds} -i \"$inputPattern\" -c:v libx264 -preset ultrafast -crf 28 -threads auto -r 30 -pix_fmt yuv420p -vf \"scale=1280:-2\" \"${outputFile.absolutePath}\""
        
        Log.d("VideoEncoder", "Executing: $command")
        
        val session = FFmpegKit.executeAsync(
            command,
            { session ->
                val returnCode = session.returnCode
                if (ReturnCode.isSuccess(returnCode)) {
                    Log.d("VideoEncoder", "Encode success: ${outputFile.absolutePath}")
                    trySend(EncodingState.Success(outputFile))
                } else {
                    val errorMsg = session.failStackTrace ?: session.output ?: "Unknown FFmpeg error"
                    Log.e("VideoEncoder", "Encode failed with return code $returnCode: $errorMsg")
                    trySend(EncodingState.Error(errorMsg))
                }
                close()
            },
            { log -> 
                // Optional: handle logs if needed for debugging
            },
            { statistics ->
                val encodedFrames = statistics.videoFrameNumber
                if (totalFrames > 0) {
                    val percent = ((encodedFrames.toFloat() / totalFrames.toFloat()) * 100).toInt().coerceIn(0, 100)
                    trySend(EncodingState.Progress(percent))
                }
            }
        )
        
        awaitClose {
            FFmpegKit.cancel(session.sessionId)
        }
    }.flowOn(Dispatchers.IO)
}
