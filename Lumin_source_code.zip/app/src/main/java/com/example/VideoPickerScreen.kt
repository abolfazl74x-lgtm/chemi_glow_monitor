package com.example

import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoPickerScreen(
    onBack: () -> Unit,
    onFramesExtracted: (files: List<File>, title: String, interval: Float, originalExposure: Float?) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isExtracting by remember { mutableStateOf(false) }
    var pendingVideoUri by remember { mutableStateOf<Uri?>(null) }
    var pendingDefaultTitle by remember { mutableStateOf("") }
    var showVideoNamingDialog by remember { mutableStateOf(false) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: android.net.Uri? ->
        if (uri != null) {
            pendingVideoUri = uri
            pendingDefaultTitle = FileUtil.extractOriginalFilename(context, uri)
            showVideoNamingDialog = true
        }
    }

    if (showVideoNamingDialog && pendingVideoUri != null) {
        TestNamingDialog(
            initialTitle = pendingDefaultTitle,
            showIntervalInput = true,
            isVideoImport = true,
            onConfirm = { name, interval, originalExposure ->
                val targetUri = pendingVideoUri
                showVideoNamingDialog = false
                if (targetUri != null) {
                    isExtracting = true
                    coroutineScope.launch {
                        val extractedFiles = extractFramesFromVideo(
                            context = context,
                            uri = targetUri,
                            intervalSeconds = interval
                        )
                        isExtracting = false
                        onFramesExtracted(extractedFiles, name, interval, originalExposure)
                    }
                }
            },
            onDismiss = {
                showVideoNamingDialog = false
                pendingVideoUri = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Extract Frames") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (isExtracting) {
                CircularProgressIndicator(modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Extracting frames...", style = MaterialTheme.typography.bodyLarge)
            } else {
                Text(
                    text = "Select a video from your device to configure the frame extraction interval and optional original camera exposure label.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
                Button(onClick = {
                    videoPickerLauncher.launch(arrayOf("video/*"))
                }) {
                    Text("Select Video from Files")
                }
            }
        }
    }
}

suspend fun extractFramesFromVideo(
    context: android.content.Context,
    uri: Uri,
    intervalSeconds: Float = 1f
): List<File> = withContext(Dispatchers.IO) {
    val uniqueId = UUID.randomUUID().toString()
    val outputDir = File(context.cacheDir, "frames_$uniqueId")
    if (!outputDir.exists()) {
        outputDir.mkdirs()
    }

    val safeInterval = if (intervalSeconds > 0f) intervalSeconds else 1f
    val inputPath = FFmpegKitConfig.getSafParameterForRead(context, uri)
    val outputPathPattern = File(outputDir, "frame_%04d.png").absolutePath

    // Strictly use interval (1/interval) for FFmpeg frame extraction
    val command = "-i \"$inputPath\" -vf fps=1/$safeInterval \"$outputPathPattern\""

    val session = FFmpegKit.execute(command)
    val returnCode = session.returnCode

    if (ReturnCode.isSuccess(returnCode)) {
        outputDir.listFiles()?.filter { it.name.endsWith(".png") }?.sortedBy { it.name } ?: emptyList()
    } else {
        Log.e(
            "VideoPickerScreen",
            "FFmpeg extraction failed with state ${session.state} and rc ${session.returnCode}.${session.failStackTrace}"
        )
        emptyList()
    }
}
