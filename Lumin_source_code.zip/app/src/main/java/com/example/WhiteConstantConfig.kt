package com.example

import android.content.Context
import android.graphics.Color
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import java.util.Locale
import kotlin.math.abs

/**
 * Configuration for pixel intensity calculation and camera white balance.
 * Uses configurable RGB channel weights, baseline offset, and scaling factor.
 */
data class WhiteConstantConfig(
    val presetName: String = "Standard Luminance (Rec. 601)",
    val redWeight: Double = 0.299,
    val greenWeight: Double = 0.587,
    val blueWeight: Double = 0.114,
    val baselineOffset: Double = 0.0,
    val scale: Double = 1.0,
    val cameraAwbMode: String = "LOCKED"
) {
    /**
     * Calculates the calibrated pixel intensity from an ARGB pixel value.
     */
    fun calculatePixelIntensity(pixel: Int): Double {
        val r = android.graphics.Color.red(pixel)
        val g = android.graphics.Color.green(pixel)
        val b = android.graphics.Color.blue(pixel)

        // Exact OpenCV BGR2GRAY integer math for perfect scientific matching
        return if (presetName == "Standard Luminance (Rec. 601)" || (redWeight == 0.299 && greenWeight == 0.587 && blueWeight == 0.114)) {
            ((r * 299 + g * 587 + b * 114 + 500) / 1000.0) + baselineOffset
        } else {
            val raw = (r * redWeight + g * greenWeight + b * blueWeight + baselineOffset) * scale
            raw.coerceAtLeast(0.0)
        }
    }

    /**
     * Formats the mathematical formula representation for display in UI.
     */
    fun formatFormula(): String {
        val offsetSign = if (baselineOffset >= 0) "+" else "-"
        val offsetVal = abs(baselineOffset)
        return String.format(
            Locale.US,
            "I = (%.3f·R + %.3f·G + %.3f·B %s %.2f) × %.2f",
            redWeight, greenWeight, blueWeight, offsetSign, offsetVal, scale
        )
    }
}

/**
 * Manages persisting and retrieving WhiteConstantConfig profiles in SharedPreferences.
 */
object WhiteConstantManager {
    private const val PREFS_NAME = "white_constant_prefs"
    private const val KEY_PRESET = "preset_name"
    private const val KEY_RED = "red_weight"
    private const val KEY_GREEN = "green_weight"
    private const val KEY_BLUE = "blue_weight"
    private const val KEY_OFFSET = "baseline_offset"
    private const val KEY_SCALE = "scale"
    private const val KEY_AWB = "camera_awb_mode"

    val PRESETS = listOf(
        WhiteConstantConfig(
            presetName = "Standard Luminance (Rec. 601)",
            redWeight = 0.299,
            greenWeight = 0.587,
            blueWeight = 0.114,
            baselineOffset = 0.0,
            scale = 1.0,
            cameraAwbMode = "LOCKED"
        ),
        WhiteConstantConfig(
            presetName = "Equal Weights (RGB Average)",
            redWeight = 0.333,
            greenWeight = 0.333,
            blueWeight = 0.334,
            baselineOffset = 0.0,
            scale = 1.0,
            cameraAwbMode = "LOCKED"
        ),
        WhiteConstantConfig(
            presetName = "HDTV Luminance (Rec. 709)",
            redWeight = 0.2126,
            greenWeight = 0.7152,
            blueWeight = 0.0722,
            baselineOffset = 0.0,
            scale = 1.0,
            cameraAwbMode = "LOCKED"
        ),
        WhiteConstantConfig(
            presetName = "Green Dominant (Fluorescence)",
            redWeight = 0.100,
            greenWeight = 0.800,
            blueWeight = 0.100,
            baselineOffset = 0.0,
            scale = 1.0,
            cameraAwbMode = "LOCKED"
        ),
        WhiteConstantConfig(
            presetName = "Blue Dominant (Chemiluminescence)",
            redWeight = 0.100,
            greenWeight = 0.200,
            blueWeight = 0.700,
            baselineOffset = 0.0,
            scale = 1.0,
            cameraAwbMode = "LOCKED"
        )
    )

    fun getConfig(context: Context): WhiteConstantConfig {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val defaultPreset = PRESETS[0]
        return WhiteConstantConfig(
            presetName = prefs.getString(KEY_PRESET, defaultPreset.presetName) ?: defaultPreset.presetName,
            redWeight = prefs.getFloat(KEY_RED, defaultPreset.redWeight.toFloat()).toDouble(),
            greenWeight = prefs.getFloat(KEY_GREEN, defaultPreset.greenWeight.toFloat()).toDouble(),
            blueWeight = prefs.getFloat(KEY_BLUE, defaultPreset.blueWeight.toFloat()).toDouble(),
            baselineOffset = prefs.getFloat(KEY_OFFSET, defaultPreset.baselineOffset.toFloat()).toDouble(),
            scale = prefs.getFloat(KEY_SCALE, defaultPreset.scale.toFloat()).toDouble(),
            cameraAwbMode = prefs.getString(KEY_AWB, defaultPreset.cameraAwbMode) ?: defaultPreset.cameraAwbMode
        )
    }

    fun saveConfig(context: Context, config: WhiteConstantConfig) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_PRESET, config.presetName)
            .putFloat(KEY_RED, config.redWeight.toFloat())
            .putFloat(KEY_GREEN, config.greenWeight.toFloat())
            .putFloat(KEY_BLUE, config.blueWeight.toFloat())
            .putFloat(KEY_OFFSET, config.baselineOffset.toFloat())
            .putFloat(KEY_SCALE, config.scale.toFloat())
            .putString(KEY_AWB, config.cameraAwbMode)
            .apply()
    }

    fun resetToDefault(context: Context): WhiteConstantConfig {
        val defaultConfig = PRESETS[0]
        saveConfig(context, defaultConfig)
        return defaultConfig
    }
}

/**
 * Settings dialog for configuring White Constants and Camera Auto White Balance mode.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhiteConstantSettingsDialog(
    onDismiss: () -> Unit,
    onSave: (WhiteConstantConfig) -> Unit = {}
) {
    val context = LocalContext.current
    val initialConfig = remember { WhiteConstantManager.getConfig(context) }

    var selectedPreset by remember { mutableStateOf(initialConfig.presetName) }
    var redWeight by remember { mutableStateOf(initialConfig.redWeight) }
    var greenWeight by remember { mutableStateOf(initialConfig.greenWeight) }
    var blueWeight by remember { mutableStateOf(initialConfig.blueWeight) }
    var baselineOffset by remember { mutableStateOf(initialConfig.baselineOffset) }
    var scale by remember { mutableStateOf(initialConfig.scale) }
    var selectedAwbMode by remember { mutableStateOf(initialConfig.cameraAwbMode) }

    var isPresetDropdownExpanded by remember { mutableStateOf(false) }
    var isAwbDropdownExpanded by remember { mutableStateOf(false) }

    val awbModes = listOf("LOCKED", "AUTO", "DAYLIGHT", "INCANDESCENT", "FLUORESCENT", "CLOUDY", "SHADE")

    val currentConfig = WhiteConstantConfig(
        presetName = selectedPreset,
        redWeight = redWeight,
        greenWeight = greenWeight,
        blueWeight = blueWeight,
        baselineOffset = baselineOffset,
        scale = scale,
        cameraAwbMode = selectedAwbMode
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("white_constant_dialog"),
            shape = MaterialTheme.shapes.extraLarge,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "White Constant Calibration",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Tune RGB weights, baseline offset, and camera white balance for accurate intensity calculations.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                // Profile Preset Selector
                Text(
                    text = "Preset Profile",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                ExposedDropdownMenuBox(
                    expanded = isPresetDropdownExpanded,
                    onExpandedChange = { isPresetDropdownExpanded = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp)
                ) {
                    OutlinedTextField(
                        value = selectedPreset,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isPresetDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        textStyle = MaterialTheme.typography.bodyMedium
                    )
                    ExposedDropdownMenu(
                        expanded = isPresetDropdownExpanded,
                        onDismissRequest = { isPresetDropdownExpanded = false }
                    ) {
                        WhiteConstantManager.PRESETS.forEach { preset ->
                            DropdownMenuItem(
                                text = { Text(preset.presetName) },
                                onClick = {
                                    selectedPreset = preset.presetName
                                    redWeight = preset.redWeight
                                    greenWeight = preset.greenWeight
                                    blueWeight = preset.blueWeight
                                    baselineOffset = preset.baselineOffset
                                    scale = preset.scale
                                    selectedAwbMode = preset.cameraAwbMode
                                    isPresetDropdownExpanded = false
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Custom") },
                            onClick = {
                                selectedPreset = "Custom"
                                isPresetDropdownExpanded = false
                            }
                        )
                    }
                }

                // Camera AWB Mode
                Text(
                    text = "Camera White Balance (AWB)",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                ExposedDropdownMenuBox(
                    expanded = isAwbDropdownExpanded,
                    onExpandedChange = { isAwbDropdownExpanded = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp)
                ) {
                    OutlinedTextField(
                        value = selectedAwbMode,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isAwbDropdownExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth(),
                        textStyle = MaterialTheme.typography.bodyMedium
                    )
                    ExposedDropdownMenu(
                        expanded = isAwbDropdownExpanded,
                        onDismissRequest = { isAwbDropdownExpanded = false }
                    ) {
                        awbModes.forEach { mode ->
                            DropdownMenuItem(
                                text = { Text(mode) },
                                onClick = {
                                    selectedAwbMode = mode
                                    if (selectedPreset != "Custom") selectedPreset = "Custom"
                                    isAwbDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Sliders for RGB Weights
                Text(
                    text = "RGB Channel Weights",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )

                // Red Weight
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Red (R)", style = MaterialTheme.typography.bodyMedium)
                    Text(String.format(Locale.US, "%.3f", redWeight), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = redWeight.toFloat(),
                    onValueChange = {
                        redWeight = it.toDouble()
                        selectedPreset = "Custom"
                    },
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth()
                )

                // Green Weight
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Green (G)", style = MaterialTheme.typography.bodyMedium)
                    Text(String.format(Locale.US, "%.3f", greenWeight), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = greenWeight.toFloat(),
                    onValueChange = {
                        greenWeight = it.toDouble()
                        selectedPreset = "Custom"
                    },
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth()
                )

                // Blue Weight
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Blue (B)", style = MaterialTheme.typography.bodyMedium)
                    Text(String.format(Locale.US, "%.3f", blueWeight), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = blueWeight.toFloat(),
                    onValueChange = {
                        blueWeight = it.toDouble()
                        selectedPreset = "Custom"
                    },
                    valueRange = 0f..1f,
                    modifier = Modifier.fillMaxWidth()
                )

                // Baseline Offset
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Baseline Offset", style = MaterialTheme.typography.bodyMedium)
                    Text(String.format(Locale.US, "%.1f", baselineOffset), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = baselineOffset.toFloat(),
                    onValueChange = {
                        baselineOffset = it.toDouble()
                        selectedPreset = "Custom"
                    },
                    valueRange = -50f..50f,
                    modifier = Modifier.fillMaxWidth()
                )

                // Scale Factor
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Scale Factor", style = MaterialTheme.typography.bodyMedium)
                    Text(String.format(Locale.US, "%.2f", scale), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = scale.toFloat(),
                    onValueChange = {
                        scale = it.toDouble()
                        selectedPreset = "Custom"
                    },
                    valueRange = 0.1f..5f,
                    modifier = Modifier.fillMaxWidth()
                )

                // Live Formula Display
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Calculated Intensity Formula:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = currentConfig.formatFormula(),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            val reset = WhiteConstantManager.resetToDefault(context)
                            selectedPreset = reset.presetName
                            redWeight = reset.redWeight
                            greenWeight = reset.greenWeight
                            blueWeight = reset.blueWeight
                            baselineOffset = reset.baselineOffset
                            scale = reset.scale
                            selectedAwbMode = reset.cameraAwbMode
                        },
                        modifier = Modifier.testTag("white_constant_reset_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset")
                    }

                    Row {
                        TextButton(
                            onClick = onDismiss,
                            modifier = Modifier.testTag("white_constant_cancel_button")
                        ) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                WhiteConstantManager.saveConfig(context, currentConfig)
                                onSave(currentConfig)
                                onDismiss()
                            },
                            modifier = Modifier.testTag("white_constant_save_button")
                        ) {
                            Text("Apply")
                        }
                    }
                }
            }
        }
    }
}
