package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CalibrationDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCalibration(calibration: CalibrationEntity)

    @Delete
    suspend fun deleteCalibration(calibration: CalibrationEntity)

    @Query("SELECT * FROM calibrations ORDER BY timestamp DESC")
    fun getAllCalibrations(): Flow<List<CalibrationEntity>>
}
