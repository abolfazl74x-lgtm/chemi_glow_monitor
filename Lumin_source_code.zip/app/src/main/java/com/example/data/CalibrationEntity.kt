package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calibrations")
data class CalibrationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val slope: Double,
    val intercept: Double,
    val rSquared: Double,
    val unit: String,
    val featureName: String,
    val standardPointsJson: String = "[]",
    val timestamp: Long = System.currentTimeMillis()
)
