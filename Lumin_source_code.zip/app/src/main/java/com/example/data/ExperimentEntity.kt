package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "experiments")
data class ExperimentEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val experimentName: String,
    val timestamp: Long,
    val exposureTime: Int,
    val originalExposure: Float? = null,
    val sessionFolderPath: String,
    val peakTime: Double,
    val peakIntensity: Double,
    val totalAuc: Double,
    val highDuration: Double,
    val maxWindowAuc: Double,
    val maxWindowStartTime: Double,
    val maxWindowEndTime: Double
)
