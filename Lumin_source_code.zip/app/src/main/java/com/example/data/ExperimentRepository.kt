package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emptyFlow

class ExperimentRepository(
    private val experimentDao: ExperimentDao,
    private val calibrationDao: CalibrationDao? = null
) {

    val allExperiments: Flow<List<ExperimentEntity>> = experimentDao.getAllExperiments()
    val savedCalibrations: Flow<List<CalibrationEntity>> =
        calibrationDao?.getAllCalibrations() ?: emptyFlow()

    suspend fun insertExperiment(experiment: ExperimentEntity) {
        experimentDao.insertExperiment(experiment)
    }

    suspend fun deleteExperimentById(id: Int) {
        experimentDao.deleteExperimentById(id)
    }

    suspend fun insertCalibration(calibration: CalibrationEntity) {
        calibrationDao?.insertCalibration(calibration)
    }

    suspend fun deleteCalibration(calibration: CalibrationEntity) {
        calibrationDao?.deleteCalibration(calibration)
    }
}
