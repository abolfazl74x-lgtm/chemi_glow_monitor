import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                                onSaveExperiment = { exp ->
                                    viewModel.insert(exp)
                                    // Optionally navigate back to dashboard
                                }"""
replacement = """                                onSaveExperiment = { exp ->
                                    onSaveExperiment(exp)
                                    onBack()
                                }"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
