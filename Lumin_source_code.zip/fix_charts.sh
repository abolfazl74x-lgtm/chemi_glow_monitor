sed -i '/@Suppress("DEPRECATION")/d' app/src/main/java/com/example/VideoAnalysisScreen.kt
sed -i '/@Suppress("DEPRECATION")/d' app/src/main/java/com/example/AnalysisResultScreen.kt
sed -i '/@Suppress("DEPRECATION")/d' app/src/main/java/com/example/MainActivity.kt

sed -i 's/lineSpec(lineColor = MaterialTheme.colorScheme.primary, cubicStrength = 1f, point = null)/lineSpec(lineColor = MaterialTheme.colorScheme.primary, point = null, pointConnector = com.patrykandpatrick.vico.core.chart.line.DefaultPointConnector())/g' app/src/main/java/com/example/VideoAnalysisScreen.kt
sed -i 's/lineSpec(lineColor = MaterialTheme.colorScheme.primary, cubicStrength = 1f, point = null)/lineSpec(lineColor = MaterialTheme.colorScheme.primary, point = null, pointConnector = com.patrykandpatrick.vico.core.chart.line.DefaultPointConnector())/g' app/src/main/java/com/example/AnalysisResultScreen.kt
sed -i 's/lineSpec(lineColor = MaterialTheme.colorScheme.primary, cubicStrength = 1f, point = null)/lineSpec(lineColor = MaterialTheme.colorScheme.primary, point = null, pointConnector = com.patrykandpatrick.vico.core.chart.line.DefaultPointConnector())/g' app/src/main/java/com/example/MainActivity.kt
