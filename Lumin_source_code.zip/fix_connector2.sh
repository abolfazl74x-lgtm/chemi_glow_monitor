sed -i 's/cubicStrength = 1f/pointConnector = com.patrykandpatrick.vico.core.chart.DefaultPointConnector(cubicStrength = 0f)/g' app/src/main/java/com/example/VideoAnalysisScreen.kt
sed -i 's/cubicStrength = 1f/pointConnector = com.patrykandpatrick.vico.core.chart.DefaultPointConnector(cubicStrength = 0f)/g' app/src/main/java/com/example/AnalysisResultScreen.kt
sed -i 's/cubicStrength = 1f/pointConnector = com.patrykandpatrick.vico.core.chart.DefaultPointConnector(cubicStrength = 0f)/g' app/src/main/java/com/example/MainActivity.kt
