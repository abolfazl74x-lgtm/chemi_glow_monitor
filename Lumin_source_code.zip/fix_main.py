import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

batch_import_target = """                        } else if (currentRoute == "batch_import") {
                            var showNamingDialog by remember { mutableStateOf(false) }
                            var pendingFiles by remember { mutableStateOf<List<java.io.File>?>(null) }
                            
                            BatchImportScreen(
                                onBack = { currentRoute = "dashboard" },
                                onImportComplete = { files ->
                                    pendingFiles = files
                                    showNamingDialog = true
                                }
                            )
                            
                            if (showNamingDialog && pendingFiles != null) {
                                TestNamingDialog(
                                    onConfirm = { name ->
                                        showNamingDialog = false
                                        currentTestTitle = name
                                        val files = pendingFiles!!
                                        extractedVideoFrames = files
                                        currentRoute = "video_analysis"
                                        
                                        val sessionDir = files.firstOrNull()?.parentFile?.parentFile
                                        if (sessionDir != null) {
                                            val videoFile = java.io.File(sessionDir, "${name}.mp4")
                                            val framesDir = java.io.File(sessionDir, "frames")
                                            
                                            scope.launch {
                                                VideoEncoder.encodeImagesToVideoFlow(
                                                    imageDir = framesDir,
                                                    outputFile = videoFile,
                                                    totalFrames = files.size,
                                                    exposureTimeSeconds = 1f
                                                ).collect { state ->
                                                    when (state) {
                                                        is EncodingState.Success -> {
                                                            android.widget.Toast.makeText(this@MainActivity, "Video Encoding Complete!", android.widget.Toast.LENGTH_SHORT).show()
                                                        }
                                                        is EncodingState.Error -> {
                                                            android.util.Log.e("BatchImport", "Video encoding failed: ${state.message}")
                                                        }
                                                        else -> {}
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    onDismiss = { showNamingDialog = false }
                                )
                            }"""

batch_import_replacement = """                        } else if (currentRoute == "batch_import") {
                            BatchImportScreen(
                                onBack = { currentRoute = "dashboard" },
                                onImportComplete = { files, title ->
                                    currentTestTitle = title
                                    extractedVideoFrames = files
                                    currentRoute = "video_analysis"
                                    
                                    val sessionDir = files.firstOrNull()?.parentFile?.parentFile
                                    if (sessionDir != null) {
                                        val videoFile = java.io.File(sessionDir, "${title}.mp4")
                                        val framesDir = java.io.File(sessionDir, "frames")
                                        
                                        scope.launch {
                                            VideoEncoder.encodeImagesToVideoFlow(
                                                imageDir = framesDir,
                                                outputFile = videoFile,
                                                totalFrames = files.size,
                                                exposureTimeSeconds = 1f
                                            ).collect { state ->
                                                when (state) {
                                                    is EncodingState.Success -> {
                                                        android.widget.Toast.makeText(this@MainActivity, "Video Encoding Complete!", android.widget.Toast.LENGTH_SHORT).show()
                                                    }
                                                    is EncodingState.Error -> {
                                                        android.util.Log.e("BatchImport", "Video encoding failed: ${state.message}")
                                                    }
                                                    else -> {}
                                                }
                                            }
                                        }
                                    }
                                }
                            )"""

content = content.replace(batch_import_target, batch_import_replacement)

video_picker_target = """                        } else if (currentRoute == "video_picker") {
                            var showNamingDialog by remember { mutableStateOf(false) }
                            var pendingFiles by remember { mutableStateOf<List<java.io.File>?>(null) }
                            VideoPickerScreen(
                                onBack = { currentRoute = "dashboard" },
                                onFramesExtracted = { files ->
                                    pendingFiles = files
                                    showNamingDialog = true
                                }
                            )
                            if (showNamingDialog && pendingFiles != null) {
                                TestNamingDialog(
                                    onConfirm = { name ->
                                        showNamingDialog = false
                                        currentTestTitle = name
                                        extractedVideoFrames = pendingFiles!!
                                        currentRoute = "video_analysis"
                                    },
                                    onDismiss = { showNamingDialog = false }
                                )
                            }"""

video_picker_replacement = """                        } else if (currentRoute == "video_picker") {
                            VideoPickerScreen(
                                onBack = { currentRoute = "dashboard" },
                                onFramesExtracted = { files, title ->
                                    currentTestTitle = title
                                    extractedVideoFrames = files
                                    currentRoute = "video_analysis"
                                }
                            )"""

content = content.replace(video_picker_target, video_picker_replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
