import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

# 1. Add currentTestTitle to MainActivity
content = content.replace(
    "var extractedVideoFrames by remember { mutableStateOf<List<java.io.File>>(emptyList()) }",
    "var extractedVideoFrames by remember { mutableStateOf<List<java.io.File>>(emptyList()) }\n                var currentTestTitle by remember { mutableStateOf(\"\") }"
)

# 2. Update BatchImportScreen to show dialog
batch_import_target = """                        } else if (currentRoute == "batch_import") {
                            BatchImportScreen(
                                onBack = { currentRoute = "dashboard" },
                                onImportComplete = { files ->
                                    extractedVideoFrames = files
                                    currentRoute = "video_analysis"
                                    
                                    // Start asynchronous video encoding for the imported frames
                                    val sessionDir = files.firstOrNull()?.parentFile?.parentFile
                                    if (sessionDir != null) {
                                        val videoFile = java.io.File(sessionDir, "nightlapse.mp4")
                                        val framesDir = java.io.File(sessionDir, "frames")
                                        
                                        scope.launch {
                                            VideoEncoder.encodeImagesToVideoFlow(
                                                imageDir = framesDir,
                                                outputFile = videoFile,
                                                totalFrames = files.size,
                                                exposureTimeSeconds = 1f // Assuming 1 fps for imported frames by default
                                            ).collect { state ->
                                                when (state) {
                                                    is EncodingState.Success -> {
                                                        android.widget.Toast.makeText(this@MainActivity, "Video Encoding Complete!", android.widget.Toast.LENGTH_SHORT).show()
                                                    }
                                                    is EncodingState.Error -> {
                                                        android.util.Log.e("BatchImport", "Video encoding failed: ${state.message}")
                                                    }
                                                    else -> {}
                                                }
                                            }
                                        }
                                    }
                                }
                            )"""

batch_import_replacement = """                        } else if (currentRoute == "batch_import") {
                            var showNamingDialog by remember { mutableStateOf(false) }
                            var pendingFiles by remember { mutableStateOf<List<java.io.File>?>(null) }
                            
                            BatchImportScreen(
                                onBack = { currentRoute = "dashboard" },
                                onImportComplete = { files ->
                                    pendingFiles = files
                                    showNamingDialog = true
                                }
                            )
                            
                            if (showNamingDialog && pendingFiles != null) {
                                TestNamingDialog(
                                    onConfirm = { name ->
                                        showNamingDialog = false
                                        currentTestTitle = name
                                        val files = pendingFiles!!
                                        extractedVideoFrames = files
                                        currentRoute = "video_analysis"
                                        
                                        val sessionDir = files.firstOrNull()?.parentFile?.parentFile
                                        if (sessionDir != null) {
                                            val videoFile = java.io.File(sessionDir, "${name}.mp4")
                                            val framesDir = java.io.File(sessionDir, "frames")
                                            
                                            scope.launch {
                                                VideoEncoder.encodeImagesToVideoFlow(
                                                    imageDir = framesDir,
                                                    outputFile = videoFile,
                                                    totalFrames = files.size,
                                                    exposureTimeSeconds = 1f
                                                ).collect { state ->
                                                    when (state) {
                                                        is EncodingState.Success -> {
                                                            android.widget.Toast.makeText(this@MainActivity, "Video Encoding Complete!", android.widget.Toast.LENGTH_SHORT).show()
                                                        }
                                                        is EncodingState.Error -> {
                                                            android.util.Log.e("BatchImport", "Video encoding failed: ${state.message}")
                                                        }
                                                        else -> {}
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    onDismiss = { showNamingDialog = false }
                                )
                            }"""
content = content.replace(batch_import_target, batch_import_replacement)

# 3. Update VideoPickerScreen
video_picker_target = """                        } else if (currentRoute == "video_picker") {
                            VideoPickerScreen(
                                onBack = { currentRoute = "dashboard" },
                                onFramesExtracted = { files ->
                                    extractedVideoFrames = files
                                    currentRoute = "video_analysis"
                                }
                            )"""

video_picker_replacement = """                        } else if (currentRoute == "video_picker") {
                            var showNamingDialog by remember { mutableStateOf(false) }
                            var pendingFiles by remember { mutableStateOf<List<java.io.File>?>(null) }
                            VideoPickerScreen(
                                onBack = { currentRoute = "dashboard" },
                                onFramesExtracted = { files ->
                                    pendingFiles = files
                                    showNamingDialog = true
                                }
                            )
                            if (showNamingDialog && pendingFiles != null) {
                                TestNamingDialog(
                                    onConfirm = { name ->
                                        showNamingDialog = false
                                        currentTestTitle = name
                                        extractedVideoFrames = pendingFiles!!
                                        currentRoute = "video_analysis"
                                    },
                                    onDismiss = { showNamingDialog = false }
                                )
                            }"""
content = content.replace(video_picker_target, video_picker_replacement)

# 4. Update VideoAnalysisScreen call
video_analysis_target = """                            VideoAnalysisScreen(
                                files = extractedVideoFrames,
                                onBack = { currentRoute = "dashboard" },"""

video_analysis_replacement = """                            VideoAnalysisScreen(
                                files = extractedVideoFrames,
                                testTitle = currentTestTitle,
                                onBack = { currentRoute = "dashboard" },"""
content = content.replace(video_analysis_target, video_analysis_replacement)


# 5. Add testTitle to CameraScreen
camera_screen_vars = """    var currentSessionDir by remember { mutableStateOf<File?>(null) }"""
camera_screen_vars_replacement = """    var currentSessionDir by remember { mutableStateOf<File?>(null) }
    var showNamingDialog by remember { mutableStateOf(false) }
    var testTitle by remember { mutableStateOf("") }"""
content = content.replace(camera_screen_vars, camera_screen_vars_replacement)


# 6. Update CameraScreen capture logic
capture_target = """                                isCapturing = false
                                if (success) {
                                    isEncoding = true
                                    encodingProgress = 0
                                    val videoFile = File(sessionDir, "nightlapse.mp4")
                                    
                                    VideoEncoder.encodeImagesToVideoFlow(
                                        imageDir = outputDir,
                                        outputFile = videoFile,
                                        totalFrames = totalFrames,
                                        exposureTimeSeconds = selectedExposure
                                    ).collect { state ->
                                        when (state) {
                                            is EncodingState.Progress -> {
                                                encodingProgress = state.percent
                                            }
                                            is EncodingState.Success -> {
                                                isEncoding = false
                                                outputVideo = state.file
                                            }
                                            is EncodingState.Error -> {
                                                isEncoding = false
                                                errorMessage = "Video encoding failed: ${state.message}"
                                            }
                                        }
                                    }
                                } else {
                                    errorMessage = "Capture sequence failed."
                                }"""

capture_replacement = """                                isCapturing = false
                                if (success) {
                                    showNamingDialog = true
                                } else {
                                    errorMessage = "Capture sequence failed."
                                }"""
content = content.replace(capture_target, capture_replacement)


# 7. Add Dialog to CameraScreen
# We can inject it right before `DisposableEffect(Unit) {`
dialog_target = """    DisposableEffect(Unit) {"""
dialog_replacement = """    if (showNamingDialog) {
        TestNamingDialog(
            onConfirm = { name ->
                showNamingDialog = false
                testTitle = name
                
                scope.launch {
                    isEncoding = true
                    encodingProgress = 0
                    val sessionDir = currentSessionDir!!
                    val outputDir = File(sessionDir, "frames")
                    val videoFile = File(sessionDir, "${name}.mp4")
                    
                    VideoEncoder.encodeImagesToVideoFlow(
                        imageDir = outputDir,
                        outputFile = videoFile,
                        totalFrames = totalFrames,
                        exposureTimeSeconds = selectedExposure
                    ).collect { state ->
                        when (state) {
                            is EncodingState.Progress -> {
                                encodingProgress = state.percent
                            }
                            is EncodingState.Success -> {
                                isEncoding = false
                                outputVideo = state.file
                            }
                            is EncodingState.Error -> {
                                isEncoding = false
                                errorMessage = "Video encoding failed: ${state.message}"
                            }
                        }
                    }
                }
            },
            onDismiss = {
                showNamingDialog = false
                errorMessage = "Capture sequence completed, but video encoding was cancelled."
            }
        )
    }

    DisposableEffect(Unit) {"""
content = content.replace(dialog_target, dialog_replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)

