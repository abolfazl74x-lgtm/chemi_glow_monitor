import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """    if (analysisResults != null && analysisParams != null) {
        val videoFile = currentSessionDir?.let { java.io.File(it, "nightlapse.mp4") }
        
        AnalysisResultScreen(
            results = analysisResults!!,
            params = analysisParams!!,
            videoFile = videoFile,
            onDismiss = { analysisResults = null },"""

replacement = """    if (analysisResults != null && analysisParams != null) {
        val videoFile = currentSessionDir?.let { java.io.File(it, "${testTitle}.mp4") }
        
        AnalysisResultScreen(
            results = analysisResults!!,
            params = analysisParams!!,
            videoFile = videoFile,
            testTitle = testTitle,
            onDismiss = { analysisResults = null },"""

content = content.replace(target, replacement)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
