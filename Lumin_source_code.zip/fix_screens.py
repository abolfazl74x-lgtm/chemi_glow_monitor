import re

with open("app/src/main/java/com/example/BatchImportScreen.kt", "r") as f:
    content = f.read()

content = content.replace(
    "onImportComplete: (List<File>) -> Unit",
    "onImportComplete: (List<File>, String) -> Unit"
)

target_batch = """                        withContext(Dispatchers.Main) {
                            importStatus = "Import Complete!"
                            onImportComplete(copiedFiles)
                        }"""
replacement_batch = """                        val title = if (sortedUris.isNotEmpty()) {
                            FileUtil.extractOriginalFilename(context, sortedUris.first())
                        } else {
                            "imported_batch"
                        }
                        withContext(Dispatchers.Main) {
                            importStatus = "Import Complete!"
                            onImportComplete(copiedFiles, title)
                        }"""
content = content.replace(target_batch, replacement_batch)

with open("app/src/main/java/com/example/BatchImportScreen.kt", "w") as f:
    f.write(content)

# -----------------

with open("app/src/main/java/com/example/VideoPickerScreen.kt", "r") as f:
    content = f.read()

content = content.replace(
    "onFramesExtracted: (List<File>) -> Unit",
    "onFramesExtracted: (List<File>, String) -> Unit"
)

target_video = """    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            isExtracting = true
            coroutineScope.launch {
                val extractedFiles = extractFramesFromVideo(context, uri)
                isExtracting = false
                onFramesExtracted(extractedFiles)
            }
        }
    }"""
replacement_video = """    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            isExtracting = true
            val title = FileUtil.extractOriginalFilename(context, uri)
            coroutineScope.launch {
                val extractedFiles = extractFramesFromVideo(context, uri)
                isExtracting = false
                onFramesExtracted(extractedFiles, title)
            }
        }
    }"""
content = content.replace(target_video, replacement_video)

with open("app/src/main/java/com/example/VideoPickerScreen.kt", "w") as f:
    f.write(content)
