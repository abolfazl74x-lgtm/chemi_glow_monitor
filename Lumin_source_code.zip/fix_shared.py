import re

with open("app/src/main/java/com/example/SharedResultsView.kt", "r") as f:
    content = f.read()

content = content.replace("RoiAnalysisResult", "IntensityResult")
content = content.replace("AdvancedAnalysisResult", "AnalysisResults")

with open("app/src/main/java/com/example/SharedResultsView.kt", "w") as f:
    f.write(content)
