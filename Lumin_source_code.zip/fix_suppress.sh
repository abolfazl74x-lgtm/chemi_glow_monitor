sed -i '1s/^/@file:Suppress("DEPRECATION")\n/' app/src/main/java/com/example/VideoAnalysisScreen.kt
sed -i '1s/^/@file:Suppress("DEPRECATION")\n/' app/src/main/java/com/example/AnalysisResultScreen.kt
sed -i '1s/^/@file:Suppress("DEPRECATION")\n/' app/src/main/java/com/example/MainActivity.kt

sed -i 's/lineSpec(lineColor = MaterialTheme.colorScheme.primary, point = null, pointConnector = com.patrykandpatrick.vico.core.chart.line.DefaultPointConnector())/lineSpec(lineColor = MaterialTheme.colorScheme.primary, cubicStrength = 1f, point = null)/g' app/src/main/java/com/example/VideoAnalysisScreen.kt
sed -i 's/lineSpec(lineColor = MaterialTheme.colorScheme.primary, point = null, pointConnector = com.patrykandpatrick.vico.core.chart.line.DefaultPointConnector())/lineSpec(lineColor = MaterialTheme.colorScheme.primary, cubicStrength = 1f, point = null)/g' app/src/main/java/com/example/AnalysisResultScreen.kt
sed -i 's/lineSpec(lineColor = MaterialTheme.colorScheme.primary, point = null, pointConnector = com.patrykandpatrick.vico.core.chart.line.DefaultPointConnector())/lineSpec(lineColor = MaterialTheme.colorScheme.primary, cubicStrength = 1f, point = null)/g' app/src/main/java/com/example/MainActivity.kt
