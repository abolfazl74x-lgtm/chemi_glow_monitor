import re

with open("gradle/libs.versions.toml", "r") as f:
    content = f.read()

# Remove the incorrectly appended lines at the end
content = re.sub(r'\[versions\]\nmedia3 = "1.4.1"\nandroidx-media3-exoplayer = .*?\nandroidx-media3-ui = .*?\n', '', content)

# Add media3 version under [versions]
content = content.replace('[libraries]', 'media3 = "1.4.1"\n\n[libraries]')

# Add media3 libs under [libraries]
content = content.replace('[plugins]', 'androidx-media3-exoplayer = { group = "androidx.media3", name = "media3-exoplayer", version.ref = "media3" }\nandroidx-media3-ui = { group = "androidx.media3", name = "media3-ui", version.ref = "media3" }\n\n[plugins]')

with open("gradle/libs.versions.toml", "w") as f:
    f.write(content)

