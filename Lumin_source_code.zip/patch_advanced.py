import re

with open("app/src/main/java/com/example/AdvancedAnalysisScreen.kt", "r") as f:
    content = f.read()

# 1. Update the signature
target_signature = """fun AdvancedAnalysisScreen(
    rawResults: List<IntensityResult>,
    exposureTime: Float,"""

replacement_signature = """fun AdvancedAnalysisScreen(
    rawResults: List<IntensityResult>?,
    exposureTime: Float,"""
content = content.replace(target_signature, replacement_signature)

# 2. Update Scaffold and fallback UI
target_scaffold = """    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Advanced Analysis") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(16.dp)
        ) {"""

replacement_scaffold = """    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text("Advanced Analysis") },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { padding ->
            if (rawResults.isNullOrEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentAlignment = androidx.compose.ui.Alignment.Center
                ) {
                    Text(
                        text = "No data available",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(padding)
                        .padding(16.dp)
                ) {"""

content = content.replace(target_scaffold, replacement_scaffold)

# 3. Handle rawResults mapping
target_run_button = """                            val rawData = rawResults.map { 
                                Pair((it.frameIndex * exposureTime).toDouble(), it.averageIntensity) 
                            }"""

replacement_run_button = """                            val rawData = rawResults.map { 
                                Pair((it.frameIndex * exposureTime).toDouble(), it.averageIntensity) 
                            }"""

# 4. Add the closing brace for the else block
target_end = """                }
            }
        }
    }
}

@Composable"""

replacement_end = """                }
            }
        }
    }
    }
}

@Composable"""

content = content.replace(target_end, replacement_end)

with open("app/src/main/java/com/example/AdvancedAnalysisScreen.kt", "w") as f:
    f.write(content)
print("Patched AdvancedAnalysisScreen")
