import re

with open("app/src/main/java/com/example/AdvancedAnalysisScreen.kt", "r") as f:
    content = f.read()

target = """    }
    }
}

@Composable
fun SettingsNumberField"""

replacement = """    }
    }
}
}

@Composable
fun SettingsNumberField"""

if target in content:
    content = content.replace(target, replacement)
    print("Added missing brace")
else:
    print("Target not found")

with open("app/src/main/java/com/example/AdvancedAnalysisScreen.kt", "w") as f:
    f.write(content)
