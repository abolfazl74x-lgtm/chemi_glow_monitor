import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target_camera_call = """                        } else if (currentRoute == "camera") {
                            if (cameraPermissionState.status.isGranted) {
                                CameraScreen(
                                    onBack = { currentRoute = "dashboard" },
                                    onSaveExperiment = { exp ->
                                        viewModel.insert(exp)
                                        currentRoute = "dashboard"
                                    }
                                )"""

replacement_camera_call = """                        } else if (currentRoute == "camera") {
                            if (cameraPermissionState.status.isGranted) {
                                CameraScreen(
                                    onBack = { currentRoute = "dashboard" },
                                    onSaveExperiment = { exp ->
                                        viewModel.insert(exp)
                                        currentRoute = "dashboard"
                                    },
                                    onNavigateToAdvancedAnalysis = { data, exposure, title, path ->
                                        advancedAnalysisRawData = data
                                        advancedAnalysisExposureTime = exposure
                                        advancedAnalysisTestTitle = title
                                        advancedAnalysisSessionPath = path
                                        currentRoute = "advanced_analysis"
                                    }
                                )"""

content = content.replace(target_camera_call, replacement_camera_call)

target_camera_sig = """fun CameraScreen(
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit
) {"""

replacement_camera_sig = """fun CameraScreen(
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit,
    onNavigateToAdvancedAnalysis: (List<IntensityResult>, Float, String, String) -> Unit
) {"""

content = content.replace(target_camera_sig, replacement_camera_sig)

target_camera_shared = """                                onNavigateToAdvancedAnalysis = {
                                    advancedAnalysisRawData = roiResults!!
                                    advancedAnalysisExposureTime = selectedExposure
                                    advancedAnalysisTestTitle = testTitle
                                    advancedAnalysisSessionPath = currentSessionDir?.absolutePath ?: ""
                                    currentRoute = "advanced_analysis"
                                }"""

replacement_camera_shared = """                                onNavigateToAdvancedAnalysis = {
                                    onNavigateToAdvancedAnalysis(
                                        roiResults!!,
                                        selectedExposure,
                                        testTitle,
                                        currentSessionDir?.absolutePath ?: ""
                                    )
                                }"""

content = content.replace(target_camera_shared, replacement_camera_shared)

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
