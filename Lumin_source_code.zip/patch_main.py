import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                        } else if (roiResults != null) {
                            var isExportingCsv by remember { mutableStateOf(false) }
                            var csvExportResult by remember { mutableStateOf<String?>(null) }
                            
                            if (csvExportResult != null) {
                                Text(csvExportResult!!, style = MaterialTheme.typography.bodyMedium, color = Color.Green)
                            } else if (isExportingCsv) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White)
                            } else {
                                Button(
                                    onClick = {
                                        scope.launch {
                                            isExportingCsv = true
                                            val currentDir = currentSessionDir
                                            if (currentDir != null) {
                                                val file = CsvExporter.exportKineticsToCsv(currentDir, roiResults!!, selectedExposure.toInt(), testTitle)
                                                csvExportResult = if (file != null) "CSV Saved in Session Folder!" else "CSV Export Failed"
                                            } else {
                                                csvExportResult = "No active session!"
                                            }
                                            isExportingCsv = false
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Export ROI Kinetics (CSV)")
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { showChartDialog = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("View Kinetics Chart")
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { showAdvancedSettings = true },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Advanced Analysis")
                                }
                            }
                        } else {"""

replacement = """                        } else if (roiResults != null) {
                            SharedResultsView(
                                roiResults = roiResults!!,
                                sessionFolder = currentSessionDir,
                                testTitle = testTitle,
                                exposureTime = selectedExposure,
                                onBack = { },
                                onSaveExperiment = { exp ->
                                    viewModel.insert(exp)
                                    // Optionally navigate back to dashboard
                                }
                            )
                        } else {"""

if target in content:
    content = content.replace(target, replacement)
    
    # Remove the duplicate Advanced Settings UI that is currently in MainActivity
    
    target2 = """    if (showAdvancedSettings && roiResults != null) {
        AdvancedAnalysisSettingsScreen(
            onRunAnalysis = { params ->
                val rawData = roiResults!!.map { 
                    Pair((it.frameIndex * selectedExposure).toDouble(), it.averageIntensity) 
                }
                val results = SignalProcessor.analyze(rawData, params)
                analysisParams = params
                analysisResults = results
                showAdvancedSettings = false
            },
            onCancel = { showAdvancedSettings = false }
        )
        return
    }
    
    if (analysisResults != null && analysisParams != null) {
        val videoFile = currentSessionDir?.let { java.io.File(it, "${testTitle}.mp4") }
        
        AnalysisResultScreen(
            results = analysisResults!!,
            params = analysisParams!!,
            videoFile = videoFile,
            testTitle = testTitle,
            onDismiss = { analysisResults = null },
            onSave = { name ->
                val entity = ExperimentEntity(
                    experimentName = name,
                    timestamp = System.currentTimeMillis(),
                    exposureTime = selectedExposure.toInt(),
                    sessionFolderPath = currentSessionDir?.absolutePath ?: "",
                    peakTime = analysisResults!!.peakTime,
                    peakIntensity = analysisResults!!.peakIntensity,
                    totalAuc = analysisResults!!.totalAuc,
                    highDuration = analysisResults!!.highDuration,
                    maxWindowAuc = analysisResults!!.maxWindowAuc,
                    maxWindowStartTime = analysisResults!!.maxWindowStartTime,
                    maxWindowEndTime = analysisResults!!.maxWindowEndTime
                )
                onSaveExperiment(entity)
            }
        )
        return
    }"""
    
    content = content.replace(target2, "")

    with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
        f.write(content)
    print("MainActivity.kt patched.")
else:
    print("Target not found in MainActivity.kt")

