import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target_states = """                var extractedVideoFrames by remember { mutableStateOf<List<java.io.File>>(emptyList()) }
                var currentTestTitle by remember { mutableStateOf("") }"""

replacement_states = """                var extractedVideoFrames by remember { mutableStateOf<List<java.io.File>>(emptyList()) }
                var currentTestTitle by remember { mutableStateOf("") }
                
                var advancedAnalysisRawData by remember { mutableStateOf<List<IntensityResult>?>(null) }
                var advancedAnalysisExposureTime by remember { mutableStateOf(1f) }
                var advancedAnalysisTestTitle by remember { mutableStateOf("") }
                var advancedAnalysisSessionPath by remember { mutableStateOf("") }"""

content = content.replace(target_states, replacement_states)

# Update CameraScreen's SharedResultsView
target_camera_shared = """                            SharedResultsView(
                                roiResults = roiResults!!,
                                sessionFolder = currentSessionDir,
                                testTitle = testTitle,
                                exposureTime = selectedExposure,
                                onBack = { },
                                onSaveExperiment = { exp ->
                                    onSaveExperiment(exp)
                                    onBack()
                                }
                            )"""

replacement_camera_shared = """                            SharedResultsView(
                                roiResults = roiResults!!,
                                sessionFolder = currentSessionDir,
                                testTitle = testTitle,
                                exposureTime = selectedExposure,
                                onBack = { },
                                onSaveExperiment = { exp ->
                                    onSaveExperiment(exp)
                                    onBack()
                                },
                                onNavigateToAdvancedAnalysis = {
                                    advancedAnalysisRawData = roiResults!!
                                    advancedAnalysisExposureTime = selectedExposure
                                    advancedAnalysisTestTitle = testTitle
                                    advancedAnalysisSessionPath = currentSessionDir?.absolutePath ?: ""
                                    currentRoute = "advanced_analysis"
                                }
                            )"""

content = content.replace(target_camera_shared, replacement_camera_shared)

# Update VideoAnalysisScreen routing
target_video_analysis = """                        } else if (currentRoute == "video_analysis") {
                            VideoAnalysisScreen(
                                files = extractedVideoFrames,
                                testTitle = currentTestTitle,
                                onBack = { currentRoute = "dashboard" },
                                onSaveExperiment = { exp ->
                                    viewModel.insert(exp)
                                    currentRoute = "dashboard"
                                }
                            )"""

replacement_video_analysis = """                        } else if (currentRoute == "video_analysis") {
                            VideoAnalysisScreen(
                                files = extractedVideoFrames,
                                testTitle = currentTestTitle,
                                onBack = { currentRoute = "dashboard" },
                                onSaveExperiment = { exp ->
                                    viewModel.insert(exp)
                                    currentRoute = "dashboard"
                                },
                                onNavigateToAdvancedAnalysis = { data, exposure, title, path ->
                                    advancedAnalysisRawData = data
                                    advancedAnalysisExposureTime = exposure
                                    advancedAnalysisTestTitle = title
                                    advancedAnalysisSessionPath = path
                                    currentRoute = "advanced_analysis"
                                }
                            )"""

content = content.replace(target_video_analysis, replacement_video_analysis)

# Add the advanced_analysis route
target_dashboard_routing = """                        } else if (currentRoute == "dashboard") {"""

replacement_dashboard_routing = """                        } else if (currentRoute == "advanced_analysis") {
                            if (advancedAnalysisRawData != null) {
                                AdvancedAnalysisScreen(
                                    rawResults = advancedAnalysisRawData!!,
                                    exposureTime = advancedAnalysisExposureTime,
                                    testTitle = advancedAnalysisTestTitle,
                                    sessionFolderPath = advancedAnalysisSessionPath,
                                    onBack = { currentRoute = "dashboard" },
                                    onSaveExperiment = { exp ->
                                        viewModel.insert(exp)
                                        currentRoute = "dashboard"
                                    }
                                )
                            }
                        } else if (currentRoute == "dashboard") {"""

content = content.replace(target_dashboard_routing, replacement_dashboard_routing)

# Also remove old state variables in MainActivity if they still exist
target_old_states = """    var showAdvancedSettings by remember { mutableStateOf(false) }
    var analysisResults by remember { mutableStateOf<AnalysisResults?>(null) }
    var analysisParams by remember { mutableStateOf<AdvancedAnalysisParams?>(null) }"""

content = content.replace(target_old_states, "")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
print("MainActivity patched")
