import re

with open("app/src/main/java/com/example/MainActivity.kt", "r") as f:
    content = f.read()

target = """                        } else if (currentRoute == "calibration_result") {
                            if (calibrationResult != null) {
                                CalibrationResultScreen(
                                    result = calibrationResult!!,
                                    featureName = calibrationFeature,
                                    onBack = { currentRoute = "dashboard" }
                                )
                            }
                        }"""

replacement = """                        } else if (currentRoute == "calibration_result") {
                            if (calibrationResult != null) {
                                CalibrationResultScreen(
                                    result = calibrationResult!!,
                                    featureName = calibrationFeature,
                                    onBack = { currentRoute = "dashboard" }
                                )
                            }
                        } else if (currentRoute == "advanced_analysis") {
                            AdvancedAnalysisScreen(
                                rawResults = advancedAnalysisRawData,
                                exposureTime = advancedAnalysisExposureTime,
                                testTitle = advancedAnalysisTestTitle,
                                sessionFolderPath = advancedAnalysisSessionPath,
                                onBack = { currentRoute = "dashboard" },
                                onSaveExperiment = { exp ->
                                    viewModel.insert(exp)
                                    currentRoute = "dashboard"
                                }
                            )
                        }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced")
else:
    print("Target not found")

with open("app/src/main/java/com/example/MainActivity.kt", "w") as f:
    f.write(content)
