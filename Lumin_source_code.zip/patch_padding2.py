import re

with open("app/src/main/java/com/example/AdvancedAnalysisScreen.kt", "r") as f:
    content = f.read()

target = """                                labelComponent = com.patrykandpatrick.vico.compose.component.textComponent(
                                    color = androidx.compose.ui.graphics.Color.White,
                                    background = com.patrykandpatrick.vico.compose.component.shapeComponent(
                                        shape = Shapes.pillShape,
                                        color = androidx.compose.ui.graphics.Color.Red
                                    ),
                                    padding = com.patrykandpatrick.vico.compose.dimensions.dimensionsOf(4.dp)
                                )"""

replacement = """                                labelComponent = com.patrykandpatrick.vico.core.component.text.TextComponent.Builder().apply {
                                    color = android.graphics.Color.WHITE
                                    background = com.patrykandpatrick.vico.core.component.shape.ShapeComponent(
                                        color = android.graphics.Color.RED,
                                        shape = Shapes.pillShape
                                    )
                                }.build()"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced with core TextComponent")
else:
    print("Not found")

with open("app/src/main/java/com/example/AdvancedAnalysisScreen.kt", "w") as f:
    f.write(content)
