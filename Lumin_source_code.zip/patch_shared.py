import re

with open("app/src/main/java/com/example/SharedResultsView.kt", "r") as f:
    content = f.read()

target = """                        if (sessionFolder != null) {
                            val file = CsvExporter.exportKineticsToCsv(sessionFolder, roiResults, exposureTime.toInt(), testTitle)
                            if (file != null) {
                                Toast.makeText(context, "CSV Saved: ${file.name}", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Failed to save CSV", Toast.LENGTH_LONG).show()
                            }
                        } else {
                            Toast.makeText(context, "No active session!", Toast.LENGTH_LONG).show()
                        }"""

replacement = """                        if (roiResults.isEmpty()) {
                            Toast.makeText(context, "No data to export", Toast.LENGTH_LONG).show()
                        } else {
                            val uri = CsvExporter.exportKineticsToCsv(context, roiResults, exposureTime, testTitle)
                            if (uri != null) {
                                Toast.makeText(context, "CSV Saved to Downloads folder", Toast.LENGTH_LONG).show()
                            } else {
                                Toast.makeText(context, "Failed to save CSV", Toast.LENGTH_LONG).show()
                            }
                        }"""

if target in content:
    content = content.replace(target, replacement)
    with open("app/src/main/java/com/example/SharedResultsView.kt", "w") as f:
        f.write(content)
    print("Patched successfully")
else:
    print("Target not found")
