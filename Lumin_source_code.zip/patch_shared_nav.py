import re

with open("app/src/main/java/com/example/SharedResultsView.kt", "r") as f:
    content = f.read()

target_signature = """fun SharedResultsView(
    roiResults: List<IntensityResult>,
    sessionFolder: File?,
    testTitle: String,
    exposureTime: Float,
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit
)"""

replacement_signature = """fun SharedResultsView(
    roiResults: List<IntensityResult>,
    sessionFolder: File?,
    testTitle: String,
    exposureTime: Float,
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit,
    onNavigateToAdvancedAnalysis: () -> Unit
)"""

content = content.replace(target_signature, replacement_signature)

target_states = """    var showAdvancedSettings by remember { mutableStateOf(false) }
    var analysisParams by remember { mutableStateOf<AdvancedAnalysisParams?>(null) }
    var analysisResults by remember { mutableStateOf<AnalysisResults?>(null) }"""

content = content.replace(target_states, "")

target_settings = """    if (showAdvancedSettings) {
        AdvancedAnalysisSettingsScreen(
            onRunAnalysis = { params ->
                val rawData = roiResults.map {
                    Pair((it.frameIndex * exposureTime).toDouble(), it.averageIntensity)
                }
                val results = SignalProcessor.analyze(rawData, params)
                analysisParams = params
                analysisResults = results
                showAdvancedSettings = false
            },
            onCancel = { showAdvancedSettings = false }
        )
        return
    }

    if (analysisResults != null && analysisParams != null) {
        val videoFile = sessionFolder?.let { File(it, "${testTitle}.mp4") }

        AnalysisResultScreen(
            results = analysisResults!!,
            params = analysisParams!!,
            videoFile = videoFile,
            testTitle = testTitle,
            onDismiss = { analysisResults = null },
            onSave = { name ->
                val entity = ExperimentEntity(
                    experimentName = name,
                    timestamp = System.currentTimeMillis(),
                    exposureTime = exposureTime.toInt(),
                    sessionFolderPath = sessionFolder?.absolutePath ?: "",
                    peakTime = analysisResults!!.peakTime,
                    peakIntensity = analysisResults!!.peakIntensity,
                    totalAuc = analysisResults!!.totalAuc,
                    highDuration = analysisResults!!.highDuration,
                    maxWindowAuc = analysisResults!!.maxWindowAuc,
                    maxWindowStartTime = analysisResults!!.maxWindowStartTime,
                    maxWindowEndTime = analysisResults!!.maxWindowEndTime
                )
                onSaveExperiment(entity)
            }
        )
        return
    }"""

content = content.replace(target_settings, "")

target_button = """        Button(
            onClick = { showAdvancedSettings = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Advanced Analysis")
        }"""

replacement_button = """        Button(
            onClick = onNavigateToAdvancedAnalysis,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Advanced Analysis")
        }"""

content = content.replace(target_button, replacement_button)

with open("app/src/main/java/com/example/SharedResultsView.kt", "w") as f:
    f.write(content)
print("SharedResultsView patched")
