import re

with open("app/src/main/java/com/example/AdvancedAnalysisScreen.kt", "r") as f:
    content = f.read()

target = """                        val thresholdLine = remember(highThresholdValue) {
                            ThresholdLine(
                                thresholdValue = highThresholdValue,
                                thresholdLabel = "High Threshold",
                                lineComponent = com.patrykandpatrick.vico.core.component.shape.ShapeComponent(
                                    color = android.graphics.Color.RED,
                                    strokeWidthDp = 2f
                                ),
                                labelComponent = com.patrykandpatrick.vico.core.component.text.TextComponent.Builder().apply {
                                    color = android.graphics.Color.WHITE
                                    background = com.patrykandpatrick.vico.core.component.shape.ShapeComponent(
                                        color = android.graphics.Color.RED,
                                        shape = Shapes.pillShape
                                    )
                                    padding = com.patrykandpatrick.vico.core.dimensions.MutableDimensions(4f, 4f, 4f, 4f)
                                }.build()
                            )
                        }"""

replacement = """                        val thresholdLine = remember(highThresholdValue) {
                            ThresholdLine(
                                thresholdValue = highThresholdValue,
                                thresholdLabel = "High Threshold",
                                lineComponent = com.patrykandpatrick.vico.core.component.shape.ShapeComponent(
                                    color = android.graphics.Color.RED,
                                    strokeWidthDp = 2f
                                ),
                                labelComponent = com.patrykandpatrick.vico.core.component.text.TextComponent.Builder().apply {
                                    color = android.graphics.Color.WHITE
                                    background = com.patrykandpatrick.vico.core.component.shape.ShapeComponent(
                                        color = android.graphics.Color.RED,
                                        shape = Shapes.pillShape
                                    )
                                    padding.set(4f, 4f, 4f, 4f)
                                }.build()
                            )
                        }"""

if target in content:
    content = content.replace(target, replacement)
    print("Replaced padding")
else:
    print("Target not found")
    
with open("app/src/main/java/com/example/AdvancedAnalysisScreen.kt", "w") as f:
    f.write(content)
