import re

with open("app/src/main/java/com/example/VideoAnalysisScreen.kt", "r") as f:
    content = f.read()

target = """            } else if (roiResults != null) {
                Text("Analysis Complete", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(24.dp))
                
                Button(
                    onClick = { showChartDialog = true },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Text("View Kinetics Chart")
                }
                
                Button(
                    onClick = {
                        val sessionFolder = files.firstOrNull()?.parentFile
                        if (sessionFolder != null) {
                            scope.launch {
                                val csvFile = CsvExporter.exportKineticsToCsv(sessionFolder, roiResults!!, 1, testTitle)
                                if (csvFile != null) {
                                    Toast.makeText(context, "CSV Saved: ${csvFile.name}", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to save CSV", Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Text("Export ROI Kinetics (CSV)")
                }
                
                Button(
                    onClick = { showAdvancedSettings = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Advanced Analysis")
                }
            }"""

replacement = """            } else if (roiResults != null) {
                SharedResultsView(
                    roiResults = roiResults!!,
                    sessionFolder = files.firstOrNull()?.parentFile,
                    testTitle = testTitle,
                    exposureTime = 1f, // Video frames are 1s interval (fps=1)
                    onBack = onBack,
                    onSaveExperiment = { exp -> 
                        onSaveExperiment(exp)
                        onBack()
                    }
                )
            }"""

if target in content:
    content = content.replace(target, replacement)
    
    target_dialog1 = """    if (showChartDialog) {
        val graphicsLayer = rememberGraphicsLayer()
        var isSavingImage by remember { mutableStateOf(false) }
        var imageSaveMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChartDialog = false },
            title = { Text("Kinetics Curve") },
            text = {
                Column {
                    if (imageSaveMessage != null) {
                        Text(
                            text = imageSaveMessage!!,
                            color = if (imageSaveMessage!!.contains("Failed") || imageSaveMessage!!.contains("Error")) Color.Red else Color.Green,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    val chartEntryModel = remember(roiResults) {
                        val entries = roiResults!!.map { 
                            FloatEntry(x = (it.frameIndex * 1f).toFloat(), y = it.averageIntensity.toFloat()) 
                        }
                        entryModelOf(entries)
                    }
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .background(MaterialTheme.colorScheme.surface) // Solid background for the exported PNG
                            .drawWithContent {
                                graphicsLayer.record {
                                    this@drawWithContent.drawContent()
                                }
                                drawContent()
                            }
                    ) {
                        Chart(
                            chart = lineChart(
                                lines = listOf(lineSpec(
                                    lineColor = MaterialTheme.colorScheme.primary,
                                    lineBackgroundShader = null
                                ))
                            ),
                            model = chartEntryModel,
                            startAxis = rememberStartAxis(),
                            bottomAxis = rememberBottomAxis(),
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showChartDialog = false }) {
                    Text("Close")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            isSavingImage = true
                            try {
                                val bitmap = graphicsLayer.toImageBitmap().asAndroidBitmap()
                                val uri = ImageExporter.exportBitmapToGallery(context, bitmap)
                                imageSaveMessage = if (uri != null) "Chart saved to MediaStore!" else "Failed to save chart"
                            } catch (e: Exception) {
                                imageSaveMessage = "Error: ${e.localizedMessage}"
                            }
                            isSavingImage = false
                        }
                    },
                    enabled = !isSavingImage
                ) {
                    Text(if (isSavingImage) "Saving..." else "Save as PNG")
                }
            }
        )
    }
    
    if (showAdvancedSettings && roiResults != null) {
        AdvancedAnalysisSettingsScreen(
            onRunAnalysis = { params ->
                val rawData = roiResults!!.map { 
                    val timeSeconds = it.frameIndex / fps
                    Pair(timeSeconds.toDouble(), it.averageIntensity) 
                }
                val results = SignalProcessor.analyze(rawData, params)
                analysisParams = params
                analysisResults = results
                showAdvancedSettings = false
            },
            onCancel = { showAdvancedSettings = false }
        )
        return
    }
    
    if (analysisResults != null && analysisParams != null) {
        val sessionDir = files.firstOrNull()?.parentFile
        val videoFile = sessionDir?.let { java.io.File(it, "${testTitle}.mp4") }
        
        AnalysisResultScreen(
            results = analysisResults!!,
            params = analysisParams!!,
            videoFile = videoFile,
            testTitle = testTitle,
            onDismiss = { analysisResults = null },
            onSave = { name ->
                val entity = ExperimentEntity(
                    experimentName = name,
                    timestamp = System.currentTimeMillis(),
                    exposureTime = 1, // Video frames are 1s interval (fps=1)
                    sessionFolderPath = files.firstOrNull()?.parent ?: "",
                    peakTime = analysisResults!!.peakTime,
                    peakIntensity = analysisResults!!.peakIntensity,
                    totalAuc = analysisResults!!.totalAuc,
                    highDuration = analysisResults!!.highDuration,
                    maxWindowAuc = analysisResults!!.maxWindowAuc,
                    maxWindowStartTime = analysisResults!!.maxWindowStartTime,
                    maxWindowEndTime = analysisResults!!.maxWindowEndTime
                )
                onSaveExperiment(entity)
            }
        )
        return
    }"""
    
    content = content.replace(target_dialog1, "")
    
    # We should also remove the duplicated state variables
    target_states = """    var showChartDialog by remember { mutableStateOf(false) }
    var showAdvancedSettings by remember { mutableStateOf(false) }
    var analysisParams by remember { mutableStateOf<AdvancedAnalysisParams?>(null) }
    var analysisResults by remember { mutableStateOf<AdvancedAnalysisResult?>(null) }"""
    
    content = content.replace(target_states, "")
    
    with open("app/src/main/java/com/example/VideoAnalysisScreen.kt", "w") as f:
        f.write(content)
    print("VideoAnalysisScreen.kt patched.")
else:
    print("Target not found in VideoAnalysisScreen.kt")
