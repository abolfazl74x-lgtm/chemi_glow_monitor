import re

with open("app/src/main/java/com/example/VideoAnalysisScreen.kt", "r") as f:
    content = f.read()

target = """    var showChartDialog by remember { mutableStateOf(false) }
    var showAdvancedSettings by remember { mutableStateOf(false) }
    
    var analysisResults by remember { mutableStateOf<AnalysisResults?>(null) }
    var analysisParams by remember { mutableStateOf<AdvancedAnalysisParams?>(null) }"""

content = content.replace(target, "")

with open("app/src/main/java/com/example/VideoAnalysisScreen.kt", "w") as f:
    f.write(content)
