import re

with open("app/src/main/java/com/example/VideoAnalysisScreen.kt", "r") as f:
    content = f.read()

# I will use string replacements for the exact blocks

block1 = """    if (showChartDialog && roiResults != null) {
        val graphicsLayer = rememberGraphicsLayer()
        var isSavingImage by remember { mutableStateOf(false) }
        var imageSaveMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showChartDialog = false },
            title = { Text("Kinetics Curve") },
            text = {
                Column {
                    if (imageSaveMessage != null) {
                        Text(
                            text = imageSaveMessage!!,
                            color = if (imageSaveMessage!!.contains("Failed") || imageSaveMessage!!.contains("Error")) Color.Red else Color.Green,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                    val chartEntryModel = remember(roiResults) {
                        val entries = roiResults!!.map { 
                            // frameIndex starting from 0, fps = 1. Time = frameIndex / fps
                            val timeSeconds = it.frameIndex / fps
                            FloatEntry(x = timeSeconds, y = it.averageIntensity.toFloat()) 
                        }
                        entryModelOf(entries)
                    }
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .background(MaterialTheme.colorScheme.surface)
                            .drawWithContent {
                                graphicsLayer.record {
                                    this@drawWithContent.drawContent()
                                }
                                drawContent()
                            }
                    ) {
                        Chart(
                            chart = lineChart(
                                lines = listOf(lineSpec(
                                    lineColor = MaterialTheme.colorScheme.primary,
                                    point = null,
                                    pointConnector = com.patrykandpatrick.vico.core.chart.DefaultPointConnector(cubicStrength = 0f)
                                ))
                            ),
                            model = chartEntryModel,
                            startAxis = rememberStartAxis(title = "Intensity"),
                            bottomAxis = rememberBottomAxis(
                                title = "Time (s)",
                                itemPlacer = AxisItemPlacer.Horizontal.default(spacing = 200)
                            ),
                            chartScrollSpec = rememberChartScrollSpec(isScrollEnabled = false)
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showChartDialog = false }) {
                    Text("Close")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            isSavingImage = true
                            try {
                                val bitmap = graphicsLayer.toImageBitmap().asAndroidBitmap()
                                val uri = ImageExporter.exportBitmapToGallery(context, bitmap)
                                imageSaveMessage = if (uri != null) "Chart saved to MediaStore!" else "Failed to save chart"
                            } catch (e: Exception) {
                                imageSaveMessage = "Error: ${e.localizedMessage}"
                            }
                            isSavingImage = false
                        }
                    },
                    enabled = !isSavingImage
                ) {
                    Text(if (isSavingImage) "Saving..." else "Save as PNG")
                }
            }
        )
    }
    
    if (showAdvancedSettings && roiResults != null) {
        AdvancedAnalysisSettingsScreen(
            onRunAnalysis = { params ->
                val rawData = roiResults!!.map { 
                    val timeSeconds = it.frameIndex / fps
                    Pair(timeSeconds.toDouble(), it.averageIntensity) 
                }
                val results = SignalProcessor.analyze(rawData, params)
                analysisParams = params
                analysisResults = results
                showAdvancedSettings = false
            },
            onCancel = { showAdvancedSettings = false }
        )
        return
    }
    
    if (analysisResults != null && analysisParams != null) {
        val sessionDir = files.firstOrNull()?.parentFile
        val videoFile = sessionDir?.let { java.io.File(it, "${testTitle}.mp4") }
        
        AnalysisResultScreen(
            results = analysisResults!!,
            params = analysisParams!!,
            videoFile = videoFile,
            testTitle = testTitle,
            onDismiss = { analysisResults = null },
            onSave = { name ->
                val entity = ExperimentEntity(
                    experimentName = name,
                    timestamp = System.currentTimeMillis(),
                    exposureTime = 1, // Video frames are 1s interval (fps=1)
                    sessionFolderPath = files.firstOrNull()?.parent ?: "",
                    peakTime = analysisResults!!.peakTime,
                    peakIntensity = analysisResults!!.peakIntensity,
                    totalAuc = analysisResults!!.totalAuc,
                    highDuration = analysisResults!!.highDuration,
                    maxWindowAuc = analysisResults!!.maxWindowAuc,
                    maxWindowStartTime = analysisResults!!.maxWindowStartTime,
                    maxWindowEndTime = analysisResults!!.maxWindowEndTime
                )
                onSaveExperiment(entity)
            }
        )
        return
    }"""

if block1 in content:
    content = content.replace(block1, "")
    print("Block replaced.")
else:
    print("Block not found!")
    
# also delete the line "showChartDialog = true // Auto-show chart upon success"
content = content.replace("showChartDialog = true // Auto-show chart upon success", "")

with open("app/src/main/java/com/example/VideoAnalysisScreen.kt", "w") as f:
    f.write(content)
