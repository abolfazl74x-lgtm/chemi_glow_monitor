import re

with open("app/src/main/java/com/example/VideoAnalysisScreen.kt", "r") as f:
    content = f.read()

target_signature = """fun VideoAnalysisScreen(
    files: List<File>,
    testTitle: String,
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit
)"""

replacement_signature = """fun VideoAnalysisScreen(
    files: List<File>,
    testTitle: String,
    onBack: () -> Unit,
    onSaveExperiment: (ExperimentEntity) -> Unit,
    onNavigateToAdvancedAnalysis: (List<IntensityResult>, Float, String, String) -> Unit
)"""

content = content.replace(target_signature, replacement_signature)

target_shared = """                SharedResultsView(
                    roiResults = roiResults!!,
                    sessionFolder = files.firstOrNull()?.parentFile,
                    testTitle = testTitle,
                    exposureTime = 1f, // Video frames are 1s interval (fps=1)
                    onBack = onBack,
                    onSaveExperiment = { exp -> 
                        onSaveExperiment(exp)
                        onBack()
                    }
                )"""

replacement_shared = """                SharedResultsView(
                    roiResults = roiResults!!,
                    sessionFolder = files.firstOrNull()?.parentFile,
                    testTitle = testTitle,
                    exposureTime = 1f, // Video frames are 1s interval (fps=1)
                    onBack = onBack,
                    onSaveExperiment = { exp -> 
                        onSaveExperiment(exp)
                        onBack()
                    },
                    onNavigateToAdvancedAnalysis = {
                        onNavigateToAdvancedAnalysis(
                            roiResults!!,
                            1f,
                            testTitle,
                            files.firstOrNull()?.parentFile?.absolutePath ?: ""
                        )
                    }
                )"""

content = content.replace(target_shared, replacement_shared)

with open("app/src/main/java/com/example/VideoAnalysisScreen.kt", "w") as f:
    f.write(content)
print("VideoAnalysisScreen patched")
