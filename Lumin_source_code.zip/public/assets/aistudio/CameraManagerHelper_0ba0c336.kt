package com.example

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

class CameraManagerHelper(private val context: Context) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    var cameraDevice: CameraDevice? = null
    var captureSession: CameraCaptureSession? = null
    var previewRequestBuilder: CaptureRequest.Builder? = null
    private var imageReader: ImageReader? = null
    
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    
    init {
        startBackgroundThread()
    }
    
    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also {
            it.start()
            backgroundHandler = Handler(it.looper)
        }
    }
    
    fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }

    fun getBackCameraId(): String? {
        return cameraManager.cameraIdList.firstOrNull { id ->
            val chars = cameraManager.getCameraCharacteristics(id)
            val facing = chars.get(CameraCharacteristics.LENS_FACING)
            facing == CameraCharacteristics.LENS_FACING_BACK
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun openCamera(cameraId: String): Boolean = suspendCoroutine { cont ->
        var resumed = false
        try {
            cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    if (!resumed) {
                        resumed = true
                        cont.resume(true)
                    }
                }
                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    cameraDevice = null
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    cameraDevice = null
                    if (!resumed) {
                        resumed = true
                        cont.resume(false)
                    }
                }
            }, backgroundHandler)
        } catch (e: Exception) {
            if (!resumed) {
                resumed = true
                cont.resume(false)
            }
        }
    }
    
    suspend fun startPreview(previewSurface: Surface): Boolean = suspendCoroutine { cont ->
        val camera = cameraDevice ?: return@suspendCoroutine cont.resume(false)
        try {
            val requestBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            requestBuilder.addTarget(previewSurface)
            previewRequestBuilder = requestBuilder
            
            camera.createCaptureSession(listOf(previewSurface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    try {
                        requestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                        session.setRepeatingRequest(requestBuilder.build(), null, backgroundHandler)
                        cont.resume(true)
                    } catch (e: Exception) {
                        cont.resume(false)
                    }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    cont.resume(false)
                }
            }, backgroundHandler)
        } catch (e: Exception) {
            cont.resume(false)
        }
    }

    fun getMinimumFocusDistance(): Float {
        val camera = cameraDevice ?: return 0f
        val chars = cameraManager.getCameraCharacteristics(camera.id)
        return chars.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
    }
    
    fun updatePreviewFocus(distance: Float) {
        val session = captureSession ?: return
        val builder = previewRequestBuilder ?: return
        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
        builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, distance)
        try {
            session.setRepeatingRequest(builder.build(), null, backgroundHandler)
        } catch (e: Exception) {
            Log.e("CameraManagerHelper", "Failed to update focus", e)
        }
    }

    suspend fun captureSequence(
        previewSurface: Surface,
        outputDir: File,
        numFrames: Int,
        exposureNanos: Long = 4_000_000_000L,
        iso: Int = 800,
        focusDistance: Float = 0f,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val camera = cameraDevice ?: return@withContext false
        
        val chars = cameraManager.getCameraCharacteristics(camera.id)
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val sizes = map?.getOutputSizes(ImageFormat.JPEG)
        val largest = sizes?.maxByOrNull { it.width * it.height } ?: return@withContext false
        
        val reader = ImageReader.newInstance(largest.width, largest.height, ImageFormat.JPEG, 2)
        imageReader = reader
        
        val session = suspendCoroutine<CameraCaptureSession?> { cont ->
            try {
                camera.createCaptureSession(listOf(previewSurface, reader.surface), object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        cont.resume(session)
                    }
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        cont.resume(null)
                    }
                }, backgroundHandler)
            } catch (e: Exception) {
                Log.e("CameraManagerHelper", "Failed to create capture session", e)
                cont.resume(null)
            }
        } ?: return@withContext false
        
        captureSession = session
        
        val requestBuilder = try {
            val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            builder.addTarget(reader.surface)
            // Also target preview surface to keep the preview alive if device allows
            builder.addTarget(previewSurface)
            
            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            builder.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exposureNanos)
            builder.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            builder.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusDistance)
            builder.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF)
            builder
        } catch (e: Exception) {
            Log.e("CameraManagerHelper", "Error setting manual parameters", e)
            return@withContext false
        }

        if (!outputDir.exists()) outputDir.mkdirs()
        else {
            // clear old frames
            outputDir.listFiles()?.forEach { it.delete() }
        }

        for (i in 1..numFrames) {
            val imageSaved = suspendCoroutine<Boolean> { cont ->
                var imageAcquired = false
                reader.setOnImageAvailableListener({ ir ->
                    if (imageAcquired) return@setOnImageAvailableListener
                    try {
                        val image: Image? = ir.acquireLatestImage()
                        image?.let {
                            val buffer = it.planes[0].buffer
                            val bytes = ByteArray(buffer.remaining())
                            buffer.get(bytes)
                            
                            val fileName = String.format("frame_%03d.jpg", i)
                            val file = File(outputDir, fileName)
                            FileOutputStream(file).use { out ->
                                out.write(bytes)
                            }
                            it.close()
                            imageAcquired = true
                            cont.resume(true)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }, backgroundHandler)
                
                try {
                    session.capture(requestBuilder.build(), null, backgroundHandler)
                } catch (e: Exception) {
                    if (!imageAcquired) {
                        imageAcquired = true
                        cont.resume(false)
                    }
                }
            }
            if (imageSaved) {
                onProgress(i)
            } else {
                break
            }
        }
        
        // clear listener
        reader.setOnImageAvailableListener(null, null)
        reader.close()
        imageReader = null
        
        // restart preview
        startPreview(previewSurface)
        
        return@withContext true
    }

    fun stopCamera() {
        try {
            captureSession?.stopRepeating()
        } catch (e: Exception) {}
        captureSession?.close()
        captureSession = null
        cameraDevice?.close()
        cameraDevice = null
    }

    fun close() {
        captureSession?.close()
        captureSession = null
        cameraDevice?.close()
        cameraDevice = null
        imageReader?.close()
        imageReader = null
        stopBackgroundThread()
    }
}
