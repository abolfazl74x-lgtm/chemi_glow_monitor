import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.core.entry.entryModelOf
import com.patrykandpatrick.vico.core.chart.decoration.ThresholdLine
import com.patrykandpatrick.vico.compose.axis.vertical.rememberStartAxis
import com.patrykandpatrick.vico.compose.axis.horizontal.rememberBottomAxis
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.patrykandpatrick.vico.compose.component.shapeComponent
import androidx.compose.ui.graphics.Color
import com.patrykandpatrick.vico.compose.component.textComponent
import com.patrykandpatrick.vico.core.component.shape.Shapes

@Composable
fun Test() {
    val tLine = remember {
        ThresholdLine(
            thresholdValue = 10f,
            lineComponent = shapeComponent(color = Color.Red),
            labelComponent = textComponent(color = Color.White),
            label = "Test"
        )
    }
}
